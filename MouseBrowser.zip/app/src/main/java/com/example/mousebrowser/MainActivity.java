package com.example.mousebrowser;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    private WebView web;
    private PadView pad;
    private TextView circle, bMouse, bDrag, bDesk;
    private LinearLayout addrBar, bar;
    private EditText urlBox;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean mouseMode = true, dragging = false, desktop = true;
    private long downTime;
    private float density;

    private int dp(float v) { return (int) (v * density + 0.5f); }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private TextView btn(String t) {
        TextView b = new TextView(this);
        b.setText(t);
        b.setTextColor(Color.WHITE);
        b.setTextSize(16);
        b.setGravity(Gravity.CENTER);
        b.setBackground(shape(0xCC202124, dp(22)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        b.setLayoutParams(lp);
        return b;
    }

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        density = getResources().getDisplayMetrics().density;

        FrameLayout root = new FrameLayout(this);
        setContentView(root);

        // ---- WebView ----
        web = new WebView(this);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setUserAgentString(DESKTOP_UA);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String u) { return false; }
            @Override public void onPageStarted(WebView v, String u, Bitmap f) {
                if (!urlBox.hasFocus()) urlBox.setText(u);
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        // ---- Touchpad + cursor ----
        pad = new PadView(this);
        pad.setListener(new PadView.Listener() {
            @Override public void onMove(float x, float y) {
                if (dragging) sendMouse(MotionEvent.ACTION_MOVE, x, y, MotionEvent.BUTTON_PRIMARY);
                else sendMouse(MotionEvent.ACTION_HOVER_MOVE, x, y, 0);
            }
            @Override public void onClick(float x, float y) { click(x, y, MotionEvent.BUTTON_PRIMARY); }
            @Override public void onScroll(float dx, float dy, float x, float y) { wheel(dx, dy, x, y); }
        });
        root.addView(pad, new FrameLayout.LayoutParams(-1, -1));

        // ---- Bottom control bar ----
        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        TextView bBack = btn("◀");
        bMouse = btn("🖱");
        TextView bL = btn("L");
        TextView bR = btn("R");
        bDrag = btn("✥");
        bDesk = btn("🖥");
        TextView bReload = btn("⟳");
        bar.addView(bBack); bar.addView(bMouse); bar.addView(bL); bar.addView(bR);
        bar.addView(bDrag); bar.addView(bDesk); bar.addView(bReload);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        blp.setMargins(dp(6), 0, dp(6), dp(8));
        root.addView(bar, blp);

        bBack.setOnClickListener(v -> { if (web.canGoBack()) web.goBack(); });
        bReload.setOnClickListener(v -> web.reload());
        bL.setOnClickListener(v -> click(pad.cx, pad.cy, MotionEvent.BUTTON_PRIMARY));
        bR.setOnClickListener(v -> click(pad.cx, pad.cy, MotionEvent.BUTTON_SECONDARY));
        bMouse.setOnClickListener(v -> {
            mouseMode = !mouseMode;
            pad.setVisibility(mouseMode ? View.VISIBLE : View.GONE);
            bMouse.setBackground(shape(mouseMode ? 0xCC202124 : 0xCC9E9E9E, dp(22)));
            if (!mouseMode && dragging) toggleDrag();
        });
        bDrag.setOnClickListener(v -> toggleDrag());
        bDesk.setOnClickListener(v -> {
            desktop = !desktop;
            web.getSettings().setUserAgentString(desktop ? DESKTOP_UA : null);
            web.getSettings().setUseWideViewPort(desktop);
            bDesk.setBackground(shape(desktop ? 0xCC202124 : 0xCC9E9E9E, dp(22)));
            web.reload();
        });

        // ---- Address bar (expanded) ----
        addrBar = new LinearLayout(this);
        addrBar.setOrientation(LinearLayout.HORIZONTAL);
        addrBar.setGravity(Gravity.CENTER_VERTICAL);
        addrBar.setBackground(shape(0xEE202124, dp(24)));
        addrBar.setPadding(dp(14), dp(4), dp(6), dp(4));
        addrBar.setVisibility(View.GONE);
        urlBox = new EditText(this);
        urlBox.setSingleLine(true);
        urlBox.setTextColor(Color.WHITE);
        urlBox.setHintTextColor(0xFFAAAAAA);
        urlBox.setHint("Address or search");
        urlBox.setBackground(null);
        urlBox.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlBox.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBox.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        TextView go = new TextView(this);
        go.setText("➜");
        go.setTextColor(Color.WHITE);
        go.setTextSize(20);
        go.setGravity(Gravity.CENTER);
        go.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(40)));
        addrBar.addView(urlBox);
        addrBar.addView(go);
        FrameLayout.LayoutParams alp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        alp.setMargins(dp(8), dp(8), dp(8), 0);
        root.addView(addrBar, alp);

        urlBox.setOnEditorActionListener((v, id, ev) -> { submit(); return true; });
        go.setOnClickListener(v -> submit());

        // ---- Circle (collapsed address) ----
        circle = new TextView(this);
        circle.setText("🌐");
        circle.setTextSize(20);
        circle.setGravity(Gravity.CENTER);
        circle.setAlpha(0.65f);
        circle.setBackground(shape(0xFF202124, dp(22)));
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP | Gravity.START);
        clp.setMargins(dp(8), dp(8), 0, 0);
        root.addView(circle, clp);
        circle.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy, sx, sy; boolean drag;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX(); sy = e.getRawY();
                        dx = v.getTranslationX(); dy = v.getTranslationY(); drag = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float mx = e.getRawX() - sx, my = e.getRawY() - sy;
                        if (drag || Math.abs(mx) + Math.abs(my) > dp(10)) {
                            drag = true;
                            v.setTranslationX(dx + mx); v.setTranslationY(dy + my);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!drag) expand();
                        return true;
                }
                return true;
            }
        });

        web.loadUrl("https://www.google.com");
    }

    // ---------- address bar ----------
    private void expand() {
        circle.setVisibility(View.GONE);
        addrBar.setVisibility(View.VISIBLE);
        urlBox.requestFocus();
        urlBox.selectAll();
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        im.showSoftInput(urlBox, InputMethodManager.SHOW_IMPLICIT);
    }

    private void collapse() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        im.hideSoftInputFromWindow(urlBox.getWindowToken(), 0);
        urlBox.clearFocus();
        addrBar.setVisibility(View.GONE);
        circle.setVisibility(View.VISIBLE);
    }

    private void submit() {
        String t = urlBox.getText().toString().trim();
        if (!t.isEmpty()) {
            String u;
            if (t.contains("://")) u = t;
            else if (!t.contains(" ") && t.contains(".")) u = "https://" + t;
            else u = "https://www.google.com/search?q=" + android.net.Uri.encode(t);
            web.loadUrl(u);
        }
        collapse();
    }

    // ---------- mouse events ----------
    private void sendMouse(int action, float x, float y, int buttons) {
        long now = SystemClock.uptimeMillis();
        if (action == MotionEvent.ACTION_DOWN) downTime = now;
        MotionEvent.PointerProperties[] pp = { new MotionEvent.PointerProperties() };
        pp[0].id = 0;
        pp[0].toolType = MotionEvent.TOOL_TYPE_MOUSE;
        MotionEvent.PointerCoords[] pc = { new MotionEvent.PointerCoords() };
        pc[0].x = x; pc[0].y = y; pc[0].pressure = 1f; pc[0].size = 1f;
        boolean generic = action == MotionEvent.ACTION_HOVER_MOVE;
        MotionEvent ev = MotionEvent.obtain(generic ? now : downTime, now, action, 1, pp, pc,
                0, buttons, 1f, 1f, 0, 0, InputDevice.SOURCE_MOUSE, 0);
        if (generic) web.dispatchGenericMotionEvent(ev);
        else web.dispatchTouchEvent(ev);
        ev.recycle();
    }

    private void click(final float x, final float y, final int button) {
        sendMouse(MotionEvent.ACTION_HOVER_MOVE, x, y, 0);
        sendMouse(MotionEvent.ACTION_DOWN, x, y, button);
        h.postDelayed(() -> sendMouse(MotionEvent.ACTION_UP, x, y, 0), 50);
    }

    private void toggleDrag() {
        dragging = !dragging;
        bDrag.setBackground(shape(dragging ? 0xCCD32F2F : 0xCC202124, dp(22)));
        if (dragging) sendMouse(MotionEvent.ACTION_DOWN, pad.cx, pad.cy, MotionEvent.BUTTON_PRIMARY);
        else sendMouse(MotionEvent.ACTION_UP, pad.cx, pad.cy, 0);
    }

    private void wheel(float dx, float dy, float x, float y) {
        long now = SystemClock.uptimeMillis();
        MotionEvent.PointerProperties[] pp = { new MotionEvent.PointerProperties() };
        pp[0].id = 0;
        pp[0].toolType = MotionEvent.TOOL_TYPE_MOUSE;
        MotionEvent.PointerCoords[] pc = { new MotionEvent.PointerCoords() };
        pc[0].x = x; pc[0].y = y;
        float unit = dp(48) / 1.5f;
        pc[0].setAxisValue(MotionEvent.AXIS_VSCROLL, dy / unit);
        pc[0].setAxisValue(MotionEvent.AXIS_HSCROLL, -dx / unit);
        MotionEvent ev = MotionEvent.obtain(now, now, MotionEvent.ACTION_SCROLL, 1, pp, pc,
                0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_MOUSE, 0);
        web.dispatchGenericMotionEvent(ev);
        ev.recycle();
    }

    @Override
    public void onBackPressed() {
        if (addrBar.getVisibility() == View.VISIBLE) collapse();
        else if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
