package com.example.mousebrowser;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;

/** Transparent touchpad layer that draws a mouse cursor. */
public class PadView extends View {
    public interface Listener {
        void onMove(float x, float y);
        void onClick(float x, float y);
        void onScroll(float dx, float dy, float x, float y);
    }

    public float cx, cy;
    public float sens = 1.6f;
    private Listener l;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path arrow = new Path();
    private boolean placed = false;
    private float lx, ly, sx, sy;
    private long t0;
    private boolean moved, multi;
    private final float slop;

    public PadView(Context c) {
        super(c);
        float d = c.getResources().getDisplayMetrics().density;
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        fill.setColor(0xFFFFFFFF);
        fill.setStyle(Paint.Style.FILL);
        stroke.setColor(0xFF000000);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(d * 1.5f);
        arrow.moveTo(0, 0);
        arrow.lineTo(0, d * 20);
        arrow.lineTo(d * 5, d * 15.5f);
        arrow.lineTo(d * 9, d * 23);
        arrow.lineTo(d * 12, d * 21.5f);
        arrow.lineTo(d * 8, d * 14.5f);
        arrow.lineTo(d * 14, d * 14.5f);
        arrow.close();
    }

    public void setListener(Listener x) { l = x; }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        if (!placed && w > 0) { cx = w / 2f; cy = h / 2f; placed = true; }
        cx = Math.min(cx, w - 1);
        cy = Math.min(cy, h - 1);
    }

    @Override
    protected void onDraw(Canvas c) {
        c.save();
        c.translate(cx, cy);
        c.drawPath(arrow, fill);
        c.drawPath(arrow, stroke);
        c.restore();
    }

    private float avgX(MotionEvent e) {
        float s = 0; for (int i = 0; i < e.getPointerCount(); i++) s += e.getX(i);
        return s / e.getPointerCount();
    }
    private float avgY(MotionEvent e) {
        float s = 0; for (int i = 0; i < e.getPointerCount(); i++) s += e.getY(i);
        return s / e.getPointerCount();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                lx = sx = e.getX(); ly = sy = e.getY();
                t0 = e.getEventTime(); moved = false; multi = false;
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
                multi = true; lx = avgX(e); ly = avgY(e);
                return true;
            case MotionEvent.ACTION_MOVE:
                if (e.getPointerCount() >= 2) {
                    float ax = avgX(e), ay = avgY(e);
                    if (l != null) l.onScroll(ax - lx, ay - ly, cx, cy);
                    lx = ax; ly = ay;
                } else if (!multi) {
                    float x = e.getX(), y = e.getY();
                    float dx = x - lx, dy = y - ly;
                    lx = x; ly = y;
                    if (Math.abs(x - sx) + Math.abs(y - sy) > slop) moved = true;
                    cx = Math.max(0, Math.min(getWidth() - 1, cx + dx * sens));
                    cy = Math.max(0, Math.min(getHeight() - 1, cy + dy * sens));
                    invalidate();
                    if (l != null) l.onMove(cx, cy);
                }
                return true;
            case MotionEvent.ACTION_UP:
                if (!moved && !multi && e.getEventTime() - t0 < 300 && l != null) l.onClick(cx, cy);
                return true;
        }
        return true;
    }
}
