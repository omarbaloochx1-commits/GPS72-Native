package com.example.mousebrowser;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    private WebView web;
    private PadView pad;
    private TextView circle, bMouse, bDrag, bDesk;
    private LinearLayout addrBar, bar;
    private EditText urlBox;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean mouseMode = true, dragging = false, desktop = true;
    private long downTime;
    private float density;

    private int dp(float v) { return (int) (v * density + 0.5f); }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private TextView btn(String t) {
        TextView b = new TextView(this);
        b.setText(t);
        b.setTextColor(Color.WHITE);
        b.setTextSize(16);
        b.setGravity(Gravity.CENTER);
        b.setBackground(shape(0xCC202124, dp(22)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        b.setLayoutParams(lp);
        return b;
    }

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle s) {
        super.onCreate(s);
        density = getResources().getDisplayMetrics().density;

        FrameLayout root = new FrameLayout(this);
        setContentView(root);

        // ---- WebView ----
        web = new WebView(this);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setBuiltInZoomControls(true);
        ws.setDisplayZoomControls(false);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setUserAgentString(DESKTOP_UA);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, String u) { return false; }
            @Override public void onPageStarted(WebView v, String u, Bitmap f) {
                if (!urlBox.hasFocus()) urlBox.setText(u);
            }
        });
        root.addView(web, new FrameLayout.LayoutParams(-1, -1));

        // ---- Touchpad + cursor ----
        pad = new PadView(this);
        pad.setListener(new PadView.Listener() {
            @Override public void onMove(float x, float y) { onCursorMove(x, y); }
            @Override public void onClick(float x, float y) { leftClick(); }
            @Override public void onScroll(float dx, float dy, float x, float y) { js("scroll", x, y, dx, dy); }
        });
        root.addView(pad, new FrameLayout.LayoutParams(-1, -1));

        // ---- Bottom control bar ----
        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        TextView bBack = btn("◀");
        bMouse = btn("🖱");
        TextView bL = btn("L");
        TextView bR = btn("R");
        bDrag = btn("✥");
        bDesk = btn("🖥");
        TextView bReload = btn("⟳");
        bar.addView(bBack); bar.addView(bMouse); bar.addView(bL); bar.addView(bR);
        bar.addView(bDrag); bar.addView(bDesk); bar.addView(bReload);
        FrameLayout.LayoutParams blp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        blp.setMargins(dp(6), 0, dp(6), dp(8));
        root.addView(bar, blp);

        bBack.setOnClickListener(v -> { if (web.canGoBack()) web.goBack(); });
        bReload.setOnClickListener(v -> web.reload());
        bL.setOnClickListener(v -> leftClick());
        bR.setOnClickListener(v -> rightClick());
        bMouse.setOnClickListener(v -> {
            mouseMode = !mouseMode;
            pad.setVisibility(mouseMode ? View.VISIBLE : View.GONE);
            bMouse.setBackground(shape(mouseMode ? 0xCC202124 : 0xCC9E9E9E, dp(22)));
            if (!mouseMode && dragging) toggleDrag();
        });
        bDrag.setOnClickListener(v -> toggleDrag());
        bDesk.setOnClickListener(v -> {
            desktop = !desktop;
            web.getSettings().setUserAgentString(desktop ? DESKTOP_UA : null);
            web.getSettings().setUseWideViewPort(desktop);
            bDesk.setBackground(shape(desktop ? 0xCC202124 : 0xCC9E9E9E, dp(22)));
            web.reload();
        });

        // ---- Address bar (expanded) ----
        addrBar = new LinearLayout(this);
        addrBar.setOrientation(LinearLayout.HORIZONTAL);
        addrBar.setGravity(Gravity.CENTER_VERTICAL);
        addrBar.setBackground(shape(0xEE202124, dp(24)));
        addrBar.setPadding(dp(14), dp(4), dp(6), dp(4));
        addrBar.setVisibility(View.GONE);
        urlBox = new EditText(this);
        urlBox.setSingleLine(true);
        urlBox.setTextColor(Color.WHITE);
        urlBox.setHintTextColor(0xFFAAAAAA);
        urlBox.setHint("Address or search");
        urlBox.setBackground(null);
        urlBox.setInputType(android.text.InputType.TYPE_TEXT_VARIATION_URI);
        urlBox.setImeOptions(EditorInfo.IME_ACTION_GO);
        urlBox.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        TextView go = new TextView(this);
        go.setText("➜");
        go.setTextColor(Color.WHITE);
        go.setTextSize(20);
        go.setGravity(Gravity.CENTER);
        go.setLayoutParams(new LinearLayout.LayoutParams(dp(44), dp(40)));
        addrBar.addView(urlBox);
        addrBar.addView(go);
        FrameLayout.LayoutParams alp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        alp.setMargins(dp(8), dp(8), dp(8), 0);
        root.addView(addrBar, alp);

        urlBox.setOnEditorActionListener((v, id, ev) -> { submit(); return true; });
        go.setOnClickListener(v -> submit());

        // ---- Circle (collapsed address) ----
        circle = new TextView(this);
        circle.setText("🌐");
        circle.setTextSize(20);
        circle.setGravity(Gravity.CENTER);
        circle.setAlpha(0.65f);
        circle.setBackground(shape(0xFF202124, dp(22)));
        FrameLayout.LayoutParams clp = new FrameLayout.LayoutParams(dp(44), dp(44), Gravity.TOP | Gravity.START);
        clp.setMargins(dp(8), dp(8), 0, 0);
        root.addView(circle, clp);
        circle.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy, sx, sy; boolean drag;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX(); sy = e.getRawY();
                        dx = v.getTranslationX(); dy = v.getTranslationY(); drag = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float mx = e.getRawX() - sx, my = e.getRawY() - sy;
                        if (drag || Math.abs(mx) + Math.abs(my) > dp(10)) {
                            drag = true;
                            v.setTranslationX(dx + mx); v.setTranslationY(dy + my);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!drag) expand();
                        return true;
                }
                return true;
            }
        });

        web.loadUrl("https://www.google.com");
    }

    // ---------- address bar ----------
    private void expand() {
        circle.setVisibility(View.GONE);
        addrBar.setVisibility(View.VISIBLE);
        urlBox.requestFocus();
        urlBox.selectAll();
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        im.showSoftInput(urlBox, InputMethodManager.SHOW_IMPLICIT);
    }

    private void collapse() {
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        im.hideSoftInputFromWindow(urlBox.getWindowToken(), 0);
        urlBox.clearFocus();
        addrBar.setVisibility(View.GONE);
        circle.setVisibility(View.VISIBLE);
    }

    private void submit() {
        String t = urlBox.getText().toString().trim();
        if (!t.isEmpty()) {
            String u;
            if (t.contains("://")) u = t;
            else if (!t.contains(" ") && t.contains(".")) u = "https://" + t;
            else u = "https://www.google.com/search?q=" + android.net.Uri.encode(t);
            web.loadUrl(u);
        }
        collapse();
    }

    // ---------- mouse events (injected as real DOM mouse/pointer events) ----------
    private static final String JS =
            "(function(a,x,y,dx,dy,W,H){\n" +
            "var vv=window.visualViewport,k=vv?vv.width/W:window.innerWidth/W;\n" +
            "var cx=(vv?vv.offsetLeft:0)+x*k,cy=(vv?vv.offsetTop:0)+y*k;\n" +
            "var el=document.elementFromPoint(cx,cy);if(!el)return 0;\n" +
            "function me(t,b,bs){return new MouseEvent(t,{bubbles:true,cancelable:true,view:window,clientX:cx,clientY:cy,screenX:cx,screenY:cy,button:b,buttons:bs});}\n" +
            "function pe(t,b,bs){try{return new PointerEvent(t,{bubbles:true,cancelable:true,view:window,clientX:cx,clientY:cy,screenX:cx,screenY:cy,button:b,buttons:bs,pointerId:1,pointerType:'mouse',isPrimary:true});}catch(e){return me(t,b,bs);}}\n" +
            "function fire(pt,mt,b,bs){if(pt)el.dispatchEvent(pe(pt,b,bs));if(mt)el.dispatchEvent(me(mt,b,bs));}\n" +
            "function edit(n){var t=(n.tagName||'').toLowerCase();return t=='input'||t=='textarea'||t=='select'||n.isContentEditable;}\n" +
            "function hover(bs){var h=window.__mh;if(h===el)return;if(h){h.dispatchEvent(pe('pointerout',0,bs));h.dispatchEvent(me('mouseout',0,bs));h.dispatchEvent(pe('pointerleave',0,bs));h.dispatchEvent(me('mouseleave',0,bs));}\n" +
            "el.dispatchEvent(pe('pointerover',0,bs));el.dispatchEvent(me('mouseover',0,bs));el.dispatchEvent(pe('pointerenter',0,bs));el.dispatchEvent(me('mouseenter',0,bs));window.__mh=el;}\n" +
            "var bs=window.__mb||0;\n" +
            "if(a=='move'){hover(bs);fire('pointermove','mousemove',0,bs);return 0;}\n" +
            "if(a=='down'||a=='click'||a=='rclick'){\n" +
            "var b=a=='rclick'?2:0,d=a=='rclick'?2:1,ed=0;\n" +
            "hover(0);fire('pointermove','mousemove',0,0);fire('pointerdown','mousedown',b,d);\n" +
            "if(b==0){var n=el;while(n&&!edit(n))n=n.parentElement;if(n){n.focus();ed=1;}else if(document.activeElement&&document.activeElement.blur){document.activeElement.blur();}}\n" +
            "if(a=='down'){window.__mb=1;return ed;}\n" +
            "fire('pointerup','mouseup',b,0);\n" +
            "if(b==0)fire(null,'click',0,0);else fire(null,'contextmenu',2,0);\n" +
            "return ed;}\n" +
            "if(a=='up'){fire('pointerup','mouseup',0,0);window.__mb=0;return 0;}\n" +
            "if(a=='scroll'){var wx=-dx*k,wy=-dy*k;\n" +
            "var we=new WheelEvent('wheel',{bubbles:true,cancelable:true,view:window,clientX:cx,clientY:cy,deltaX:wx,deltaY:wy,deltaMode:0});\n" +
            "if(!el.dispatchEvent(we))return 0;\n" +
            "for(var n=el;n&&n!==document.body&&n!==document.documentElement;n=n.parentElement){var s=getComputedStyle(n);\n" +
            "if(((s.overflowY=='auto'||s.overflowY=='scroll')&&n.scrollHeight>n.clientHeight)||((s.overflowX=='auto'||s.overflowX=='scroll')&&n.scrollWidth>n.clientWidth)){n.scrollBy(wx,wy);return 0;}}\n" +
            "window.scrollBy(wx,wy);return 0;}\n" +
            "return 0;})('%s',%f,%f,%f,%f,%d,%d)";

    private long lastMoveMs = 0;

    private void js(String action, float x, float y, float dx, float dy) {
        final boolean wantsResult = action.equals("click") || action.equals("down");
        String code = String.format(java.util.Locale.US, JS, action, x, y, dx, dy,
                Math.max(1, web.getWidth()), Math.max(1, web.getHeight()));
        web.evaluateJavascript(code, wantsResult ? value -> {
            InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if ("1".equals(value)) {
                web.requestFocus();
                im.showSoftInput(web, 0);
            } else {
                im.hideSoftInputFromWindow(web.getWindowToken(), 0);
            }
        } : null);
    }

    private void sendHover(float x, float y) {
        long now = SystemClock.uptimeMillis();
        MotionEvent.PointerProperties[] pp = { new MotionEvent.PointerProperties() };
        pp[0].id = 0;
        pp[0].toolType = MotionEvent.TOOL_TYPE_MOUSE;
        MotionEvent.PointerCoords[] pc = { new MotionEvent.PointerCoords() };
        pc[0].x = x; pc[0].y = y;
        MotionEvent ev = MotionEvent.obtain(now, now, MotionEvent.ACTION_HOVER_MOVE, 1, pp, pc,
                0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_MOUSE, 0);
        web.dispatchGenericMotionEvent(ev);
        ev.recycle();
    }

    private void onCursorMove(float x, float y) {
        long now = SystemClock.uptimeMillis();
        if (now - lastMoveMs < 40) return;
        lastMoveMs = now;
        if (!dragging) sendHover(x, y);
        js("move", x, y, 0, 0);
    }

    private void leftClick() { js("click", pad.cx, pad.cy, 0, 0); }
    private void rightClick() { js("rclick", pad.cx, pad.cy, 0, 0); }

    private void toggleDrag() {
        dragging = !dragging;
        bDrag.setBackground(shape(dragging ? 0xCCD32F2F : 0xCC202124, dp(22)));
        js(dragging ? "down" : "up", pad.cx, pad.cy, 0, 0);
    }

    @Override
    public void onBackPressed() {
        if (addrBar.getVisibility() == View.VISIBLE) collapse();
        else if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
