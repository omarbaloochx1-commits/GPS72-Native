package com.example.gps72;

import java.util.ArrayList;
import java.util.Locale;

/** Builds a GPX 1.1 document from waypoints, the active track log and saved tracks. */
final class Gpx {
    private Gpx() { }

    static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    static String build(ArrayList<GpsView.Wp> wps, ArrayList<double[]> log, ArrayList<GpsView.Trk> saved) {
        StringBuilder b = new StringBuilder(64 * 1024);
        b.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        b.append("<gpx version=\"1.1\" creator=\"GPS 72\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n");
        for (GpsView.Wp w : wps) {
            b.append(String.format(Locale.US, "  <wpt lat=\"%.6f\" lon=\"%.6f\"><name>%s</name></wpt>\n", w.la, w.lo, esc(w.n)));
        }
        for (GpsView.Trk t : saved) segment(b, t.n, t.p);
        if (log.size() > 1) segment(b, "ACTIVE LOG", log);
        b.append("</gpx>\n");
        return b.toString();
    }

    private static void segment(StringBuilder b, String name, ArrayList<double[]> pts) {
        if (pts.size() < 2) return;
        b.append("  <trk><name>").append(esc(name)).append("</name><trkseg>\n");
        for (double[] q : pts) b.append(String.format(Locale.US, "    <trkpt lat=\"%.6f\" lon=\"%.6f\"/>\n", q[0], q[1]));
        b.append("  </trkseg></trk>\n");
    }
}
