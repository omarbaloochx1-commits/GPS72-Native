# Bell UH-1 Iroquois 2D Flight Simulator

Android WebView project. Includes a 2D side-view training flight, simplified instruments, touch controls, a quick flight manual, and a first-flight mission (engine start → takeoff → transit → landing zone).

## Build APK on GitHub (phone-only workflow)
1. Create a new GitHub repository.
2. Upload the **contents** of this ZIP (not the ZIP file itself) to the repository root. Keep `.github/workflows/build-apk.yml`.
3. Open **Actions** → **Build Bell UH-1 APK** → **Run workflow** (or push to `main`).
4. Open the completed run and download the `Bell-UH1-Simulator-APK` artifact.
5. Extract the downloaded artifact ZIP to get `app-debug.apk`.

## Controls
Battery/Master → Engine Start → wait for rotor RPM → Mission Start. Use Collective to lift, Cyclic Pitch for forward/back motion, Cyclic Roll for lateral movement, Pedals for yaw, and Throttle for engine power. The manual is available in-game.

## Important
This is an educational 2D game prototype with deliberately simplified flight dynamics and instrument behavior. It is not a real-world flight-training device and does not reproduce certified UH-1H flight characteristics or procedures.
