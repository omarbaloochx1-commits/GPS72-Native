package com.example.gps72;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.location.Location;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.SystemClock;
import android.util.JsonReader;
import android.util.JsonToken;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.TimeZone;
import android.os.Looper;
import android.view.View;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.Locale;

public class GpsView extends View {
    static class Wp { String n; double la, lo, ele = Double.NaN; String desc = "", cat = ""; long ts = System.currentTimeMillis(); Wp(String n, double a, double b) { this.n = n; la = a; lo = b; } }
    public interface ShareCb { void share(ArrayList<Wp> l); }
    static class Ui { boolean[] chk; int t, m, sel, c, lm; char[] n; String nm = ""; double pla, plo; boolean atPos; }

    static final int[] ZM = {1, 2, 5, 10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 500000};
    static final String CH = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    static final String[] UN = {"Metric", "Statute", "Nautical"};
    static final int L = 0, C = 1, R = 2;

    public boolean on;
    public int gerr;
    public double lat, lon, alt;
    public float spd, trk, acc, cmp;
    public long lastFix, cmpT;
    boolean hasAlt, bl = true;
    long t0, mt;
    int page, zi = 8, un, pf, con = 6, ms, go = -1;
    int bto, bp, dfm, nr, lf = 1, ofi = 1, sub, tb, si = -1, ts, tsel, mapOri, ptc;
    boolean t24 = true, eleFt, ofc, arrAl = true, hdgLn = true, accC = true, satUp, lostMsg;
    float tz = 99;
    public float decl;
    public String ver = "";
    public boolean fromGps;
    long lastGps;
    public Runnable loadLandReq, exportReq, scanReq, importReq;
    public ShareCb shareReq;
    int wsel;
    String manDesc = "", manCat = "";
    static final String[] CATS = {"", "Camp", "Water", "Danger", "Village", "Road", "Peak", "Other"};
    boolean gridOn = true, pan;
    ArrayList<float[]> lline = new ArrayList<>(), llbox = new ArrayList<>();
    double pcLat, pcLon;
    int ari = 1, celTab, tdi, tideInt = 180;
    float tideRng = 2.0f;
    int editIdx = -1;
    String lastWps = "";
    float gBrg;
    long gBrgT;
    int goSaved = -1;
    ArrayList<ArrayList<float[]>> lpoly = new ArrayList<>();
    ArrayList<float[]> lbox = new ArrayList<>();
    boolean landOn = true;
    String landMsg = "";
    boolean tkDirty;
    long lastTkSave;
    double odo, maxSpd, gsLat = 999, gsLon;
    long movT, stopT, totT, blUntil, lastOff;
    static final int[] BTS = {0, 15, 30, 60, 120};
    static final String[] BTN = {"Stays On", "15 Seconds", "30 Seconds", "1 Minute", "2 Minutes"};
    static final String[] BPN = {"Key and Message", "Message Only", "Off"};
    static final String[] DFN = {"Degrees", "Cardinal", "Mils"};
    static final String[] LFN = {"hddd.ddddd", "hddd mm.mmm", "hddd mm ss.s", "UTM", "Maidenhead"};
    static final String[] NRN = {"Auto (Mag)", "True"};
    static final int[] OFD = {50, 100, 200, 500, 1000};
    static final String[] TABS = {"Gen", "Time", "Units", "Loc", "Alarm"};
    static final String[] CARD = {"N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE", "S", "SSW", "SW", "WSW", "W", "WNW", "NW", "NNW"};
    static class Trk { String n; ArrayList<double[]> p = new ArrayList<>(); boolean show; }
    ArrayList<Trk> saved = new ArrayList<>();
    ToneGenerator tg;
    String manName = "";
    char[] ml = new char[8], mo = new char[9];
    int mc;
    double trip;
    String msg = "";
    Ui ui;
    ArrayList<Wp> wps = new ArrayList<>();
    ArrayList<double[]> tk = new ArrayList<>();
    int sn;
    int[] sid = new int[0];
    float[] saz = new float[0], sel = new float[0], scn = new float[0];
    boolean[] sus = new boolean[0];
    Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    Canvas c;
    SharedPreferences sp;
    Handler h = new Handler(Looper.getMainLooper());
    Runnable tickR = new Runnable() { public void run() { tick(); invalidate(); h.postDelayed(this, 1000); } };
    // smooth display position (interpolated between the last GPS fixes) and last known position
    double slat, slon, lpLa, lpLo;
    boolean haveLast;
    long lastPosSave;
    long[] hT = new long[4];
    double[] hLa = new double[4], hLo = new double[4];
    int hN;
    Runnable animR = new Runnable() { public void run() { animStep(); h.postDelayed(this, 33); } };

    public GpsView(Context x) {
        super(x);
        P.setTypeface(Typeface.MONOSPACE);
        sp = x.getSharedPreferences("g72", 0);
        un = sp.getInt("un", 0); pf = sp.getInt("pf", 0); con = sp.getInt("con", 6); bl = sp.getBoolean("bl", true);
        bto = sp.getInt("bto", 0); bp = sp.getInt("beep2", 1); dfm = sp.getInt("dfm", 0); nr = sp.getInt("nr", 0); lf = sp.getInt("lf", 1); ofi = sp.getInt("ofi", 1);
        t24 = sp.getBoolean("t24", true); eleFt = sp.getBoolean("eleFt", false); ofc = sp.getBoolean("ofc", false); arrAl = sp.getBoolean("arr", true);
        hdgLn = sp.getBoolean("hdg", true); accC = sp.getBoolean("acc", true); mapOri = sp.getInt("mori", 0); gridOn = sp.getBoolean("grid", true); tideInt = sp.getInt("tint", 180); ari = sp.getInt("ari", 1); tideRng = sp.getFloat("trng", 2.0f); tz = sp.getFloat("tz", 99); odo = sp.getFloat("odo", 0);
        loadTracks();
        File lf0 = new File(x.getFilesDir(), "land.json");
        if (lf0.exists()) loadLand(lf0); else if (!sp.getBoolean("landCleared", false)) installLand(lf0);
        loadLog();
        wpDir = new File(Environment.getExternalStorageDirectory(), folderName() + "/waypoints");
        loadWps();
        if (sp.contains("pLa")) {
            lat = Double.longBitsToDouble(sp.getLong("pLa", 0)); lon = Double.longBitsToDouble(sp.getLong("pLo", 0));
            alt = Double.longBitsToDouble(sp.getLong("pAl", 0));
            lpLa = lat; lpLo = lon; haveLast = true;
        }
        slat = lat; slon = lon;
        if (wps.isEmpty()) restoreWps();
        lastWps = wpsStr();
        backupWps();
        go = sp.getInt("go", -1);
        if (go >= wps.size()) go = -1;
        gsLat = Double.longBitsToDouble(sp.getLong("gsLat", Double.doubleToLongBits(999)));
        gsLon = Double.longBitsToDouble(sp.getLong("gsLon", 0));
        goSaved = go;
        on = true; t0 = System.currentTimeMillis(); relight(); // power on automatically
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        h.removeCallbacks(tickR);
        h.postDelayed(tickR, 1000);
        h.removeCallbacks(animR);
        h.postDelayed(animR, 33);
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        h.removeCallbacks(tickR);
        h.removeCallbacks(animR);
        if (tg != null) { tg.release(); tg = null; }
    }

    void save() {
        String ws = wpsStr();
        if (!ws.equals(lastWps)) { lastWps = ws; backupWps(); }
        sp.edit().putInt("un", un).putInt("pf", pf).putInt("con", con).putBoolean("bl", bl).putString("wps2", ws).putInt("bto", bto).putInt("beep2", bp).putInt("dfm", dfm).putInt("nr", nr).putInt("lf", lf).putInt("ofi", ofi).putBoolean("t24", t24).putBoolean("eleFt", eleFt).putBoolean("ofc", ofc).putBoolean("arr", arrAl).putBoolean("hdg", hdgLn).putBoolean("acc", accC).putInt("mori", mapOri).putFloat("tz", tz).putFloat("odo", (float) odo)
                .putBoolean("grid", gridOn).putInt("ari", ari).putInt("tint", tideInt).putFloat("trng", tideRng).putInt("go", go).putLong("gsLat", Double.doubleToLongBits(gsLat)).putLong("gsLon", Double.doubleToLongBits(gsLon)).apply();
    }

    String san(String s) { return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' '); }

    /** Tab separated: name, lat, lon, ele, category, description, timestamp. */
    String wpsStr() {
        StringBuilder b = new StringBuilder();
        for (Wp w : wps) b.append(san(w.n)).append('\t').append(w.la).append('\t').append(w.lo).append('\t').append(Double.isNaN(w.ele) ? "" : "" + w.ele).append('\t').append(san(w.cat)).append('\t').append(san(w.desc)).append('\t').append(w.ts).append('\n');
        return b.toString();
    }

    void loadWps() {
        wps.clear();
        String s2 = sp.getString("wps2", null);
        if (s2 != null) {
            for (String ln : s2.split("\n")) {
                if (ln.isEmpty()) continue;
                try {
                    String[] a = ln.split("\t", -1);
                    Wp w = new Wp(a[0], Double.parseDouble(a[1]), Double.parseDouble(a[2]));
                    if (a.length > 3 && !a[3].isEmpty()) w.ele = Double.parseDouble(a[3]);
                    if (a.length > 4) w.cat = a[4];
                    if (a.length > 5) w.desc = a[5];
                    if (a.length > 6 && !a[6].isEmpty()) w.ts = Long.parseLong(a[6]);
                    wps.add(w);
                } catch (Exception e) { /* skip one bad entry */ }
            }
        } else {
            for (String s : sp.getString("wps", "").split(";")) {
                if (s.isEmpty()) continue;
                try {
                    String[] a = s.split(",");
                    wps.add(new Wp(a[0], Double.parseDouble(a[1]), Double.parseDouble(a[2])));
                } catch (Exception e) { }
            }
        }
    }

    /** Folder name = app label with only safe characters, e.g. "GPS 72 12" (differs per build). */
    String folderName() {
        try {
            String l = getContext().getApplicationInfo().loadLabel(getContext().getPackageManager()).toString().replaceAll("[^A-Za-z0-9 _.-]", "").trim();
            return l.isEmpty() ? "GPS72" : l;
        } catch (Exception e) { return "GPS72"; }
    }

    /** Downloads/<app name>/waypoints/ (Android 10+, no permission needed). */
    String pubRel() { return "Download/" + folderName() + "/waypoints/"; }

    android.net.Uri findPublic(android.content.ContentResolver cr, String rel) {
        android.net.Uri col = android.provider.MediaStore.Files.getContentUri("external");
        android.net.Uri uri = null;
        android.database.Cursor q = cr.query(col, new String[]{android.provider.MediaStore.MediaColumns._ID},
                android.provider.MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + android.provider.MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                new String[]{"waypoints.gpx", rel}, null);
        if (q != null) {
            if (q.moveToFirst()) uri = android.content.ContentUris.withAppendedId(col, q.getLong(0));
            q.close();
        }
        return uri;
    }

    /** Primary location: <storage root>/<app name>/waypoints (needs all-files access on Android 11+). */
    public File wpDir;

    String readAll(java.io.InputStream in) throws Exception {
        java.io.BufferedReader r = new java.io.BufferedReader(new InputStreamReader(in, "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String ln;
        while ((ln = r.readLine()) != null) sb.append(ln).append('\n');
        r.close();
        return sb.toString();
    }

    /** Writes the root-storage file; falls back to Download/<app name>/waypoints when the root is not writable. */
    void backupWps() {
        final String gpx = Gpx.build(wps, new ArrayList<double[]>(), new ArrayList<Trk>());
        final Context cx = getContext();
        final String rel = pubRel();
        final File d = wpDir;
        new Thread(new Runnable() {
            public void run() {
                boolean ok = false;
                if (d != null) {
                    try {
                        d.mkdirs();
                        java.io.FileOutputStream o = new java.io.FileOutputStream(new File(d, "waypoints.gpx"));
                        o.write(gpx.getBytes("UTF-8"));
                        o.close();
                        ok = true;
                    } catch (Exception e) { }
                }
                if (ok || Build.VERSION.SDK_INT < 29) return;
                try {
                    android.content.ContentResolver cr = cx.getContentResolver();
                    android.net.Uri uri = findPublic(cr, rel);
                    if (uri == null) {
                        android.content.ContentValues v = new android.content.ContentValues();
                        v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "waypoints.gpx");
                        v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/gpx+xml");
                        v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, rel);
                        uri = cr.insert(android.provider.MediaStore.Files.getContentUri("external"), v);
                    }
                    if (uri == null) return;
                    java.io.OutputStream o = cr.openOutputStream(uri, "wt");
                    o.write(gpx.getBytes("UTF-8"));
                    o.close();
                } catch (Exception e) { }
            }
        }).start();
    }

    public void syncGpx() { backupWps(); }

    void restoreWps() {
        try {
            if (wpDir != null) {
                File f = new File(wpDir, "waypoints.gpx");
                if (f.exists()) { wps.addAll(Gpx.parseWaypoints(readAll(new FileInputStream(f)))); return; }
            }
        } catch (Exception e) { }
        if (Build.VERSION.SDK_INT < 29) return;
        try {
            android.content.ContentResolver cr = getContext().getContentResolver();
            android.net.Uri uri = findPublic(cr, pubRel());
            if (uri != null) wps.addAll(Gpx.parseWaypoints(readAll(cr.openInputStream(uri))));
        } catch (Exception e) { }
    }

    // ---------- data in ----------
    public void onLoc(Location l) {
        if (SystemClock.elapsedRealtimeNanos() - l.getElapsedRealtimeNanos() > 20000000000L) return; // stale fix
        long now = System.currentTimeMillis();
        boolean g = "gps".equals(l.getProvider()) || ("fused".equals(l.getProvider()) && l.getAccuracy() < 12);
        if (!g && now - lastGps < 15000) return;
        if (g) lastGps = now;
        fromGps = g;
        double nla = l.getLatitude(), nlo = l.getLongitude();
        if (lastFix > 0 && now - lastFix < 5000) {
            double d0 = dist(lat, lon, nla, nlo);
            boolean still = l.hasSpeed() ? l.getSpeed() < 0.5f : d0 < l.getAccuracy() * 0.7;
            if (still && d0 < Math.max(10, l.getAccuracy() * 1.5)) { nla = lat; nlo = lon; }
        }
        lat = nla; lon = nlo;
        haveLast = true;
        if (hN > 0 && Math.abs(hLa[hN - 1] - lat) < 1e-9 && Math.abs(hLo[hN - 1] - lon) < 1e-9) hT[hN - 1] = now;
        else {
            if (hN == hT.length) { for (int q = 1; q < hN; q++) { hT[q - 1] = hT[q]; hLa[q - 1] = hLa[q]; hLo[q - 1] = hLo[q]; } hN--; }
            hT[hN] = now; hLa[hN] = lat; hLo[hN] = lon; hN++;
        }
        if (now - lastPosSave > 30000 || dist(lpLa, lpLo, lat, lon) > 25) {
            lastPosSave = now; lpLa = lat; lpLo = lon;
            sp.edit().putLong("pLa", Double.doubleToRawLongBits(lat)).putLong("pLo", Double.doubleToRawLongBits(lon)).putLong("pAl", Double.doubleToRawLongBits(alt)).apply();
        }
        hasAlt = l.hasAltitude();
        if (hasAlt) alt = (Build.VERSION.SDK_INT >= 34 && l.hasMslAltitude()) ? l.getMslAltitudeMeters() : l.getAltitude(); // MSL, not ellipsoid
        acc = l.getAccuracy(); spd = l.hasSpeed() ? l.getSpeed() : 0; lastFix = now; gerr = 0;
        if (l.hasBearing() && spd > 1.5f) { gBrg = l.getBearing(); gBrgT = now; }
        updHdg();
        double[] last = tk.isEmpty() ? null : tk.get(tk.size() - 1);
        double th = Math.max(4, Math.min(acc, 30) * 0.5); // ignore GPS jitter when accuracy is poor
        if (last == null || dist(last[0], last[1], lat, lon) > th) {
            if (last != null) { double dd = dist(last[0], last[1], lat, lon); if (dd < 2000) { trip += dd; odo += dd; } if (++ptc % 10 == 0) sp.edit().putFloat("odo", (float) odo).apply(); }
            tk.add(new double[]{lat, lon});
            tkDirty = true;
            if (tk.size() > 5000) tk.remove(0);
        }
        if (go >= 0 && go < wps.size() && dist(lat, lon, wps.get(go).la, wps.get(go).lo) < arriveR()) {
            if (arrAl) alarm("Arriving at Destination"); go = -1;
        }
        postInvalidate();
    }

    static final int[] ARD = {3, 5, 10, 15, 25};

    /** Arrival radius in meters: depends only on the Setup value, never on map zoom. */
    double arriveR() { return ARD[ari]; }

    public void setCompass(float hd) {
        float d = ((hd - cmp + 540) % 360) - 180;
        cmp = cmpT == 0 ? hd : (cmp + d * 0.25f + 360) % 360;
        cmpT = System.currentTimeMillis();
        updHdg();
        postInvalidate();
    }

    /** Moving fast: trust GPS course; otherwise use the compass. */
    void updHdg() {
        long now = System.currentTimeMillis();
        if (spd > 1.5f && now - gBrgT < 3000) trk = gBrg;
        else if (cmpT > 0) trk = cmp;
    }

    /** Keeps only tracked satellites, strongest/used first, at most 24. */
    public void setSats(int n, final int[] id, float[] az, float[] el, final float[] cn, final boolean[] us) {
        ArrayList<Integer> ix = new ArrayList<>();
        for (int i = 0; i < n; i++) if (us[i] || cn[i] > 0) ix.add(i);
        java.util.Collections.sort(ix, new java.util.Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                if (us[a] != us[b]) return us[a] ? -1 : 1;
                return Float.compare(cn[b], cn[a]);
            }
        });
        int m = Math.min(ix.size(), 24);
        int[] i2 = new int[m];
        float[] a2 = new float[m], e2 = new float[m], c2 = new float[m];
        boolean[] u2 = new boolean[m];
        for (int k = 0; k < m; k++) {
            int j = ix.get(k);
            i2[k] = id[j]; a2[k] = az[j]; e2[k] = el[j]; c2[k] = cn[j]; u2[k] = us[j];
        }
        sn = m; sid = i2; saz = a2; sel = e2; scn = c2; sus = u2; postInvalidate();
    }

    void toast(String s) { msg = s; mt = System.currentTimeMillis() + 2000; postInvalidate(); }

    // ---------- helpers ----------
    static double dist(double a, double b, double c, double d) { return Geo.dist(a, b, c, d); }
    static double brg(double a, double b, double c, double d) { return Geo.brg(a, b, c, d); }
    int fix() { return !on ? 0 : (System.currentTimeMillis() - lastFix < (fromGps ? 10000 : 60000) && lastFix > 0) ? (hasAlt ? 3 : 2) : 0; }
    String fmi(double m) { double mi = m / 1609.344; return String.format(Locale.US, mi < 10 ? "%.2f mi" : "%.1f mi", mi); }

    String fd(double m) {
        if (un == 0) return m < 1000 ? String.format(Locale.US, "%.0fm", m) : String.format(Locale.US, m < 10000 ? "%.2fkm" : "%.1fkm", m / 1000);
        double f = m * 3.281;
        if (un == 1) return f < 1000 ? String.format(Locale.US, "%.0fft", f) : String.format(Locale.US, "%.2fmi", m / 1609.34);
        return m < 185 ? String.format(Locale.US, "%.0fft", f) : String.format(Locale.US, "%.2fnm", m / 1852);
    }
    String fs(double v) { return un == 0 ? String.format(Locale.US, "%.1fkm/h", v * 3.6) : un == 1 ? String.format(Locale.US, "%.1fmph", v * 2.237) : String.format(Locale.US, "%.1fkt", v * 1.944); }
    String fa(double m) { return !eleFt ? String.format(Locale.US, "%.0fm", m) : String.format(Locale.US, "%.0fft", m * 3.281); }
    String fl(double v, boolean la) {
        if (lastFix == 0 && !haveLast) return "-----";
        if (lf == 3) { String[] u = utm(lat, lon); return la ? u[0] : u[1]; }
        if (lf == 4) return la ? mh(lat, lon) : "";
        return fx(v, la);
    }
    String fx(double v, boolean la) {
        String hh = la ? (v >= 0 ? "N" : "S") : (v >= 0 ? "E" : "W");
        double a = Math.abs(v);
        int d = (int) a;
        String dd = String.format(Locale.US, la ? "%02d" : "%03d", d);
        if (lf == 0) return hh + " " + String.format(Locale.US, "%.5f", a) + "\u00B0";
        if (lf == 2) { double mn = (a - d) * 60; int m2 = (int) mn; return hh + " " + dd + "\u00B0" + String.format(Locale.US, "%02d'%04.1f\"", m2, (mn - m2) * 60); }
        return hh + " " + dd + "\u00B0" + String.format(Locale.US, "%06.3f", (a - d) * 60) + "'";
    }
    String ete() {
        if (go < 0 || go >= wps.size() || spd < 0.3) return "--:--:--";
        int s = (int) (dist(lat, lon, wps.get(go).la, wps.get(go).lo) / spd);
        return String.format(Locale.US, "%02d:%02d:%02d", s / 3600, s / 60 % 60, s % 60);
    }
    int ia() { return ((int) (255 * (0.4 + con * 0.06))) << 24; }
    void ink() { P.setColor(ia() | 0x14200C); }
    void bgc() { P.setColor(lit() ? 0xFFA9CC7E : 0xFF93A578); }
    void T(String s, float x, float y, float z, int al, boolean b) {
        P.setStyle(Paint.Style.FILL); P.setTextSize(z); P.setFakeBoldText(b);
        P.setTextAlign(al == 0 ? Paint.Align.LEFT : al == 1 ? Paint.Align.CENTER : Paint.Align.RIGHT);
        c.drawText(s, x, y + z * 0.8f, P);
    }
    void fr(float x, float y, float w, float hh) { P.setStyle(Paint.Style.FILL); c.drawRect(x, y, x + w, y + hh, P); }
    void sr(float x, float y, float w, float hh) { P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1); c.drawRect(x, y, x + w, y + hh, P); }
    void ln(float a, float b, float x, float y) { P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1); c.drawLine(a, b, x, y, P); }
    void circ(float x, float y, float r) { P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1); c.drawCircle(x, y, r, P); }
    void row(int i, String s, boolean sel, float y0) {
        float y = y0 + i * 20;
        if (sel) { fr(2, y, 156, 18); bgc(); T(s, 6, y + 4, 11, L, false); ink(); } else T(s, 6, y + 4, 11, L, false);
    }
    void animStep() {
        if (!on || hN == 0 || page == 0 || page == 4) return;
        long now = System.currentTimeMillis();
        double nla, nlo;
        if (hN < 2) { nla = hLa[hN - 1]; nlo = hLo[hN - 1]; }
        else {
            long dlt = Math.max(400, Math.min(2000, hT[hN - 1] - hT[hN - 2]));
            long tr = now - dlt;
            if (tr >= hT[hN - 1]) { nla = hLa[hN - 1]; nlo = hLo[hN - 1]; }
            else if (tr <= hT[0]) { nla = hLa[0]; nlo = hLo[0]; }
            else {
                int i = hN - 1;
                while (i > 0 && hT[i - 1] > tr) i--;
                long span = hT[i] - hT[i - 1];
                double fr = span <= 0 ? 1 : (double) (tr - hT[i - 1]) / span;
                nla = hLa[i - 1] + (hLa[i] - hLa[i - 1]) * fr; nlo = hLo[i - 1] + (hLo[i] - hLo[i - 1]) * fr;
            }
        }
        if (dist(slat, slon, nla, nlo) > 300) { slat = nla; slon = nlo; }   // big jump: no gliding
        else { slat += (nla - slat) * 0.5; slon += (nlo - slon) * 0.5; }
        postInvalidate();
    }

    float[] proj(double la, double lo) {
        double p = 60.0 / ZM[zi];
        double cla = pan ? pcLat : slat, clo = pan ? pcLon : slon;
        double dx = (lo - clo) * Math.cos(Math.toRadians(cla)) * 111320, dy = (la - cla) * 110540;
        if (mapOri == 1) { double t = Math.toRadians(trk), x2 = dx * Math.cos(t) - dy * Math.sin(t), y2 = dx * Math.sin(t) + dy * Math.cos(t); dx = x2; dy = y2; }
        return new float[]{(float) (80 + dx * p), (float) (125 - dy * p)};
    }

    // ---------- batch 1 features ----------
    boolean lit() { return bl && (bto == 0 || System.currentTimeMillis() < blUntil); }
    void relight() { if (bl && bto > 0) blUntil = System.currentTimeMillis() + BTS[bto] * 1000L; }
    void beep(boolean key) {
        if (bp == 2 || (key && bp == 1)) return;
        try { if (tg == null) tg = new ToneGenerator(AudioManager.STREAM_SYSTEM, 60); tg.startTone(ToneGenerator.TONE_PROP_BEEP, key ? 40 : 250); } catch (Exception e) { }
    }
    void alarm(String m) { toast(m); beep(false); }
    void tick() {
        if (tkDirty && System.currentTimeMillis() - lastTkSave > 20000) { persistLog(); lastTkSave = System.currentTimeMillis(); }
        if (go != goSaved) { goSaved = go; save(); }
        if (!on) return;
        long now = System.currentTimeMillis();
        int f = fix();
        if (f > 0) { totT++; if (spd > 0.5) { movT++; if (spd > maxSpd) maxSpd = spd; } else stopT++; }
        if (lastFix > 0 && f == 0 && !lostMsg) { alarm("Lost Satellite Reception"); lostMsg = true; }
        if (f > 0) lostMsg = false;
        if (ofc && f > 0 && go >= 0 && go < wps.size() && Math.abs(xtk()) > OFD[ofi] && now - lastOff > 30000) { alarm("Off Course"); lastOff = now; }
    }
    double xtk() {
        if (go < 0 || go >= wps.size() || gsLat > 900) return 0;
        Wp w = wps.get(go);
        double b1 = Math.toRadians(brg(gsLat, gsLon, w.la, w.lo)), b13 = Math.toRadians(brg(gsLat, gsLon, lat, lon)), d13 = dist(gsLat, gsLon, lat, lon) / 6371000.0;
        return Math.asin(Math.sin(d13) * Math.sin(b13 - b1)) * 6371000.0;
    }
    String dirS(double t) {
        double d = nr == 1 ? t : t - decl;
        d = ((d % 360) + 360) % 360;
        if (dfm == 1) return CARD[(int) Math.round(d / 22.5) % 16];
        if (dfm == 2) return String.format(Locale.US, "%dmil", (int) Math.round(d * 6400 / 360) % 6400);
        return String.format(Locale.US, "%d\u00B0", (int) Math.round(d) % 360);
    }
    TimeZone tzone() {
        if (tz > 90) return TimeZone.getDefault();
        int m = Math.round(tz * 60);
        return TimeZone.getTimeZone(String.format(Locale.US, "GMT%s%02d:%02d", m < 0 ? "-" : "+", Math.abs(m) / 60, Math.abs(m) % 60));
    }
    String hm(long ms, boolean sec) {
        SimpleDateFormat f = new SimpleDateFormat(t24 ? (sec ? "HH:mm:ss" : "HH:mm") : (sec ? "hh:mm:ss a" : "hh:mm a"), Locale.US);
        f.setTimeZone(tzone()); return f.format(new Date(ms));
    }
    String dt(long ms) { SimpleDateFormat f = new SimpleDateFormat("dd MMM yyyy", Locale.US); f.setTimeZone(tzone()); return f.format(new Date(ms)); }
    String coord(double la, double lo) {
        if (lf == 3) { String[] u = utm(la, lo); return u[0] + " " + u[1]; }
        if (lf == 4) return mh(la, lo);
        return fx(la, true) + " " + fx(lo, false);
    }
    void wrow(int i, Wp w, boolean sel, String pre) {
        float y = 16 + i * 29;
        if (sel) { fr(1, y, 158, 28); bgc(); }
        T(pre + w.n, 4, y + 2, 10, L, true);
        if (pre.isEmpty()) { double d = dist(lat, lon, w.la, w.lo); T(lastFix > 0 || haveLast ? fd(d) + " " + sec(d) : "-----", 157, y + 3, 8, R, false); }
        T(coord(w.la, w.lo), 157, y + 16, 7, R, false);
        if (sel) ink();
    }
    String[] utm(double a, double b) { return Geo.utm(a, b); }
    String mh(double a, double b) { return Geo.maidenhead(a, b); }
    long[] sunTimes() { return lastFix == 0 ? new long[]{-1, -1} : Geo.sunTimes(lat, lon, System.currentTimeMillis()); }
    double[] moonInfo() { return Geo.moon(System.currentTimeMillis()); }
    String phaseName(double a) { return Geo.phaseName(a); }
    String gpxText() { return Gpx.build(wps, tk, saved); }
    String hms(long s) { return String.format(Locale.US, "%d:%02d:%02d", s / 3600, s / 60 % 60, s % 60); }
    double tlen(Trk t) { double d = 0; for (int i = 1; i < t.p.size(); i++) d += dist(t.p.get(i - 1)[0], t.p.get(i - 1)[1], t.p.get(i)[0], t.p.get(i)[1]); return d; }
    void saveTracks() {
        StringBuilder b = new StringBuilder();
        for (Trk t : saved) { b.append(t.n).append('~').append(t.show ? 1 : 0).append('~'); for (double[] q : t.p) b.append(String.format(Locale.US, "%.5f,%.5f;", q[0], q[1])); b.append('|'); }
        sp.edit().putString("trk", b.toString()).apply();
    }
    void loadTracks() {
        try {
            for (String s : sp.getString("trk", "").split("\\|")) {
                if (s.isEmpty()) continue;
                String[] a = s.split("~", 3);
                Trk t = new Trk(); t.n = a[0]; t.show = a[1].equals("1");
                for (String q : a[2].split(";")) { if (q.isEmpty()) continue; String[] c2 = q.split(","); t.p.add(new double[]{Double.parseDouble(c2[0]), Double.parseDouble(c2[1])}); }
                saved.add(t);
            }
        } catch (Exception e) { saved.clear(); }
    }
    void saveLog() {
        if (tk.size() < 2) { toast("Track log empty"); return; }
        if (saved.size() >= 10) { toast("Track memory full"); return; }
        Trk t = new Trk(); t.n = new SimpleDateFormat("MMdd-HHmm", Locale.US).format(new Date()); t.show = true;
        int st = Math.max(1, tk.size() / 1500);
        for (int i = 0; i < tk.size(); i += st) t.p.add(tk.get(i));
        saved.add(t); saveTracks(); toast("Track saved");
    }
    void restoreDefaults() { ari = 1; mapOri = 0; bto = 0; bp = 1; con = 6; t24 = true; tz = 99; eleFt = false; un = 0; dfm = 0; lf = 1; nr = 0; ofc = false; ofi = 1; arrAl = true; save(); toast("Defaults restored"); }
    void menuAct(int i) {
        if (i == 0) sub = 1; else if (i == 1) { sub = 2; ts = 0; } else if (i == 2) { scanFolder(); ui = new Ui(); ui.t = 1; ui.m = 1; }
        else if (i == 3) startManual();
        else if (i == 4) { if (scanReq != null) scanReq.run(); }
        else if (i == 5) { sub = 3; celTab = 0; } else if (i == 6) { sub = 4; tb = 0; si = -1; } else if (i == 7) sub = 5;
        else if (i == 8) { clearLog(); toast("Track cleared"); } else if (i == 9) { go = -1; toast("GOTO stopped"); }
        save();
    }
    static final int[] LC = {0, 2, 3, 5, 6, 8, 9, 10};
    static final int[] OC = {0, 2, 3, 4, 6, 7, 9, 10, 11};
    void startManual() {
        sub = 7; mc = 0; editIdx = -1; manDesc = ""; manCat = "";
        manName = String.format(Locale.US, "WPT%03d", wps.size() + 1);
        double la = lastFix > 0 ? lat : 0, lo = lastFix > 0 ? lon : 0;
        ml = dm(Math.abs(la), 2, la < 0 ? 'S' : 'N');
        mo = dm(Math.abs(lo), 3, lo < 0 ? 'W' : 'E');
    }
    char[] dm(double a, int dd, char h) {
        int d = (int) a;
        String m = String.format(Locale.US, "%06.3f", (a - d) * 60);
        if (m.startsWith("60")) { d++; m = "00.000"; }
        return (h + String.format(Locale.US, dd == 2 ? "%02d" : "%03d", d) + m.replace(".", "")).toCharArray();
    }
    void manualKey(String k, int dy) {
        int tot = 8 + 9;
        if (k.equals("left")) mc = (mc + tot - 1) % tot;
        else if (k.equals("right")) mc = (mc + 1) % tot;
        else if (dy != 0) {
            if (mc < 8) {
                if (mc == 0) ml[0] = ml[0] == 'N' ? 'S' : 'N'; else ml[mc] = (char) ('0' + ((ml[mc] - '0') - dy + 10) % 10);
            } else {
                int j = mc - 8;
                if (j == 0) mo[0] = mo[0] == 'E' ? 'W' : 'E'; else mo[j] = (char) ('0' + ((mo[j] - '0') - dy + 10) % 10);
            }
        } else if (k.equals("enter")) {
            double mla = Double.parseDouble(new String(ml, 3, 2) + "." + new String(ml, 5, 3));
            double mlo = Double.parseDouble(new String(mo, 4, 2) + "." + new String(mo, 6, 3));
            double la = Double.parseDouble(new String(ml, 1, 2)) + mla / 60.0;
            double lo = Double.parseDouble(new String(mo, 1, 3)) + mlo / 60.0;
            if (ml[0] == 'S') la = -la;
            if (mo[0] == 'W') lo = -lo;
            if (mla >= 60 || mlo >= 60 || Math.abs(la) > 90 || Math.abs(lo) > 180) { toast("Invalid coordinates"); return; }
            String nm = manName.replaceAll("[,;|~]", " ");
            if (editIdx >= 0 && editIdx < wps.size()) {
                Wp ew = wps.get(editIdx);
                ew.n = nm; ew.la = la; ew.lo = lo; ew.desc = manDesc; ew.cat = manCat;
                int ix = editIdx; editIdx = -1; save(); sub = 0; reopenList(ix); toast("Updated " + nm);
            } else {
                Wp nw = new Wp(nm, la, lo);
                nw.desc = manDesc; nw.cat = manCat;
                wps.add(nw); editIdx = -1; save(); sub = 0; toast("Saved " + nm);
            }
        }
    }
    void drawManual() {
        T(editIdx >= 0 ? "EDIT WAYPOINT" : "NEW WAYPOINT", 80, 3, 10, C, true);
        T("Name  (MENU = options)", 4, 18, 8, L, false); T(manName, 4, 29, 14, L, true);
        T("Latitude", 4, 52, 8, L, false); T("Longitude", 4, 88, 8, L, false);
        for (int j = 0; j < 8; j++) mch(j, "" + ml[j], 4 + LC[j] * 11, 62);
        T("\u00B0", 4 + 4 * 11, 62, 13, L, true); T(".", 4 + 7 * 11, 62, 13, L, true); T("'", 4 + 11 * 11, 62, 13, L, true);
        for (int j = 0; j < 9; j++) mch(8 + j, "" + mo[j], 4 + OC[j] * 11, 98);
        T("\u00B0", 4 + 5 * 11, 98, 13, L, true); T(".", 4 + 8 * 11, 98, 13, L, true); T("'", 4 + 12 * 11, 98, 13, L, true);
        T("Cat: " + (manCat.isEmpty() ? "-" : manCat), 4, 126, 8, L, false);
        T("Desc: " + (manDesc.length() > 22 ? manDesc.substring(0, 22) + ".." : manDesc), 4, 138, 8, L, false);
        T("DDD\u00B0MM.mmm' (WGS84)", 80, 160, 8, C, false);
        T("\u25B2\u25BC change  \u25C4\u25BA move", 80, 188, 8, C, false); T("ENTER = save  QUIT = cancel", 80, 202, 8, C, false);
    }
    void mch(int idx, String ch, float x, float y) {
        if (idx == mc) { fr(x - 1, y - 1, 11, 17); bgc(); T(ch, x, y, 13, L, true); ink(); } else T(ch, x, y, 13, L, true);
    }
    String[] setupRows() {
        long now = System.currentTimeMillis();
        switch (tb) {
            case 0: return new String[]{"Backlight: " + BTN[bto], "Beeper: " + BPN[bp], "Contrast: " + con, "Map: " + (mapOri == 1 ? "Track Up (turns)" : "North Up (fixed)")};
            case 1: return new String[]{"Format: " + (t24 ? "24 Hour" : "12 Hour"), "Zone: " + (tz > 90 ? "Auto" : String.format(Locale.US, "UTC%+.1f", tz)), "Time: " + hm(now, true), "Date: " + dt(now)};
            case 2: return new String[]{"Elev: " + (eleFt ? "Feet" : "Meters"), "Dist: " + UN[un], "Dir: " + DFN[dfm]};
            case 3: return new String[]{"Fmt: " + LFN[lf], "North: " + NRN[nr], String.format(Locale.US, "MagVar: %.1f\u00B0", decl)};
            default: return new String[]{"Off Course: " + (ofc ? "On" : "Off"), "Dist: " + fd(OFD[ofi]), "Arrival: " + (arrAl ? "On" : "Off"), "Arrive Dist: " + fd(ARD[ari])};
        }
    }
    void setupAct(int d) {
        if (tb == 0) { if (si == 0) bto = (bto + d + 5) % 5; else if (si == 1) bp = (bp + d + 3) % 3; else if (si == 2) con = Math.max(0, Math.min(10, con + d)); else if (si == 3) mapOri ^= 1; }
        else if (tb == 1) { if (si == 0) t24 = !t24; else if (si == 1) { tz = tz > 90 ? (d > 0 ? -12 : 14) : tz + 0.5f * d; if (tz > 14 || tz < -12) tz = 99; } }
        else if (tb == 2) { if (si == 0) eleFt = !eleFt; else if (si == 1) un = (un + d + 3) % 3; else if (si == 2) dfm = (dfm + d + 3) % 3; }
        else if (tb == 3) { if (si == 0) lf = (lf + d + 5) % 5; else if (si == 1) nr = (nr + 1) % 2; }
        else { if (si == 0) ofc = !ofc; else if (si == 1) ofi = (ofi + d + 5) % 5; else if (si == 2) arrAl = !arrAl; else if (si == 3) ari = (ari + d + 5) % 5; }
        relight(); save();
    }
    void subKey(String k, int dy) {
        if (k.equals("page")) { sub = 0; editIdx = -1; page = (page + 1) % 5; return; }
        if (k.equals("quit")) {
            if (sub == 7 && editIdx >= 0) { int ix = editIdx; editIdx = -1; sub = 0; reopenList(ix); return; }
            sub = sub == 6 ? 2 : 0; return;
        }
        if (k.equals("menu") && sub == 7) { ui = new Ui(); ui.t = 3; ui.m = 6; return; }
        if (k.equals("menu")) {
            if (sub == 3) { celTab ^= 1; return; }
            if (sub == 1 || sub == 2 || sub == 4 || sub == 6) { ui = new Ui(); ui.t = 3; ui.m = sub == 1 ? 1 : sub == 2 ? 2 : sub == 4 ? 3 : 4; }
            return;
        }
        if (sub == 3) { tideKey(k, dy); return; }
        if (sub == 2) {
            int n = 2 + saved.size();
            if (dy != 0) ts = Math.max(0, Math.min(n - 1, ts + dy));
            else if (k.equals("enter")) { if (ts == 0) saveLog(); else if (ts == 1) { clearLog(); toast("Track log cleared"); } else { tsel = ts - 2; sub = 6; } }
        } else if (sub == 6) {
            if (k.equals("enter") && tsel < saved.size()) { saved.get(tsel).show = !saved.get(tsel).show; saveTracks(); }
        } else if (sub == 7) {
            manualKey(k, dy);
        } else if (sub == 4) {
            int n = setupRows().length;
            if (dy != 0) si = Math.max(-1, Math.min(n - 1, si + dy));
            else if (k.equals("left") || k.equals("right")) { if (si == -1) tb = (tb + (k.equals("left") ? 4 : 1)) % 5; else setupAct(k.equals("left") ? -1 : 1); }
            else if (k.equals("enter") && si >= 0) setupAct(1);
        }
    }
    String[] optItems() {
        switch (ui.m) {
            case 0:
                if (page == 0) return new String[]{"Orientation: " + (satUp ? "Track Up" : "North Up")};
                return new String[]{"Orientation: " + (mapOri == 1 ? "Track Up" : "North Up"), "Land: " + (landOn ? "On " : "Off ") + landMsg, "Load Land File", "Clear Land File", "Grid: " + (gridOn ? "On" : "Off"), "Download Coast..."};
            case 1: return new String[]{"Reset Trip", "Reset Max Speed", "Reset Odometer"};
            case 2: return new String[]{"Delete Saved Track", "Delete All Tracks", "Export GPX"};
            case 3: return new String[]{"Restore Defaults"};
            case 10: return new String[]{"Around me: 20 km", "Around me: 50 km", "Around me: 150 km", "Around me: 300 km"};
            case 6: return new String[]{"Name...", "Description...", "Category: " + (manCat.isEmpty() ? "-" : manCat)};
            case 7: return new String[]{"Share Single Waypoint", "Share Multiple Waypoints", "Share All Waypoints"};
            default: return new String[]{"Delete Track"};
        }
    }
    void optKey(String k, int dy) {
        String[] o = optItems();
        if (k.equals("menu")) { if (ui.m == 0) { ui = null; page = 4; } else ui = null; return; }
        if (dy != 0) ui.sel = Math.max(0, Math.min(o.length - 1, ui.sel + dy));
        else if (k.equals("enter")) optAct(ui.sel);
    }
    void optAct(int i) {
        int m = ui.m;
        if (m == 0) {
            if (page == 0) satUp = !satUp; else if (i == 0) mapOri ^= 1; else if (i == 1) landOn = !landOn;
            else if (i == 2) { ui = null; if (loadLandReq != null) loadLandReq.run(); }
            else if (i == 4) gridOn = !gridOn;
            else if (i == 5) { ui = new Ui(); ui.t = 3; ui.m = 10; return; }
            else { lpoly = new ArrayList<>(); lbox = new ArrayList<>(); lline = new ArrayList<>(); llbox = new ArrayList<>(); landMsg = ""; new File(getContext().getFilesDir(), "land.json").delete(); sp.edit().putBoolean("landCleared", true).apply(); }
            save(); return;
        }
        if (m == 6) { manOpt(i); return; }
        if (m == 7) { shareOpt(i); return; }
        if (m == 10) { ui = null; downloadCoast(new double[]{20, 50, 150, 300}[i]); return; }
        ui = null;
        if (m == 1) { if (i == 0) { trip = 0; movT = 0; stopT = 0; totT = 0; toast("Trip reset"); } else if (i == 1) { maxSpd = 0; toast("Max speed reset"); } else { odo = 0; toast("Odometer reset"); } persistLog(); save(); }
        else if (m == 2) { if (i == 0 && ts >= 2 && ts - 2 < saved.size()) { saved.remove(ts - 2); ts = Math.max(0, ts - 1); } else if (i == 1) { saved.clear(); ts = 0; } else if (i == 2 && exportReq != null) exportReq.run(); saveTracks(); }
        else if (m == 3) restoreDefaults();
        else { if (tsel < saved.size()) saved.remove(tsel); saveTracks(); sub = 2; ts = 0; }
    }
    void drawOpts() {
        T("OPTIONS", 80, 3, 10, C, true);
        String[] o = optItems();
        for (int i = 0; i < o.length; i++) row(i, o[i], i == ui.sel, 22);
        if (ui.m == 10) { T("Needs internet (once).", 80, 190, 8, C, false); T("Then saved for offline use.", 80, 202, 8, C, false); }
        T("ENTER select  MENU:" + (ui.m == 0 ? "main" : "close"), 80, 222, 8, C, false);
    }
    void drawMenu() {
        if (sub == 1) { drawTrip(); return; }
        if (sub == 2) { drawTracks(); return; }
        if (sub == 3) { drawSun(); return; }
        if (sub == 4) { drawSetup(); return; }
        if (sub == 5) { drawSys(); return; }
        if (sub == 6) { drawTInfo(); return; }
        if (sub == 7) { drawManual(); return; }
        T("MAIN MENU", 80, 3, 10, C, true);
        String[] it = {"Trip Computer", "Tracks", "Waypoints (" + wps.size() + ")", "New Waypoint", "Scan QR Code", "Sun & Moon", "Setup", "System Info", "Clear Track", "Stop GOTO"};
        for (int i = 0; i < it.length; i++) row2(i, it[i], i == ms, 14, 19);
        T("ENTER select", 80, 208, 8, C, false); T("Garmin GPS 72  v" + ver, 80, 222, 8, C, false);
    }
    void drawTrip() {
        T("TRIP COMPUTER", 80, 2, 9, C, true);
        String[] lb = {"Trip Odom", "Stopped Time", "Moving Avg", "Moving Time", "Overall Avg", "Total Time", "Max Speed", "Odometer"};
        String[] v = {fd(trip), hms(stopT), fs(movT > 0 ? trip / movT : 0), hms(movT), fs(totT > 0 ? trip / totT : 0), hms(totT), fs(maxSpd), fd(odo)};
        String[] v2 = {sec(trip), "", ss(movT > 0 ? trip / movT : 0), "", ss(totT > 0 ? trip / totT : 0), "", ss(maxSpd), sec(odo)};
        for (int i = 0; i < 8; i++) { float x = 4 + (i % 2) * 80, y = 18 + (i / 2) * 50; T(lb[i], x, y, 8, L, false); T(v[i], x, y + 12, v[i].length() > 8 ? 10 : 12, L, true); T(v2[i], x, y + 27, 8, L, false); }
        T("MENU: reset options", 80, 224, 8, C, false);
    }
    void drawTracks() {
        T("TRACKS", 80, 2, 10, C, true);
        T("Log: " + tk.size() + " pts  " + fd(trip), 80, 15, 8, C, false);
        int n = 2 + saved.size(), o = Math.max(0, Math.min(ts - 3, n - 8));
        for (int i = o; i < Math.min(n, o + 8); i++) row(i - o, i == 0 ? "Save Log" : i == 1 ? "Clear Log" : saved.get(i - 2).n + " " + fd(tlen(saved.get(i - 2))), i == ts, 26);
        T("MENU: options", 80, 224, 8, C, false);
    }
    void drawTInfo() {
        T("TRACK INFO", 80, 3, 10, C, true);
        if (tsel >= saved.size()) return;
        Trk t = saved.get(tsel);
        T("Name", 4, 24, 8, L, false); T(t.n, 4, 34, 12, L, true);
        T("Distance", 4, 58, 8, L, false); T(fd(tlen(t)), 4, 68, 12, L, true);
        T("Points", 4, 92, 8, L, false); T("" + t.p.size(), 4, 102, 12, L, true);
        T("Show on Map: " + (t.show ? "[X]" : "[ ]"), 4, 130, 10, L, true);
        T("ENTER: toggle  MENU: delete", 80, 222, 8, C, false);
    }
    void drawSun() {
        if (celTab == 1) { drawTide(); return; }
        T("SUN & MOON", 80, 3, 10, C, true);
        long now = System.currentTimeMillis();
        T(dt(now), 80, 18, 9, C, false);
        long[] s = sunTimes();
        T("Sunrise  " + (s[0] < 0 ? "--:--" : hm(s[0], false)), 4, 40, 11, L, true);
        T("Sunset   " + (s[1] < 0 ? "--:--" : hm(s[1], false)), 4, 58, 11, L, true);
        if (s[0] >= 0) { long dl = (s[1] - s[0]) / 60000; T(String.format(Locale.US, "Day %dh %02dm", dl / 60, dl % 60), 4, 76, 10, L, false); }
        double[] m = moonInfo();
        P.setStyle(Paint.Style.FILL); P.setAlpha((int) (40 + 215 * m[1])); c.drawCircle(80, 128, 24, P); ink(); circ(80, 128, 24);
        T(phaseName(m[0]), 80, 160, 11, C, true);
        T(String.format(Locale.US, "Age %.1f d   %d%% lit", m[0], (int) Math.round(m[1] * 100)), 80, 176, 9, C, false);
        if (lastFix == 0) T("Waiting for GPS location", 80, 206, 8, C, false);
        T("MENU: Tides", 80, 224, 8, C, false);
    }
    // ---------- tides (estimate from the moon, calibrated by the user) ----------
    static final double LUNAR_DAY_H = 24.8412;

    /** Tide height in meters relative to mean level: semidiurnal lunar tide, spring/neap from the moon phase. */
    double tideH(long t) {
        double days = t / 86400000.0, jd = days + 2440587.5, syn = 29.530588853;
        double e = 2 * Math.PI * ((((jd - 2451550.1) % syn) + syn) % syn) / syn;      // moon elongation
        double hm = 2 * Math.PI * (days + lon / 360.0 - 0.5) - e;                    // moon hour angle
        double lag = 2 * Math.PI * (tideInt / 60.0) / LUNAR_DAY_H;                    // moon transit -> high water
        return tideRng / 2 * (1 + 0.25 * Math.cos(2 * e)) * Math.cos(2 * (hm - lag));
    }

    String fh(double m) { return eleFt ? String.format(Locale.US, "%+.1fft", m * 3.281) : String.format(Locale.US, "%+.1fm", m); }

    void tideKey(String k, int dy) {
        if (celTab != 1) return;
        if (dy != 0) { tdi = Math.max(0, Math.min(1, tdi + dy)); return; }
        int d = k.equals("left") ? -1 : k.equals("right") ? 1 : 0;
        if (d == 0) return;
        if (tdi == 0) tideInt = (tideInt + d * 5 + 745) % 745;
        else tideRng = Math.max(0.1f, Math.min(15f, Math.round((tideRng + d * 0.1f) * 10) / 10f));
        save();
    }

    void drawTide() {
        T("TIDES (estimate)", 80, 3, 9, C, true);
        row(0, String.format(Locale.US, "HW after moon: %dh%02dm", tideInt / 60, tideInt % 60), tdi == 0, 16);
        row(1, "Range: " + (eleFt ? String.format(Locale.US, "%.1fft", tideRng * 3.281) : String.format(Locale.US, "%.1fm", tideRng)), tdi == 1, 16);
        if (lastFix == 0) T("Waiting for GPS location", 80, 100, 9, C, false);
        else {
            long now = System.currentTimeMillis();
            double h = tideH(now), h2 = tideH(now + 60000);
            T("Now " + fh(h) + (h2 > h ? "  Rising" : "  Falling"), 4, 62, 10, L, true);
            long hw = -1, lw = -1;
            double hwH = 0, lwH = 0, prev2 = tideH(now), prev = tideH(now + 300000);
            for (long t = now + 600000; t < now + 26 * 3600000L && (hw < 0 || lw < 0); t += 300000) {
                double cur = tideH(t);
                if (hw < 0 && prev > prev2 && prev >= cur) { hw = t - 300000; hwH = prev; }
                if (lw < 0 && prev < prev2 && prev <= cur) { lw = t - 300000; lwH = prev; }
                prev2 = prev; prev = cur;
            }
            T("HW " + (hw < 0 ? "--:--" : hm(hw, false) + " " + fh(hwH)), 4, 76, 10, L, false);
            T("LW " + (lw < 0 ? "--:--" : hm(lw, false) + " " + fh(lwH)), 4, 90, 10, L, false);
            float gx = 6, gw = 148, cy = 150, amp = 38;
            long t0 = now - 3 * 3600000L;
            double mx = Math.max(0.05, tideRng / 2 * 1.25);
            sr(gx, cy - amp - 4, gw, 2 * amp + 8);
            P.setPathEffect(new DashPathEffect(new float[]{2, 3}, 0)); ln(gx, cy, gx + gw, cy); P.setPathEffect(null);
            Path pa = new Path();
            for (int i = 0; i <= 96; i++) {
                float x = gx + gw * i / 96f, y = (float) (cy - tideH(t0 + i * 900000L) / mx * amp);
                if (i == 0) pa.moveTo(x, y); else pa.lineTo(x, y);
            }
            P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1); c.drawPath(pa, P);
            float nx = gx + gw * 3f / 24f;
            ln(nx, cy - amp - 4, nx, cy + amp + 4);
            P.setStyle(Paint.Style.FILL); c.drawCircle(nx, (float) (cy - h / mx * amp), 3, P);
            T(hm(t0, false), gx, cy + amp + 6, 7, L, false);
            T(hm(t0 + 24 * 3600000L, false), gx + gw, cy + amp + 6, 7, R, false);
        }
        T("\u25B2\u25BC select  \u25C4\u25BA change", 80, 210, 8, C, false);
        T("MENU: Sun&Moon  QUIT: back", 80, 222, 8, C, false);
    }

    void drawSetup() {
        T("SETUP", 80, 1, 8, C, false);
        for (int i = 0; i < 5; i++) {
            float x = 2 + i * 31.5f;
            if (i == tb) { fr(x, 12, 30, 14); bgc(); T(TABS[i], x + 15, 15, 8, C, false); ink(); } else { sr(x, 12, 30, 14); T(TABS[i], x + 15, 15, 8, C, false); }
        }
        if (si == -1) fr(2, 28, 156, 2);
        String[] r = setupRows();
        for (int i = 0; i < r.length; i++) row(i, r[i], i == si, 34);
        T("\u25C4 \u25BA change  MENU: defaults", 80, 224, 8, C, false);
    }
    void drawSys() {
        T("SYSTEM INFO", 80, 3, 10, C, true);
        int u = 0; for (boolean b : sus) if (b) u++;
        T("GPS 72 (Android)", 4, 28, 11, L, true); T("Software v" + ver, 4, 46, 10, L, false);
        T("Unit ID " + String.format(Locale.US, "%08X", (Build.MODEL + Build.DEVICE).hashCode()), 4, 62, 10, L, false);
        T("Satellites: " + sn + "  Used: " + u, 4, 82, 10, L, false); T("Android " + Build.VERSION.RELEASE, 4, 98, 10, L, false);
    }

    // ---------- second units + offline land ----------
    String sec(double m) {
        if (un == 0) { double f = m * 3.281; return f < 1000 ? String.format(Locale.US, "%.0fft", f) : String.format(Locale.US, m / 1609.34 < 10 ? "%.2fmi" : "%.1fmi", m / 1609.34); }
        return m < 1000 ? String.format(Locale.US, "%.0fm", m) : String.format(Locale.US, m < 10000 ? "%.2fkm" : "%.1fkm", m / 1000);
    }
    String ss(double v) { return un == 0 ? String.format(Locale.US, "%.1fmph", v * 2.237) : String.format(Locale.US, "%.1fkm/h", v * 3.6); }
    /** Copies the bundled Natural Earth 1:50m land outline (assets/land.json) and loads it. */
    void installLand(final File lf) {
        final Context cx = getContext();
        new Thread(new Runnable() {
            public void run() {
                try {
                    java.io.InputStream in = cx.getAssets().open("land.json");
                    java.io.FileOutputStream o = new java.io.FileOutputStream(lf);
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
                    o.close();
                    in.close();
                    post(new Runnable() { public void run() { loadLand(lf); } });
                } catch (Exception e) { }
            }
        }).start();
    }

    public void loadLand(final File file) {
        sp.edit().putBoolean("landCleared", false).apply();
        landMsg = "loading..."; postInvalidate();
        new Thread(new Runnable() {
            public void run() {
                final ArrayList<ArrayList<float[]>> np = new ArrayList<>();
                final ArrayList<float[]> nb = new ArrayList<>(), nl = new ArrayList<>(), nlb = new ArrayList<>();
                String msg;
                try {
                    JsonReader r = new JsonReader(new InputStreamReader(new BufferedInputStream(new FileInputStream(file), 65536), "UTF-8"));
                    LandData.readGeo(r, np, nb, nl, nlb);
                    r.close();
                    msg = np.size() > 0 ? np.size() + " polys" : nl.size() + " lines";
                } catch (Throwable e) { np.clear(); nb.clear(); nl.clear(); nlb.clear(); msg = "file error"; }
                final String m2 = msg;
                post(new Runnable() { public void run() { lpoly = np; lbox = nb; lline = nl; llbox = nlb; landMsg = m2; invalidate(); } });
            }
        }).start();
    }
    static final double[] GS = {1 / 3600.0, 2 / 3600.0, 5 / 3600.0, 10 / 3600.0, 30 / 3600.0, 1 / 60.0, 2 / 60.0, 5 / 60.0, 10 / 60.0, 30 / 60.0, 1, 2, 5, 10, 30};

    /** Lat/lon graticule; the equator and the prime meridian are drawn heavier and labelled. */
    void drawGrid() {
        final double lat = pan ? pcLat : this.slat, lon = pan ? pcLon : this.slon;
        double p = 60.0 / ZM[zi], cl = Math.max(0.05, Math.cos(Math.toRadians(lat)));
        double step = GS[GS.length - 1];
        for (double g : GS) if (g * Geo.M_PER_DEG_LAT * p >= 45) { step = g; break; }
        double rr = 200.0 / p, dLa = rr / Geo.M_PER_DEG_LAT, dLo = rr / (Geo.M_PER_DEG_LON * cl);
        long k0 = (long) Math.floor((lat - dLa) / step);
        for (long k = k0; k * step <= lat + dLa && k - k0 < 40; k++) {
            double v = k * step;
            if (Math.abs(v) > 90) continue;
            float[] a = proj(v, lon - dLo), b = proj(v, lon + dLo);
            gridLine(a, b, k == 0);
            if (k == 0) { float[] q = proj(0, lon); ink(); T("EQ", q[0] + 3, q[1] - 9, 7, L, false); }
        }
        k0 = (long) Math.floor((lon - dLo) / step);
        for (long k = k0; k * step <= lon + dLo && k - k0 < 40; k++) {
            double v = k * step;
            float[] a = proj(lat - dLa, v), b = proj(lat + dLa, v);
            gridLine(a, b, k == 0);
            if (k == 0) { float[] q = proj(lat, 0); ink(); T("0\u00B0", q[0] + 3, q[1] + 2, 7, L, false); }
        }
        ink();
    }

    void gridLine(float[] a, float[] b, boolean strong) {
        P.setStyle(Paint.Style.STROKE);
        if (strong) { ink(); P.setStrokeWidth(1.6f); } else { P.setColor((0x50 << 24) | 0x14200C); P.setStrokeWidth(0.8f); }
        c.drawLine(a[0], a[1], b[0], b[1], P);
        P.setStrokeWidth(1);
    }

    void drawLand() {
        final double lat = pan ? pcLat : this.slat, lon = pan ? pcLon : this.slon;
        double p = 60.0 / ZM[zi], cl = Math.max(0.05, Math.cos(Math.toRadians(lat)));
        double rr = 200.0 / p, dLa = rr / 110540, dLo = rr / (111320 * cl), sLa = (1.0 / p) / 110540, sLo = (1.0 / p) / (111320 * cl);
        boolean rot = mapOri == 1;
        double ct = Math.cos(Math.toRadians(trk)), st = Math.sin(Math.toRadians(trk));
        Path path = new Path(); path.setFillType(Path.FillType.EVEN_ODD);
        boolean any = false;
        boolean polys = ZM[zi] >= 500;
        for (int i = 0; polys && i < lpoly.size(); i++) {
            float[] bx = lbox.get(i);
            if (bx[1] < lat - dLa || bx[0] > lat + dLa || bx[3] < lon - dLo || bx[2] > lon + dLo) continue;
            for (float[] ring : lpoly.get(i)) {
                double lastLa = 1e9, lastLo = 1e9; boolean first = true;
                for (int k = 0; k < ring.length; k += 2) {
                    double la = ring[k], lo = ring[k + 1];
                    if (!first && Math.abs(la - lastLa) < sLa && Math.abs(lo - lastLo) < sLo && k < ring.length - 2) continue;
                    lastLa = la; lastLo = lo;
                    double dx = (lo - lon) * cl * 111320, dy = (la - lat) * 110540;
                    if (rot) { double x2 = dx * ct - dy * st, y2 = dx * st + dy * ct; dx = x2; dy = y2; }
                    float x = (float) Math.max(-1e6, Math.min(1e6, 80 + dx * p)), y = (float) Math.max(-1e6, Math.min(1e6, 125 - dy * p));
                    if (first) { path.moveTo(x, y); first = false; } else path.lineTo(x, y);
                }
                if (!first) path.close();
            }
            any = true;
        }
        if (any) {
            P.setStyle(Paint.Style.FILL); P.setColor((56 << 24) | 0x14200C); c.drawPath(path, P);
            ink(); P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1); c.drawPath(path, P);
        }
        drawLines();
    }

    /** Downloaded coastline: thick line with small ticks pointing to the sea side. */
    void drawLines() {
        if (lline.isEmpty()) return;
        final double lat = pan ? pcLat : this.slat, lon = pan ? pcLon : this.slon;
        double p = 60.0 / ZM[zi], cl = Math.max(0.05, Math.cos(Math.toRadians(lat)));
        double rr = 200.0 / p, dLa = rr / 110540, dLo = rr / (111320 * cl), sLa = (0.7 / p) / 110540, sLo = (0.7 / p) / (111320 * cl);
        boolean rot = mapOri == 1;
        double ct = Math.cos(Math.toRadians(trk)), st = Math.sin(Math.toRadians(trk));
        Path path = new Path(), ticks = new Path();
        for (int i = 0; i < lline.size(); i++) {
            float[] bx = llbox.get(i);
            if (bx[1] < lat - dLa || bx[0] > lat + dLa || bx[3] < lon - dLo || bx[2] > lon + dLo) continue;
            float[] a = lline.get(i);
            boolean ori = bx[4] > 0;
            double lastLa = 1e9, lastLo = 1e9;
            float px = 0, py = 0, acc2 = 0;
            boolean first = true;
            for (int k = 0; k < a.length; k += 2) {
                double la = a[k], lo = a[k + 1];
                if (!first && Math.abs(la - lastLa) < sLa && Math.abs(lo - lastLo) < sLo && k < a.length - 2) continue;
                lastLa = la; lastLo = lo;
                double dx = (lo - lon) * cl * 111320, dy = (la - lat) * 110540;
                if (rot) { double x2 = dx * ct - dy * st, y2 = dx * st + dy * ct; dx = x2; dy = y2; }
                float x = (float) Math.max(-1e6, Math.min(1e6, 80 + dx * p)), y = (float) Math.max(-1e6, Math.min(1e6, 125 - dy * p));
                if (first) { path.moveTo(x, y); first = false; }
                else {
                    path.lineTo(x, y);
                    float sx = x - px, sy = y - py, len = (float) Math.sqrt(sx * sx + sy * sy);
                    if (ori && len > 0.5f && Math.abs(px) < 2000 && Math.abs(py) < 2000 && Math.abs(x) < 2000 && Math.abs(y) < 2000) {
                        float ux = sx / len, uy = sy / len, nx = -uy, ny = ux, s0 = 14 - acc2;
                        while (s0 <= len) { float tx = px + ux * s0, ty = py + uy * s0; ticks.moveTo(tx, ty); ticks.lineTo(tx + nx * 5, ty + ny * 5); s0 += 14; }
                        acc2 = len - (s0 - 14);
                    } else acc2 = 0;
                }
                px = x; py = y;
            }
        }
        ink(); P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(2); c.drawPath(path, P);
        P.setStrokeWidth(1); c.drawPath(ticks, P);
    }

    // ---------- persistent track log ----------
    void clearLog() { tk.clear(); tkDirty = true; persistLog(); }
    public void flush() { if (tkDirty) persistLog(); }
    void persistLog() {
        tkDirty = false;
        sp.edit().putFloat("trip", (float) trip).putLong("movT", movT).putLong("stopT", stopT).putLong("totT", totT).putFloat("maxSpd", (float) maxSpd).putFloat("odo", (float) odo).apply();
        final ArrayList<double[]> snap = new ArrayList<>(tk);
        final File file = new File(getContext().getFilesDir(), "tracklog.txt");
        new Thread(new Runnable() {
            public void run() {
                try {
                    java.io.BufferedWriter w = new java.io.BufferedWriter(new java.io.FileWriter(file));
                    for (double[] q : snap) { w.write(String.format(Locale.US, "%.6f,%.6f", q[0], q[1])); w.newLine(); }
                    w.close();
                } catch (Exception e) { }
            }
        }).start();
    }
    void loadLog() {
        trip = sp.getFloat("trip", 0); movT = sp.getLong("movT", 0); stopT = sp.getLong("stopT", 0); totT = sp.getLong("totT", 0); maxSpd = sp.getFloat("maxSpd", 0);
        try {
            java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader(new File(getContext().getFilesDir(), "tracklog.txt")));
            String ln;
            while ((ln = r.readLine()) != null) { String[] a = ln.split(","); if (a.length == 2) tk.add(new double[]{Double.parseDouble(a[0]), Double.parseDouble(a[1])}); }
            r.close();
        } catch (Exception e) { }
    }

    @Override
    protected void onMeasure(int w, int hh) {
        int W = MeasureSpec.getSize(w);
        setMeasuredDimension(W, W * 3 / 2);
    }

    // ---------- drawing ----------
    @Override
    protected void onDraw(Canvas cv) {
        c = cv;
        int W = getWidth(), H = getHeight();
        float sc = Math.min(W / 160f, H / 240f);
        c.save();
        c.translate((W - 160 * sc) / 2, (H - 240 * sc) / 2);
        c.scale(sc, sc);
        c.clipRect(0, 0, 160, 240);
        draw();
        if (on) lcdFx();
        c.restore();
    }

    /** Pixel grid, edge vignette and a soft glass reflection. */
    void lcdFx() {
        P.setPathEffect(null); P.setShader(null);
        P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(0.16f); P.setColor(0x14000000);
        for (int x = 0; x <= 160; x++) c.drawLine(x, 0, x, 240, P);
        for (int y = 0; y <= 240; y++) c.drawLine(0, y, 160, y, P);
        P.setStyle(Paint.Style.FILL);
        P.setShader(new RadialGradient(80, 120, 150, 0x00000000, 0x34000000, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, 160, 240, P);
        P.setShader(new LinearGradient(0, 0, 160, 90, 0x26FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, 160, 90, P);
        P.setShader(null);
    }

    void draw() {
        if (page != 1) pan = false;
        P.setPathEffect(null);
        if (on) bgc(); else P.setColor(0xFF4A4D31);
        P.setStyle(Paint.Style.FILL); c.drawRect(0, 0, 160, 240, P);
        if (!on) return;
        ink();
        int f = fix();
        long now = System.currentTimeMillis();
        if (now - t0 < 2500) {
            T("GARMIN", 80, 70, 24, C, true); T("GPS 72", 80, 104, 18, C, true); T("Hand-held Navigator", 80, 140, 9, C, false);
            return;
        }
        if (page == 0) {
            T("SATELLITE", 80, 2, 8, C, false); T(hm(System.currentTimeMillis(), false), 2, 2, 8, L, false); T(fs(spd), 158, 2, 8, R, false);
            float cx = 80, cy = 70, r = 50;
            circ(cx, cy, r); circ(cx, cy, r / 2); ln(cx - r, cy, cx + r, cy); ln(cx, cy - r, cx, cy + r);
            T("N", cx, cy - r - 10, 8, C, false);
            for (int i = 0; i < sn; i++) {
                float q = (90 - sel[i]) / 90f * r;
                double an = Math.toRadians(saz[i] - (satUp ? trk : 0)); float x = cx + q * (float) Math.sin(an), y = cy - q * (float) Math.cos(an);
                if (sus[i]) { fr(x - 7, y - 5, 14, 10); bgc(); T("" + sid[i], x, y - 4, 8, C, false); ink(); }
                else { sr(x - 7, y - 5, 14, 10); T("" + sid[i], x, y - 4, 8, C, false); }
            }
            int cnt = Math.min(sn, 12);
            for (int i = 0; i < cnt; i++) {
                float x = 6 + i * 12.5f, hh = Math.min(scn[i], 50) * 0.9f;
                if (hh > 1) fr(x, 200 - hh, 9, hh); else fr(x, 199, 9, 1);
                T("" + sid[i], x + 4.5f, 203, 7, C, false);
            }
            fr(4, 196, 152, 1);
            T(f == 0 ? "Acquiring Satellites" : f == 2 ? "2D GPS Location" : "3D GPS Location", 80, 216, 10, C, true);
            T(gerr == 1 ? "Location permission denied" : gerr == 2 ? "GPS is turned off" : f > 0 ? (fromGps ? "REAL GPS  EPE " : "NETWORK  EPE ") + (int) acc + "m" : "Waiting for GPS...", 80, 229, 8, C, false);
        } else if (page == 1) {
            float[] me = proj(slat, slon);
            c.save(); c.clipRect(0, 12, 160, 226);
            if (landOn && ((ZM[zi] >= 500 && !lpoly.isEmpty()) || !lline.isEmpty())) drawLand();
            if (gridOn) drawGrid();
            Path pa = new Path();
            for (int i = 0; i < tk.size(); i++) { float[] q = proj(tk.get(i)[0], tk.get(i)[1]); if (i == 0) pa.moveTo(q[0], q[1]); else pa.lineTo(q[0], q[1]); }
            if (!tk.isEmpty()) { float[] q = proj(slat, slon); pa.lineTo(q[0], q[1]); }
            P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1); P.setPathEffect(new DashPathEffect(new float[]{2, 2}, 0)); c.drawPath(pa, P); P.setPathEffect(null);
            for (Trk t : saved) { if (!t.show) continue; Path sp2 = new Path(); for (int i = 0; i < t.p.size(); i++) { float[] q = proj(t.p.get(i)[0], t.p.get(i)[1]); if (i == 0) sp2.moveTo(q[0], q[1]); else sp2.lineTo(q[0], q[1]); } P.setStyle(Paint.Style.STROKE); c.drawPath(sp2, P); }
            if (go >= 0 && go < wps.size()) { float[] q = proj(wps.get(go).la, wps.get(go).lo); P.setStrokeWidth(2); c.drawLine(me[0], me[1], q[0], q[1], P); P.setStrokeWidth(1); }
            for (int i = 0; i < wps.size(); i++) {
                float[] q = proj(wps.get(i).la, wps.get(i).lo);
                Path d = new Path(); d.moveTo(q[0], q[1] - 5); d.lineTo(q[0] + 5, q[1]); d.lineTo(q[0], q[1] + 5); d.lineTo(q[0] - 5, q[1]); d.close();
                P.setStyle(i == go ? Paint.Style.FILL : Paint.Style.STROKE); c.drawPath(d, P);
                T(wps.get(i).n, q[0] + 7, q[1] - 4, 8, L, false);
            }
            c.save(); c.translate(me[0], me[1]); c.rotate(mapOri == 1 ? 0 : trk);
            Path ar = new Path(); ar.moveTo(0, -8); ar.lineTo(6, 7); ar.lineTo(0, 3); ar.lineTo(-6, 7); ar.close();
            P.setStyle(Paint.Style.FILL); c.drawPath(ar, P); c.restore();
            if (pan) {
                P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1);
                P.setPathEffect(new DashPathEffect(new float[]{3, 2}, 0)); c.drawLine(80, 125, me[0], me[1], P); P.setPathEffect(null);
                c.drawCircle(80, 125, 5, P);
                P.setStyle(Paint.Style.FILL); c.drawCircle(80, 125, 2, P);
                double dp = dist(pcLat, pcLon, lat, lon);
                T(lastFix > 0 || haveLast ? fd(dp) : "---", 88, 100, 8, L, true);
                if (lastFix > 0 || haveLast) T(fmi(dp), 88, 111, 8, L, true);
            }
            c.restore();
            fr(0, 12, 160, 1); T(pan ? "PAN" : mapOri == 1 ? "TRK UP" : "N\u2191", 156, 15, 8, R, false);
            T(pan ? fl(pcLat, true) + " " + fl(pcLon, false) : fl(lat, true) + " " + fl(lon, false), 3, 15, 7, L, false);
            T("SPD " + fs(spd), 3, 24, 8, L, true); T(ss(spd), 3, 33, 8, L, false);
            {
                float ccx = 19, ccy = 56, cr = 13;
                P.setStyle(Paint.Style.FILL); bgc(); P.setAlpha(210); c.drawCircle(ccx, ccy, cr, P);
                ink(); P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1); c.drawCircle(ccx, ccy, cr, P);
                for (int a4 = 0; a4 < 4; a4++) {
                    double g4 = Math.toRadians(a4 * 90 - trk), sx4 = Math.sin(g4), cx4 = -Math.cos(g4);
                    if (a4 == 0) {
                        Path nt = new Path();
                        nt.moveTo((float) (ccx + sx4 * (cr + 2.5)), (float) (ccy + cx4 * (cr + 2.5)));
                        nt.lineTo((float) (ccx + sx4 * (cr - 3) - cx4 * 2.6), (float) (ccy + cx4 * (cr - 3) + sx4 * 2.6));
                        nt.lineTo((float) (ccx + sx4 * (cr - 3) + cx4 * 2.6), (float) (ccy + cx4 * (cr - 3) - sx4 * 2.6));
                        nt.close();
                        P.setStyle(Paint.Style.FILL); c.drawPath(nt, P); P.setStyle(Paint.Style.STROKE);
                    } else ln((float) (ccx + sx4 * (cr - 3)), (float) (ccy + cx4 * (cr - 3)), (float) (ccx + sx4 * cr), (float) (ccy + cx4 * cr));
                }
                Path ht = new Path();
                ht.moveTo(ccx, ccy - cr - 1.5f); ht.lineTo(ccx - 2.5f, ccy - cr - 5.5f); ht.lineTo(ccx + 2.5f, ccy - cr - 5.5f); ht.close();
                P.setStyle(Paint.Style.FILL); c.drawPath(ht, P);
                T(dirS(trk), ccx, ccy - 3.5f, 7, C, true);
            }
            fr(4, 230, 60, 2); fr(4, 227, 1, 5); fr(63, 227, 1, 5); T(fd(ZM[zi]) + " " + sec(ZM[zi]), 68, 226, 7, L, false);
            if (go >= 0 && go < wps.size()) { double dd2 = dist(lat, lon, wps.get(go).la, wps.get(go).lo); T("\u2192" + wps.get(go).n + " " + fd(dd2), 158, 207, 8, R, true); T(sec(dd2), 158, 217, 8, R, false); }
            else if (f == 0) T("NO FIX", 156, 226, 9, R, false);
        } else if (page == 3) {
            T("HIGHWAY", 80, 2, 8, C, false);
            if (go < 0 || go >= wps.size()) { T("No Active GOTO", 80, 100, 11, C, true); T("Press GOTO to select", 80, 120, 9, C, false); }
            else {
                Wp w = wps.get(go);
                double b = brg(lat, lon, w.la, w.lo), d = dist(lat, lon, w.la, w.lo), df = ((b - trk + 540) % 360) - 180;
                T("TO  " + w.n, 4, 14, 11, L, true); T("DST " + fd(d) + " " + sec(d), 4, 30, 11, L, false);
                T("BRG " + dirS(b), 4, 46, 11, L, false); T("ETE " + ete(), 4, 62, 11, L, false); fr(0, 80, 160, 1);
                float vx = (float) (80 + Math.max(-70, Math.min(70, df * 1.6)));
                ln(20, 215, vx - 6, 100); ln(140, 215, vx + 6, 100);
                P.setPathEffect(new DashPathEffect(new float[]{6, 6}, 0)); ln(80, 215, vx, 100); P.setPathEffect(null); fr(0, 100, 160, 1);
                T(Math.abs(df) < 5 ? "ON COURSE" : df > 0 ? "TURN RIGHT " + (int) Math.abs(df) + "\u00B0" : "TURN LEFT " + (int) Math.abs(df) + "\u00B0", 80, 86, 9, C, true);
            }
            fr(0, 218, 160, 1); T("SPD " + fs(spd), 4, 224, 10, L, false); T("TRK " + dirS(trk), 156, 224, 10, R, false);
        } else if (page == 2) {
            T("POINTER", 80, 2, 8, C, false);
            boolean act = go >= 0 && go < wps.size();
            T("SPD " + fs(spd), 4, 12, 9, L, true); T("TRK " + dirS(trk), 156, 12, 9, R, true);
            float cx = 80, cy = 98, r = 42;
            circ(cx, cy, r);
            for (int a = 0; a < 360; a += 30) {
                double g = Math.toRadians(a - trk);
                float sn2 = (float) Math.sin(g), co = (float) -Math.cos(g);
                if (a % 90 == 0) T("" + "NESW".charAt(a / 90), cx + sn2 * (r - 9), cy + co * (r - 9) - 4, 9, C, true);
                else ln(cx + sn2 * (r - 4), cy + co * (r - 4), cx + sn2 * r, cy + co * r);
            }
            Path tr = new Path(); tr.moveTo(cx, cy - r - 6); tr.lineTo(cx + 5, cy - r); tr.lineTo(cx - 5, cy - r); tr.close(); P.setStyle(Paint.Style.FILL); c.drawPath(tr, P);
            if (act) {
                Wp w = wps.get(go);
                double b = brg(lat, lon, w.la, w.lo), d = dist(lat, lon, w.la, w.lo);
                c.save(); c.translate(cx, cy); c.rotate((float) (b - trk));
                Path pp = new Path(); pp.moveTo(0, -r + 6); pp.lineTo(7, 8); pp.lineTo(0, 3); pp.lineTo(-7, 8); pp.close(); P.setStyle(Paint.Style.FILL); c.drawPath(pp, P); c.restore();
                T("TO " + w.n, 4, 144, 10, L, true); T("DST " + fd(d) + " (" + sec(d) + ")", 4, 156, 9, L, false);
                T("BRG " + dirS(b), 4, 168, 10, L, false); T("ETE " + ete(), 84, 168, 10, L, false); T("XTK " + fd(Math.abs(xtk())), 4, 180, 10, L, false);
            } else T("No Active GOTO", 80, 146, 10, C, true);
            fr(0, 192, 160, 1); T(fl(lat, true), 80, 196, 10, C, true); T(fl(lon, false), 80, 210, 10, C, true); T("ALT " + fa(alt), 80, 225, 8, C, false);
        } else {
            drawMenu();
        }
        if (ui != null) {
            bgc(); fr(0, 0, 160, 240); ink();
            if (ui.t == 1) {
                T(ui.m == 1 ? "WAYPOINTS" : "GOTO WAYPOINT", 80, 3, 10, C, true);
                if (wps.isEmpty()) T("No waypoints", 80, 100, 10, C, false);
                int o = Math.max(0, Math.min(ui.sel - 3, wps.size() - 7));
                for (int i = o; i < Math.min(wps.size(), o + 7); i++) wrow(i - o, wps.get(i), i == ui.sel, "");
                T(ui.m == 1 ? "ENTER:OPEN  QUIT:BACK" : "ENTER:GOTO  MENU:EDIT", 80, 222, 8, C, false);
            } else if (ui.t == 2) {
                fr(0, 0, 160, 16); bgc(); T("MARK POSITION", 80, 3, 10, C, true); ink(); T("Name", 80, 44, 9, C, false); T(ui.nm, 80, 56, 16, C, true);
                T(fp(ui.pla, ui.plo, true), 80, 100, 10, C, false); T(fp(ui.pla, ui.plo, false), 80, 114, 10, C, false);
                T("MENU = name keyboard", 80, 170, 9, C, false); T("ENTER = OK   QUIT = CANCEL", 80, 200, 8, C, false);
            } else if (ui.t == 5) drawSel();
            else if (ui.t == 4) drawWpMenu();
            else drawOpts();
        }
        if (now < mt) { ink(); fr(10, 95, 140, 34); bgc(); T(msg, 80, 106, 10, C, true); }
    }

    // ---------- keys ----------
    void pwr() {
        on = !on;
        if (on) { t0 = System.currentTimeMillis(); page = 0; ui = null; sub = 0; relight(); }
        postInvalidate();
    }

    void startGoto(int i) { go = i; gsLat = lat; gsLon = lon; ui = null; page = 1; toast("GOTO " + wps.get(go).n); }
    void wpMenu(int idx) { int lm = ui.m; ui = new Ui(); ui.t = 4; ui.c = idx; ui.lm = lm; }
    void wpList(int lm, int sel) { ui = new Ui(); ui.t = 1; ui.m = lm; ui.sel = Math.max(0, Math.min(sel, wps.size() - 1)); }

    void startEdit(int idx) {
        Wp w = wps.get(idx);
        page = 4; sub = 7; mc = 0; editIdx = idx; manName = w.n; manDesc = w.desc; manCat = w.cat;
        ml = dm(Math.abs(w.la), 2, w.la < 0 ? 'S' : 'N');
        mo = dm(Math.abs(w.lo), 3, w.lo < 0 ? 'W' : 'E');
    }

    void wpMenuKey(String k, int dy) {
        if (ui.c >= wps.size()) { ui = null; return; }
        final int idx = ui.c;
        Wp w = wps.get(idx);
        if (dy != 0) { ui.sel = Math.max(0, Math.min(7, ui.sel + dy)); ui.m = 0; return; }
        if (!k.equals("enter")) return;
        switch (ui.sel) {
            case 0: startGoto(idx); break;
            case 1:
                editName(w.n, new NameKeyboard.Done() {
                    public void ok(String x) {
                        if (idx < wps.size()) { wps.get(idx).n = x.replaceAll("[,;|~]", " "); save(); postInvalidate(); }
                    }
                });
                break;
            case 2: ui = null; startEdit(idx); break;
            case 3:
                if (lastFix == 0) toast("No GPS fix");
                else { w.la = lat; w.lo = lon; if (hasAlt) w.ele = alt; save(); toast("Position updated"); }
                break;
            case 4: wsel = idx; ui = new Ui(); ui.t = 3; ui.m = 7; break;
            case 5:
                if (ui.m != 1) { ui.m = 1; toast("ENTER again to delete"); }
                else {
                    if (go == idx) go = -1; else if (go > idx) go--;
                    wps.remove(idx); save(); toast("Deleted");
                    if (wps.isEmpty()) ui = null; else wpList(ui.lm, idx);
                }
                break;
            case 6:
                if (ui.m != 2) { ui.m = 2; toast("ENTER again: delete ALL"); }
                else { wps.clear(); go = -1; save(); toast("All waypoints deleted"); ui = null; }
                break;
            default:
                ui = null;
                if (importReq != null) importReq.run();
        }
    }

    void drawWpMenu() {
        if (ui.c >= wps.size()) return;
        Wp w = wps.get(ui.c);
        T(w.n, 80, 3, 12, C, true);
        T(coord(w.la, w.lo), 80, 19, 7, C, false);
        if (lastFix > 0) T(fd(dist(lat, lon, w.la, w.lo)) + "  " + dirS(brg(lat, lon, w.la, w.lo)), 80, 30, 8, C, false);
        String[] it = {"Go To", "Rename", "Edit", "Use Current Position", "Share via QR", ui.m == 1 ? "CONFIRM DELETE?" : "Delete", ui.m == 2 ? "CONFIRM DELETE ALL?" : "Delete All", "Import File"};
        for (int i = 0; i < it.length; i++) row(i, it[i], i == ui.sel, 42);
        T("ENTER select  QUIT:BACK", 80, 222, 8, C, false);
    }

    // ---------- coastline download (OpenStreetMap via Overpass, saved for offline use) ----------
    public void downloadCoast(final double km) {
        if (lastFix == 0) { toast("Need a GPS position first"); return; }
        double dLa = km / 110.54, dLo = km / (111.32 * Math.max(0.2, Math.cos(Math.toRadians(lat))));
        final String q = String.format(Locale.US, "[out:json][timeout:90];way[\"natural\"=\"coastline\"](%.4f,%.4f,%.4f,%.4f);out geom;", lat - dLa, lon - dLo, lat + dLa, lon + dLo);
        landMsg = "downloading..."; toast("Downloading coastline..."); postInvalidate();
        final File out = new File(getContext().getFilesDir(), "land.json"), tmp = new File(getContext().getFilesDir(), "land.tmp");
        new Thread(new Runnable() {
            public void run() {
                String[] hosts = {"https://overpass.private.coffee/api/interpreter", "https://overpass-api.de/api/interpreter", "https://maps.mail.ru/osm/tools/overpass/api/interpreter", "https://overpass.osm.jp/api/interpreter"};
                boolean ok = false;
                for (String h0 : hosts) {
                    try {
                        java.net.HttpURLConnection cn = (java.net.HttpURLConnection) new java.net.URL(h0).openConnection();
                        cn.setConnectTimeout(15000); cn.setReadTimeout(120000);
                        cn.setRequestMethod("POST"); cn.setDoOutput(true);
                        cn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                        cn.setRequestProperty("User-Agent", "GPS72-Android/1.0");
                        cn.setRequestProperty("Accept", "*/*");
                        java.io.OutputStream os = cn.getOutputStream();
                        os.write(("data=" + java.net.URLEncoder.encode(q, "UTF-8")).getBytes("UTF-8"));
                        os.close();
                        if (cn.getResponseCode() != 200) continue;
                        java.io.InputStream is = cn.getInputStream();
                        java.io.FileOutputStream fo = new java.io.FileOutputStream(tmp);
                        byte[] bf = new byte[65536]; int n; long tot = 0;
                        while ((n = is.read(bf)) > 0 && tot < 40000000L) { fo.write(bf, 0, n); tot += n; }
                        fo.close(); is.close();
                        if (tmp.length() > 20) { out.delete(); ok = tmp.renameTo(out); if (ok) break; }
                    } catch (Exception e) { }
                }
                final boolean fin = ok;
                post(new Runnable() { public void run() { if (fin) { loadLand(out); toast("Coastline saved (offline)"); } else { landMsg = ""; toast("Download failed"); } } });
            }
        }).start();
    }

    // ---------- import from files ----------
    /** Imports new .gpx / .wpt files found in the waypoints folder (each file is imported only once). */
    public void scanFolder() {
        final ArrayList<File> dirs = new ArrayList<>();
        if (wpDir != null) dirs.add(wpDir);
        File ext = getContext().getExternalFilesDir(null);
        if (ext != null) dirs.add(new File(ext, "waypoints"));
        final java.util.HashSet<String> done = new java.util.HashSet<>(sp.getStringSet("impfiles", new java.util.HashSet<String>()));
        new Thread(new Runnable() {
            public void run() {
                final ArrayList<Wp> found = new ArrayList<>();
                final ArrayList<String> sigs = new ArrayList<>();
                for (File d : dirs) {
                    File[] fl = d.listFiles();
                    if (fl == null) continue;
                    for (File f : fl) {
                        String nm = f.getName().toLowerCase(Locale.US);
                        if (!f.isFile() || nm.equals("waypoints.gpx") || !(nm.endsWith(".gpx") || nm.endsWith(".wpt"))) continue;
                        String sig = f.getAbsolutePath() + "|" + f.length() + "|" + f.lastModified();
                        if (done.contains(sig)) continue;
                        try { found.addAll(WptImport.read(f)); } catch (Exception e) { }
                        sigs.add(sig);
                    }
                }
                if (sigs.isEmpty()) return;
                post(new Runnable() {
                    public void run() {
                        int n = importWps(found);
                        java.util.HashSet<String> all = new java.util.HashSet<>(done);
                        all.addAll(sigs);
                        sp.edit().putStringSet("impfiles", all).apply();
                        if (n > 0) toast("Imported " + n + " waypoint(s) from files");
                    }
                });
            }
        }).start();
    }

    // ---------- import / share (QR) ----------
    boolean isDup(Wp w) {
        for (Wp x : wps) if (x.n.equalsIgnoreCase(w.n) && dist(x.la, x.lo, w.la, w.lo) < 2) return true;
        return false;
    }

    public int importWps(List<Wp> l) {
        int c0 = 0;
        for (Wp w : l) if (!isDup(w)) { wps.add(w); c0++; }
        if (c0 > 0) save();
        postInvalidate();
        return c0;
    }

    void reopenList(int sel) {
        if (wps.isEmpty()) { ui = null; return; }
        ui = new Ui(); ui.t = 1; ui.m = 1; ui.sel = Math.max(0, Math.min(sel, wps.size() - 1));
    }

    void doShare(ArrayList<Wp> l) {
        ui = null;
        if (l.isEmpty()) { toast("No waypoints"); return; }
        if (shareReq != null) shareReq.share(l);
    }

    void shareOpt(int i) {
        if (i == 0) { ArrayList<Wp> l = new ArrayList<>(); if (wsel < wps.size()) l.add(wps.get(wsel)); doShare(l); }
        else if (i == 1) { ui = new Ui(); ui.t = 5; ui.sel = Math.min(wsel, Math.max(0, wps.size() - 1)); ui.chk = new boolean[wps.size()]; }
        else doShare(new ArrayList<>(wps));
    }

    void drawSel() {
        T("SELECT WAYPOINTS", 80, 3, 10, C, true);
        int o = Math.max(0, Math.min(ui.sel - 3, wps.size() - 7));
        for (int i = o; i < Math.min(wps.size(), o + 7); i++) wrow(i - o, wps.get(i), i == ui.sel, ui.chk[i] ? "[x] " : "[ ] ");
        T("ENTER:tick  MENU:share", 80, 222, 8, C, false);
    }

    void selKey(String k, int dy) {
        int n = wps.size();
        if (dy != 0) ui.sel = Math.max(0, Math.min(n - 1, ui.sel + dy));
        else if (k.equals("enter") && n > 0) ui.chk[ui.sel] = !ui.chk[ui.sel];
        else if (k.equals("menu")) {
            ArrayList<Wp> l = new ArrayList<>();
            for (int i = 0; i < n; i++) if (ui.chk[i]) l.add(wps.get(i));
            if (l.isEmpty()) { toast("Select at least one"); return; }
            doShare(l);
        }
    }

    void manOpt(int i) {
        if (i == 0) { ui = null; editName(manName, new NameKeyboard.Done() { public void ok(String x) { manName = x; postInvalidate(); } }); }
        else if (i == 1) {
            ui = null;
            try { new NameKeyboard(getContext(), manDesc, 80, new NameKeyboard.Done() { public void ok(String x) { manDesc = san(x); postInvalidate(); } }).show(); } catch (Exception e) { }
        } else {
            int k = 0;
            for (int j = 0; j < CATS.length; j++) if (CATS[j].equals(manCat)) k = j;
            manCat = CATS[(k + 1) % CATS.length];
        }
    }

    void row2(int i, String s, boolean sel, float y0, float pitch) {
        float y = y0 + i * pitch;
        if (sel) { fr(2, y, 156, pitch - 2); bgc(); T(s, 6, y + 3, 11, L, false); ink(); } else T(s, 6, y + 3, 11, L, false);
    }

    void markAt(String n, double la, double lo, boolean here) {
        Wp w = new Wp(n.replaceAll("[,;|~]", " "), la, lo);
        if (here && hasAlt) w.ele = alt;
        wps.add(w); save();
    }
    String fp(double la, double lo, boolean isLat) {
        if (lf == 3) { String[] u = utm(la, lo); return isLat ? u[0] : u[1]; }
        if (lf == 4) return isLat ? mh(la, lo) : "";
        return fx(isLat ? la : lo, isLat);
    }
    void mark(String n) { Wp w = new Wp(n.replaceAll("[,;|~]", " "), lat, lon); if (hasAlt) w.ele = alt; wps.add(w); save(); }
    void editName(String init, NameKeyboard.Done d) { try { new NameKeyboard(getContext(), init, d).show(); } catch (Exception e) { } }

    /** Moves the pan cursor by about 12 screen pixels, in screen directions. */
    void panMove(String k) {
        double m = 12.0 * ZM[zi] / 60.0;
        double x2 = k.equals("left") ? -m : k.equals("right") ? m : 0, y2 = k.equals("up") ? m : k.equals("down") ? -m : 0;
        double t = mapOri == 1 ? Math.toRadians(trk) : 0;
        double dx = x2 * Math.cos(t) + y2 * Math.sin(t), dy = -x2 * Math.sin(t) + y2 * Math.cos(t);
        pcLat = Math.max(-85, Math.min(85, pcLat + dy / Geo.M_PER_DEG_LAT));
        pcLon += dx / (Geo.M_PER_DEG_LON * Math.max(0.05, Math.cos(Math.toRadians(pcLat))));
        if (pcLon > 180) pcLon -= 360;
        if (pcLon < -180) pcLon += 360;
    }

    public void press(String k, boolean lg) {
        if (k.equals("light") && lg) { pwr(); return; }
        if (!on) return;
        beep(true);
        if (System.currentTimeMillis() - t0 < 2500) t0 = 0;
        if (k.equals("light")) { bl = !lit(); relight(); save(); postInvalidate(); return; }
        relight();
        int dy = k.equals("up") ? -1 : k.equals("down") ? 1 : 0;
        if (ui != null) {
            if (k.equals("quit")) { if (ui.t == 4) wpList(ui.lm, ui.c); else ui = null; }
            else if (ui.t == 1) {
                int n = wps.size();
                if (dy != 0) ui.sel = Math.max(0, Math.min(n - 1, ui.sel + dy));
                else if (k.equals("enter") && n > 0) { if (ui.m == 1) wpMenu(ui.sel); else startGoto(ui.sel); }
                else if (k.equals("menu") && ui.m == 0 && n > 0) wpMenu(ui.sel);
            } else if (ui.t == 5) { selKey(k, dy);
            } else if (ui.t == 4) { wpMenuKey(k, dy);
            } else if (ui.t == 3) { optKey(k, dy);
            } else {
                if (k.equals("menu")) editName(ui.nm, new NameKeyboard.Done() { public void ok(String x) { if (ui != null) { ui.nm = x; postInvalidate(); } } });
                else if (k.equals("enter")) { String nm = ui.nm; markAt(nm, ui.pla, ui.plo, ui.atPos); ui = null; toast("Saved " + nm); }
            }
            postInvalidate(); return;
        }
        if (sub != 0) { subKey(k, dy); postInvalidate(); return; }
        if (k.equals("page")) page = (page + 1) % 5;
        else if (k.equals("quit")) page = (page + 4) % 5;
        else if (k.equals("menu")) {
            if (page == 4) page = 1;
            else if (page == 0 || page == 1) { ui = new Ui(); ui.t = 3; ui.m = 0; }
            else page = 4;
        } else if (k.equals("zin") && (page == 1 || page == 3)) zi = Math.max(0, zi - 1);
        else if (k.equals("zout") && (page == 1 || page == 3)) zi = Math.min(ZM.length - 1, zi + 1);
        else if (k.equals("pan")) {
            if (page != 1) { page = 1; pan = true; pcLat = lat; pcLon = lon; }
            else { pan = !pan; if (pan) { pcLat = lat; pcLon = lon; } }
        } else if (pan && page == 1 && (k.equals("up") || k.equals("down") || k.equals("left") || k.equals("right"))) panMove(k);
        else if (k.equals("goto")) {
            if (lg) {
                if (lastFix == 0) { toast("No GPS fix"); return; }
                mark("MOB"); go = wps.size() - 1; gsLat = lat; gsLon = lon; page = 1; toast("MOB - GOTO active");
            } else if (wps.isEmpty()) toast("No waypoints");
            else { ui = new Ui(); ui.t = 1; ui.m = 0; ui.sel = Math.max(0, go); }
        } else if (k.equals("enter")) {
            if (lg) {
                boolean atPan = page == 1 && pan;
                if (!atPan && lastFix == 0) { toast("No GPS fix"); return; }
                ui = new Ui(); ui.t = 2; ui.nm = String.format(Locale.US, "WPT%03d", wps.size() + 1);
                ui.pla = atPan ? pcLat : lat; ui.plo = atPan ? pcLon : lon; ui.atPos = !atPan;
            } else if (page == 4) menuAct(ms);
        } else if (page == 4) {
            if (dy != 0) ms = (ms + dy + 10) % 10;
        }
        postInvalidate();
    }
}
