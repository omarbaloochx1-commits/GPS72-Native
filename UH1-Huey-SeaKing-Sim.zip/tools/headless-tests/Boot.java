package com.hueysim.uh1;

public class Boot {
    public static Sim huey() { Terrain.setMap(Terrain.VALLEY); Sim s = new Sim(Aircraft.get(Aircraft.HUEY)); s.setup(0, 22, 3.5, 780, 150); return s; }
    public static Sim seaKing() { Terrain.setMap(Terrain.COAST); Sim s = new Sim(Aircraft.get(Aircraft.SEAKING)); s.setup(0, 18, 3.0, 3000, 300); return s; }

    static void run(Sim s, double sec) { for (int i = 0; i < (int) (sec * 60); i++) s.step(1.0 / 60); }
    public static Sim ready() {
        Sim s = huey();
        s.batt = true; s.fuelMain = true; s.fuelStart = true; s.inverter = true; run(s, 1);
        s.starterBtn = true; while (s.n1 < 15) run(s, 0.1);
        s.throttle = 0.15; while (s.n1 < 40) run(s, 0.1);
        s.starterBtn = false; run(s, 14);
        s.gen = true; s.hyd = true; s.fuelStart = false; run(s, 2); s.throttle = 1.0; run(s, 40);
        return s;
    }
}
