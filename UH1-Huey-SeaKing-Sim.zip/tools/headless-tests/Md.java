package com.hueysim.uh1;

public class Md {
    public static void main(String[] a) throws Exception {
        for (int lang = 0; lang < 2; lang++) {
            boolean fa = lang == 1;
            StringBuilder b = new StringBuilder();
            b.append(fa ? "# دفترچه راهنمای شبیه‌ساز هلیکوپتر (UH-1H Huey + Sea King)\n\n" : "# Helicopter Simulator (UH-1H Huey + Sea King) - Operating Manual\n\n");
            for (int i = 0; i < Manual.pages(); i++) {
                String[] pg = Manual.page(fa, i);
                b.append("## ").append(pg[0]).append("\n\n");
                for (int k = 1; k < pg.length; k++) b.append(pg[k]).append("\n\n");
            }
            b.append(fa ? "# ماموریت‌ها\n\n" : "# Missions\n\n");
            for (Mission.Def d : Mission.DEFS) {
                b.append("## ").append(d.id + 1).append(". ").append(fa ? d.titleFa : d.titleEn).append(" - ").append(Aircraft.get(d.aircraft).name).append("\n\n");
                for (String s : (fa ? d.briefFa : d.briefEn)) b.append(s).append("\n\n");
                b.append(fa ? d.weatherFa : d.weatherEn).append("\n\n");
                int n = 1;
                for (Mission.Step st : d.steps) {
                    b.append(n++).append(". ").append(fa ? st.fa : st.en).append("\n\n   ").append(fa ? st.hFa : st.hEn).append("\n\n");
                }
            }
            java.nio.file.Files.write(java.nio.file.Paths.get("docs/" + (fa ? "MANUAL_FA.md" : "MANUAL_EN.md")), b.toString().getBytes("UTF-8"));
        }
    }
}
