package com.hueysim.uh1;

public class T7 {
    static void run(Sim s, double sec) { for (int i = 0; i < (int) (sec * 60); i++) s.step(1.0 / 60); }
    static void p(Sim s, String t) {
        System.out.printf("%-24s t=%5.1f nr=%5.1f | E1 n1=%5.1f egt=%4.0f tq=%5.1f lit=%b | E2 n1=%5.1f egt=%4.0f tq=%5.1f lit=%b | fuel=%4.0f busV=%4.1f%n", t, s.time, s.nr,
                s.eng[0].n1, s.eng[0].egt, s.eng[0].torque, s.eng[0].lit, s.eng[1].n1, s.eng[1].egt, s.eng[1].torque, s.eng[1].lit, s.fuelLb, s.busV);
    }
    public static void main(String[] a) {
        Sim s = Boot.seaKing();
        s.batt = true; s.inverter = true; s.throttle = 0.15; run(s, 1);
        // engine 1
        s.starterBtn = true; while (s.eng[0].n1 < 15) run(s, 0.1);
        s.fuelMain = true; p(s, "E1 cock at 15 %");
        while (s.eng[0].n1 < 40) run(s, 0.1);
        s.starterBtn = false; run(s, 14); p(s, "E1 idle");
        // engine 2
        s.starter2 = true; while (s.eng[1].n1 < 15) run(s, 0.1);
        s.fuel2 = true; p(s, "E2 cock at 15 %");
        while (s.eng[1].n1 < 40) run(s, 0.1);
        s.starter2 = false; run(s, 14); p(s, "E2 idle");
        s.gen = true; s.gen2 = true; s.hyd = true; run(s, 2);
        s.throttle = 1.0; for (int i = 0; i < 8; i++) { run(s, 4); p(s, "spool"); }
        boolean anyLight = false; for (boolean l : s.light) anyLight |= l;
        System.out.println("any caution light: " + anyLight + " mass=" + s.massKg());
        for (double c = 0.30; c < 0.9; c += 0.05) {
            s.collective = c; run(s, 2);
            System.out.printf("coll %.2f thrust/weight=%.3f vz=%.2f agl=%.1f tq1=%.0f%% tq2=%.0f%% nr=%.1f onGround=%b%n", c, s.thrustN / (s.massKg() * Sim.G), s.vz, s.agl, s.eng[0].torque, s.eng[1].torque, s.nr, s.onGround);
            if (!s.onGround) break;
        }
        // gear up + cruise + OEI test from presets
        Sim k = Boot.seaKing(); k.presetAirborne(120, 40);
        run(k, 5);
        System.out.printf("Sea King cruise: ias=%.0f kt agl=%.0f vz=%.1f nr=%.1f tq=%.0f%%/%.0f%% fuelflow=%.0f lb/h%n", k.ias, k.agl, k.vz, k.nr, k.eng[0].torque, k.eng[1].torque, k.fuelFlow);
        k.failEngine(1); run(k, 3);
        System.out.printf("after engine 2 failure (3 s): nr=%.1f tq1=%.0f%% vz=%.1f ias=%.0f lights E2fail=%b%n", k.nr, k.eng[0].torque, k.vz, k.ias, k.light[5]);
        k.collective = 0.45; run(k, 10);
        System.out.printf("OEI after collective reduction: nr=%.1f tq1=%.0f%% vz=%.1f ias=%.0f agl=%.0f%n", k.nr, k.eng[0].torque, k.vz, k.ias, k.agl);
    }
}
