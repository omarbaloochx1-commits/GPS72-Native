package com.hueysim.uh1;

public class T2 {
    static Sim s = Boot.huey();
    static void run(double sec) { for (int i = 0; i < (int) (sec * 60); i++) s.step(1.0 / 60); }
    static void startUp() {
        s.batt = true; s.fuelMain = true; s.fuelStart = true; s.inverter = true; run(1);
        s.starterBtn = true; double t0 = s.time;
        while (s.n1 < 15) run(0.1);
        s.throttle = 0.15;
        while (s.n1 < 40) run(0.1);
        s.starterBtn = false; run(14);
        s.gen = true; s.hyd = true; s.fuelStart = false; run(2); s.throttle = 1.0; run(40);
    }
    static double prevUf;
    public static void main(String[] a) {
        startUp();
        System.out.printf("ready nr=%.1f n1=%.1f tq=%.1f%n", s.nr, s.n1, s.torque);
        double targetV = 0, targetAgl = 4;
        double cc = 0.55, cy = 0;
        double destX = Terrain.padX[1];
        double lastPrint = -10;
        String phase = "hover";
        for (int step = 0; step < 60 * 400; step++) {
            double dt = 1.0 / 60;
            double agl = s.agl;
            // phase logic
            if (phase.equals("hover") && s.time > 100 + 0 && agl > 3 && Math.abs(s.vz) < 0.5) { phase = "cruise"; System.out.printf("-> cruise at t=%.1f%n", s.time); }
            if (phase.equals("hover")) { targetV = 0; targetAgl = 4; }
            double dist = destX - s.x;
            if (phase.equals("cruise")) {
                targetV = 30; targetAgl = 120;
                if (dist < 900) { phase = "approach"; System.out.printf("-> approach at t=%.1f x=%.0f%n", s.time, s.x); }
            }
            if (phase.equals("approach")) { targetV = Math.max(2, Math.min(30, dist / 30)); targetAgl = Math.max(3, Math.min(120, dist * 0.12)); if (dist < 25) { phase = "land"; System.out.printf("-> land at t=%.1f%n", s.time); } }
            if (phase.equals("land")) { targetV = Math.max(0, Math.min(3, dist / 20)); targetAgl = -1.5; }
            // collective: altitude hold
            double vzCmd = Math.max(-2.5, Math.min(4, (targetAgl - agl) * 0.5));
            if (phase.equals("land") && agl < 6) vzCmd = -0.6;
            if (agl < 0.3 && phase.equals("land")) vzCmd = -1;
            cc += (0.7 * (vzCmd - s.vz)) * 0.25 * dt * 3;
            cc = Math.max(0.0, Math.min(1, cc));
            if (phase.equals("land") && s.onGround) cc = Math.max(0, cc - 0.3 * dt);
            s.collective = cc;
            // cyclic: speed hold  (target forward air speed relative ground; use ground speed)
            double gs = s.vx * Math.signum(Math.sin(Math.toRadians(s.hdg)));
            double ax = (s.vx - prevUf) / dt; prevUf = s.vx;
            double vErr = targetV - gs;
            cy = Math.max(-1, Math.min(1, 0.06 * vErr - 0.02 * (s.vx - 0) * 0 + 0.0 - 0.012 * ax * Math.signum(Math.sin(Math.toRadians(s.hdg))) * 0 + (targetV > 15 ? 0.35 : 0)));
            // add damping on pitch rate
            cy -= 0.05 * s.pitchRate;
            s.cyclic = Math.max(-1, Math.min(1, cy));
            // yaw: keep heading 90
            double hErr = 90 - s.hdg; if (hErr > 180) hErr -= 360; if (hErr < -180) hErr += 360;
            s.pedal = Math.max(-1, Math.min(1, 0.08 * hErr - 0.02 * s.yawRate));
            s.step(dt);
            if (s.time - lastPrint >= 10) {
                lastPrint = s.time;
                System.out.printf("t=%6.1f %-8s x=%6.0f agl=%5.1f vx=%5.1f vz=%5.1f pitch=%5.1f ias=%5.1f coll=%.2f cyc=%.2f tq=%4.1f nr=%5.1f egt=%4.0f fuel=%4.0f hdg=%5.1f%n",
                    s.time, phase, s.x, s.agl, s.vx, s.vz, Math.toDegrees(s.pitch), s.ias, s.collective, s.cyclic, s.torque, s.nr, s.egt, s.fuelLb, s.hdg);
            }
            if (s.crashed) { System.out.println("CRASH: " + s.crashMsg + " t=" + s.time + " x=" + s.x); break; }
            if (phase.equals("land") && s.onGround && Math.abs(s.vx) < 0.3 && s.time > 100) { System.out.printf("LANDED x=%.1f touchVz=%.2f touchSpeed=%.2f pitch=%.1f hard=%b fuel=%.0f t=%.1f%n", s.x, s.touchVz, s.touchSpeed, s.touchPitch, s.hardLanding, s.fuelLb, s.time); break; }
        }
    }
}
