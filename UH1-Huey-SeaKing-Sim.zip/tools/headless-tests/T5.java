package com.hueysim.uh1;

public class T5 {
    static void run(Sim s, double sec) { for (int i = 0; i < (int) (sec * 60); i++) s.step(1.0 / 60); }
    public static void main(String[] a) {
        // max speed: hold altitude with collective, increase cyclic
        Sim r = T4.airborne();
        r.throttle = 1.0; r.govAuto = true; r.lit = true;
        for (double cy : new double[]{0.45, 0.6, 0.75, 0.9, 1.0}) {
            r.cyclic = cy;
            for (int i = 0; i < 60 * 25; i++) {
                r.collective = Math.max(0, Math.min(1, r.collective + (0.0004 * (150 - r.agl) - 0.0012 * r.vz)));
                r.pedal = Math.max(-1, Math.min(1, 0.08 * (90 - r.hdg))); r.step(1.0 / 60);
            }
            System.out.printf("cyclic %.2f: ias=%.0f kt vs=%.0f agl=%.0f torque=%.1f psi nr=%.1f egt=%.0f pitch=%.1f fuelflow=%.0f lb/h%n", cy, r.ias, r.vsiFpm, r.agl, r.torque, r.nr, r.egt, Math.toDegrees(r.pitch), r.fuelFlow);
        }
        for (double flareAt : new double[]{25, 35, 45}) {
            Sim s = T4.airborne();
            s.throttle = 0; double t0 = s.time;
            run(s, 0.8);
            while (!s.onGround && !s.crashed && s.time - t0 < 60) {
                double target;
                if (s.agl > flareAt) { target = Math.max(0.0, Math.min(0.5, 0.12 + 0.02 * (s.nr - 100))); s.cyclic = s.ias > 60 ? -0.2 : 0.1; }
                else if (s.agl > 9) { target = 0.10; s.cyclic = -0.9; }
                else { target = Math.min(1.0, 0.45 + (-s.vz) * 0.10); s.cyclic = Math.abs(s.vx) > 6 ? -0.3 : 0.0; }
                s.collective += (target - s.collective) * 0.15;
                run(s, 1.0 / 60);
                if (flareAt == 35 && ((int) ((s.time - t0) * 60)) % 30 == 0 && s.agl < 60) System.out.printf("    t+%.1f agl=%.1f vx=%.1f vz=%.1f pitch=%.1f nr=%.1f coll=%.2f%n", s.time - t0, s.agl, s.vx, s.vz, Math.toDegrees(s.pitch), s.nr, s.collective);
            }
            System.out.printf("flare at %.0f m: crashed=%b (%s) touchVz=%.2f m/s (%.0f fpm) touchSpeed=%.1f m/s (%.0f kt) pitch=%.1f nr=%.1f hard=%b%n", flareAt, s.crashed, s.crashMsg, s.touchVz, s.touchVz * 196.85, s.touchSpeed, s.touchSpeed * 1.944, s.touchPitch, s.nr, s.hardLanding);
        }
    }
}
