package com.hueysim.uh1;

/** Scripted test pilot that flies every mission through the real Mission checklist. */
public class Pilot {
    final Sim s; final Mission m; final Mission.Def d;
    double cc = 0.0, wantHdg = 90, prevCyc = 0;
    final double dt = 1.0 / 60;
    String log = "";

    Pilot(int missionIdx) {
        d = Mission.DEFS[missionIdx];
        Terrain.setMap(d.map);
        s = new Sim(Aircraft.get(d.aircraft));
        s.setup(d.startX, d.oat, d.wind, d.fuel, d.payload);
        m = new Mission(d);
        if (d.airborne) {
            s.presetAirborne(d.airAgl, d.airSpeed);
        } else if (!d.cold) {
            s.presetRunning();
        }
        m.startTime = s.time;
    }

    void tick() { s.step(dt); m.update(s, dt); }
    void run(double sec) { for (int i = 0; i < (int) (sec * 60); i++) tick(); }

    void startup() {
        if (s.ac.id == Aircraft.HUEY) {
            s.batt = true; s.fuelMain = true; s.fuelStart = true; s.inverter = true; run(1);
            s.starterBtn = true; while (s.n1 < 15) run(0.1);
            s.throttle = 0.15; while (s.n1 < 40) run(0.1);
            s.starterBtn = false; run(14);
            s.gen = true; s.hyd = true; s.fuelStart = false; run(2); s.throttle = 1.0; run(40);
        } else {
            s.batt = true; s.inverter = true; s.throttle = 0.15; run(1);
            s.starterBtn = true; while (s.eng[0].n1 < 15) run(0.1);
            s.fuelMain = true; while (s.eng[0].n1 < 40) run(0.1);
            s.starterBtn = false; run(14);
            s.starter2 = true; while (s.eng[1].n1 < 15) run(0.1);
            s.fuel2 = true; while (s.eng[1].n1 < 40) run(0.1);
            s.starter2 = false; run(14);
            s.gen = true; s.gen2 = true; s.hyd = true; run(2); s.throttle = 1.0; run(60);
        }
    }

    double norm(double a) { while (a > 180) a -= 360; while (a < -180) a += 360; return a; }

    /** Flight controllers. targetV = speed along the heading direction (m/s). */
    void ctl(double targetV, double targetAgl, boolean landing) {
        double dir = Math.signum(Math.sin(Math.toRadians(wantHdg)));
        double gsF = s.vx * dir;
        double look = Math.max(Terrain.h(s.x), Terrain.h(s.x + dir * 22));
        double agl = s.alt - s.contact - look;
        double vzCmd = Math.max(-2.5, Math.min(8, (targetAgl - agl) * 0.5));
        if (landing && agl < 6) vzCmd = -0.6;
        cc += 0.7 * (vzCmd - s.vz) * 0.25 * dt * 3;
        if (s.nr < 97 && s.anyLit) cc -= 0.15 * dt * (97 - s.nr) / 3.0;
        cc = Math.max(0, Math.min(1, cc));
        if (landing && s.onGround) cc = Math.max(0, cc - 0.3 * dt);
        s.collective = cc;
        double cy = 0.06 * (targetV - gsF) + (targetV > 15 ? 0.35 : 0) - 0.05 * s.pitchRate;
        s.cyclic = Math.max(-1, Math.min(1, cy));
        s.pedal = Math.max(-1, Math.min(1, 0.08 * norm(wantHdg - s.hdg) - 0.02 * s.yawRate));
    }

    boolean fly(double maxSec) {
        double t0 = s.time;
        double groundAgl = 0;
        int lastStep = -1;
        while (!m.complete && !m.failed && s.time - t0 < maxSec) {
            Mission.Step st = m.cur();
            double dist = m.distTarget(s) * 1.0;          // + east
            double dir = Math.signum(Math.sin(Math.toRadians(wantHdg)));
            if (m.step != lastStep) { lastStep = m.step; log += String.format("  step %d (type %d) at t=%.0f x=%.0f agl=%.0f%n", m.step, st.type, s.time - t0, s.x, s.agl); }
            switch (st.type) {
                case Mission.F_TAKEOFF: if (s.ac.hasGear && !s.gearCmd) s.gearCmd = true; ctl(0, 4, false); if (m.step > 0 && d.steps[Math.max(0, m.step - 1)].type == Mission.F_LAND_WAIT) { ctl(0, 4, false); } break;
                case Mission.F_HOVER: ctl(0, 4, false); break;
                case Mission.F_GEARUP: s.gearCmd = false; ctl(0, 25, false); break;
                case Mission.F_GEARDN: s.gearCmd = true; ctl(25, 100, false); break;
                case Mission.F_CLIMB: ctl(25, st.a + 25, false); break;
                case Mission.F_REACH: {
                    wantHdg = st.b >= 0 ? 90 : 270;
                    double tgtAgl = Math.max(110, Math.max(Terrain.h(s.x + dir * 500), Terrain.h(s.x + dir * 1000)) - Terrain.h(s.x) + 110);
                    ctl(38, tgtAgl, false);
                    break;
                }
                case Mission.F_NEAR: case Mission.F_LAND: case Mission.F_LAND_WAIT: {
                    int pad = st.pad;
                    double ax = m.padX(pad) - s.x;
                    wantHdg = ax >= 0 ? 90 : 270;
                    double adist = Math.abs(ax);
                    double half = Terrain.padHalf[pad];
                    boolean running = d.failEng >= 0 && s.ac.id == Aircraft.SEAKING && s.eng[1].failed;
                    double tv = Math.max(2, Math.min(38, adist / 30));
                    double ta = Math.max(3, Math.min(110, adist * 0.12));
                    if (running) { tv = Math.max(12, Math.min(30, adist / 25)); ta = Math.max(2, Math.min(80, adist * 0.12)); }
                    if (adist < 25 && !running) { tv = Math.max(0, Math.min(3, adist / 20)); ta = -1.5; }
                    if (running && adist < half * 1.0) { tv = 10; ta = -1.5; }
                    boolean land = st.type != Mission.F_NEAR && adist < 40 || (running && st.type == Mission.F_LAND && adist < half);
                    if (st.type == Mission.F_LAND_WAIT && s.onGround) { cc = Math.max(0, cc - 0.3 * dt); s.collective = cc; s.cyclic = 0; }
                    else ctl(tv, ta, adist < 25 || (running && adist < half));
                    if (s.ac.hasGear) s.gearCmd = true;
                    break;
                }
                case Mission.F_HOIST_POS: case Mission.F_HOIST_LOWER: case Mission.F_HOIST_LOAD: case Mission.F_HOIST_RAISE: {
                    wantHdg = 90;
                    double ex = d.raftX - s.x;
                    double tv = Math.max(-2, Math.min(25, ex / 25 + 0));
                    if (Math.abs(ex) < 60) tv = Math.max(-3, Math.min(3, ex * 0.1 - s.vx * 0.5));
                    ctl(tv, 28, false);
                    s.hoistCmd = st.type == Mission.F_HOIST_LOWER || st.type == Mission.F_HOIST_LOAD ? (s.cableLen < s.agl - 3 ? 1 : 0) : st.type == Mission.F_HOIST_RAISE ? -1 : 0;
                    break;
                }
                case Mission.F_FAIL: {
                    wantHdg = 90; ctl(d.airSpeed, d.airAgl, false);
                    break;
                }
                case Mission.F_AUTOLAND: {
                    // autorotation pilot
                    double target;
                    double ax = m.padX(st.pad) - s.x;
                    if (s.agl > 38) { target = Math.max(0.0, Math.min(0.5, 0.12 + 0.02 * (s.nr - 100))); s.cyclic = s.ias > 62 ? -0.15 : 0.2; }
                    else if (s.agl > 9) { target = 0.10; s.cyclic = -0.9; }
                    else { target = Math.min(1.0, 0.45 + (-s.vz) * 0.10); s.cyclic = Math.abs(s.vx) > 6 ? -0.3 : 0.0; }
                    cc += (target - cc) * 0.15; s.collective = cc;
                    s.pedal = Math.max(-1, Math.min(1, 0.08 * norm(90 - s.hdg)));
                    if (s.onGround) { cc = 0; s.collective = 0; }
                    break;
                }
                default: ctl(0, 4, false);
            }
            tick();
            if (!s.onGround && Math.abs(s.pitch) > 0.69 && false) break;
        }
        return m.complete;
    }
}
