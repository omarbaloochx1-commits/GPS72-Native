Headless (no Android) tests of the flight model. They only need a JDK:

  P=app/src/main/java/com/hueysim/uh1
  javac -d out $P/Aircraft.java $P/Terrain.java $P/Sim.java $P/Mission.java $P/Manual.java tools/headless-tests/*.java
  java -cp out com.hueysim.uh1.T8       # scripted pilot flies all seven missions through the real checklist and scoring

T1 UH-1H engine start + hover collective, T2 scripted UH-1H flight/landing, T4/T5 hot-start variants, top speed, autorotation,
T7 Sea King twin-engine start, hover, cruise, single-engine failure, T8/T9 mission runner, Md writes docs/MANUAL_*.md.
