package com.hueysim.uh1;

public class T9 {
    public static void main(String[] a) {
        Pilot p = new Pilot(2);
        p.startup();
        System.out.printf("after start-up: nr=%.1f tq=%.1f mass=%.0f sigma=%.3f fieldElev=%.0f%n", p.s.nr, p.s.torque, p.s.massKg(), p.s.sigma, p.s.fieldElev);
        double t0 = p.s.time;
        for (int i = 0; i < 60 * 140 && !p.m.failed && !p.m.complete; i++) {
            // run one pilot tick at a time via fly with tiny budget
            p.fly(1.0 / 60 + 1e-9);
            if (i % 300 == 0) System.out.printf("t=%5.0f step=%d x=%5.0f alt=%6.0f agl=%5.1f terrAhead=%6.0f ias=%5.1f vz=%5.1f coll=%.2f tq=%5.1f nr=%5.1f egt=%4.0f%n", p.s.time - t0, p.m.step, p.s.x, p.s.alt, p.s.agl, Terrain.h(p.s.x + 300), p.s.ias, p.s.vz, p.s.collective, p.s.torque, p.s.nr, p.s.egt);
        }
        System.out.println("failed=" + p.m.failed + " " + p.m.failMsg);
    }
}
