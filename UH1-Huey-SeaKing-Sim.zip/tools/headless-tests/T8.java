package com.hueysim.uh1;

public class T8 {
    public static void main(String[] a) {
        int only = a.length > 0 ? Integer.parseInt(a[0]) : -1;
        for (int i = 0; i < Mission.DEFS.length; i++) {
            if (only >= 0 && i != only) continue;
            Pilot p = new Pilot(i);
            if (p.d.cold) p.startup();
            boolean ok = p.fly(900);
            Sim s = p.s; Mission m = p.m;
            System.out.printf("MISSION %d %-26s complete=%b failed=%b (%s) step=%d/%d t=%.0f x=%.0f score=%.0f [%.0f/%.0f/%.0f/%.0f] %s touchVz=%.2f spd=%.1f fuel=%.0f%n",
                    i + 1, p.d.titleEn, ok, m.failed, m.failMsg, m.step, m.n(), s.time, s.x, m.score, m.sStart, m.sFlight, m.sLand, m.sBonus, m.rating, s.touchVz, s.touchSpeed, s.fuelLb);
            if (!ok) System.out.print(p.log);
        }
    }
}
