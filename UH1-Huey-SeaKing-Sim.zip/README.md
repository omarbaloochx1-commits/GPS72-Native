# Helicopter Simulator: UH-1H Huey + Sea King (Android, 2D)

A 2-D side-view helicopter simulator with a real physical model and a complete working cockpit.

## Aircraft
* **Bell UH-1H Iroquois**: single engine (T53 type), two-blade teetering rotor, skids.
* **Westland Sea King HAR.3**: twin engines, five-blade rotor, retractable wheels, amphibious hull (lands on water), rescue winch.

## Simulation
* Momentum-theory rotor model: thrust from collective / rotor speed / inflow, induced + profile + parasite power, ground effect, translational lift, autorotation, density altitude.
* Turboshaft engines: N1 gas producer, EGT, torque, governor (AUTO / EMER), real start sequence (hot start), single-engine failures.
* 24 V electrical system, hydraulics, fuel, engine / gearbox oils, 14 caution lights per aircraft, 16 working instruments.
* Synthesised sound: turbine whine, blade slap (2 or 5 blades), starter, wind, low-rpm horn, touchdown thump.

## Missions (7)
1. Delivery Flight (UH-1H, valley, cold start)
2. Medevac (UH-1H, valley, timed)
3. Hot & High Resupply (UH-1H, mountains, thin air)
4. Autorotation Drill (UH-1H, engine failure)
5. Sea King Familiarisation (cold start, gear, ship deck landing)
6. Search and Rescue (Sea King, winch hoist from a raft, timed)
7. Single-Engine Emergency (Sea King, running landing)

Manuals: `docs/MANUAL_EN.md`, `docs/MANUAL_FA.md` (same text as the in-game MANUAL button, English and Persian).

## Build the APK on GitHub
1. Create a new repository (or empty an old one) and upload the contents of this project, **including the `.github` folder**
   (or upload the project zip next to `.github/workflows/build.yml`; the workflow unpacks the newest zip).
2. Open the *Actions* tab -> **Build APK** -> run -> download the artifact `UH1-Huey-Sim-apk-<n>`.
3. Install `app-debug.apk`. The package name `com.hueysim.uh1` and the signing key are fixed, so every new build updates the old one
   and keeps the saved settings and scores.

Requirements: Android 7.0+ (API 24), landscape. No permissions are needed.

## Controls (touch)
Left: **COLLECTIVE** lever and **THROTTLE** twist grip (ESL on the Sea King). Right: **CYCLIC** lever (double-tap to centre).
Under the outside view: **LEFT / RIGHT PEDAL** and, on the Sea King, **WINCH DOWN / UP**. Switches are tapped; **STARTER** buttons are press-and-hold.

## Developer notes
`tools/headless-tests` contains Java tests of the flight model and a scripted pilot that flies all 7 missions without Android
(`javac` the four pure-Java classes `Aircraft, Terrain, Sim, Mission` plus the tests; run `com.hueysim.uh1.T8`).
