package com.hueysim.uh1;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import java.util.ArrayList;
import java.util.Locale;

/** Environment values the gauges need besides the simulation itself. */
final class GaugeEnv {
    double clock;          // seconds since 08:00:00
    double distDest;       // metres to the destination (signed, +east)
    double bearingDest;    // degrees
    boolean blink;
}

/** Shared drawing helpers. Angles are degrees clockwise from 3 o'clock (Android canvas convention). */
final class GU {
    private GU() { }
    static final int GREEN = 0xFF38C25A, YELLOW = 0xFFF0C419, RED = 0xFFE5392E, WHITE = 0xFFEDEDED, ORANGE = 0xFFFF9A2E, GREY = 0xFF8C8F94, CYAN = 0xFF4FD0E8;
    private static final RectF RF = new RectF();
    private static final Path PATH = new Path();

    static void text(Canvas c, Paint p, String s, float x, float y, float size, int color, Paint.Align al, boolean bold) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        p.setTextSize(size);
        p.setTextAlign(al);
        p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        c.drawText(s, x, y + size * 0.35f, p);
    }

    static void dial(Canvas c, float r, Paint p) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF2A2B2E);
        c.drawCircle(r, r, r * 0.998f, p);
        p.setColor(0xFF06070A);
        c.drawCircle(r, r, r * 0.91f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(r * 0.025f);
        p.setColor(0xFF55585E);
        c.drawCircle(r, r, r * 0.93f, p);
    }

    static void band(Canvas c, Paint p, float cx, float cy, float rad, float a0, float sweep, int color, float w) {
        RF.set(cx - rad, cy - rad, cx + rad, cy + rad);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w);
        p.setColor(color);
        c.drawArc(RF, a0, sweep, false, p);
    }

    static void line(Canvas c, Paint p, float cx, float cy, float ang, float r0, float r1, float w, int color) {
        double a = Math.toRadians(ang);
        float cs = (float) Math.cos(a), sn = (float) Math.sin(a);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w);
        p.setColor(color);
        c.drawLine(cx + cs * r0, cy + sn * r0, cx + cs * r1, cy + sn * r1, p);
    }

    static void needle(Canvas c, Paint p, float cx, float cy, float ang, float len, float tail, float w, int color) {
        c.save();
        c.rotate(ang, cx, cy);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(w);
        p.setColor(color);
        c.drawLine(cx - tail, cy, cx + len, cy, p);
        p.setStrokeCap(Paint.Cap.BUTT);
        c.restore();
    }

    static void hub(Canvas c, Paint p, float cx, float cy, float rr) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF3A3C40);
        c.drawCircle(cx, cy, rr, p);
        p.setColor(0xFF121315);
        c.drawCircle(cx, cy, rr * 0.55f, p);
    }

    static void box(Canvas c, Paint p, float cx, float cy, float w, float h, String s, float size, int color) {
        RF.set(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF000000);
        c.drawRoundRect(RF, h * 0.2f, h * 0.2f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1, h * 0.06f));
        p.setColor(0xFF4A4C50);
        c.drawRoundRect(RF, h * 0.2f, h * 0.2f, p);
        text(c, p, s, cx, cy, size, color, Paint.Align.CENTER, true);
    }

    static String num(double v) {
        if (Math.abs(v - Math.round(v)) < 1e-6) return String.valueOf((long) Math.round(v));
        return String.format(Locale.US, "%.1f", v);
    }

    static void clipCircle(Canvas c, float cx, float cy, float rad) {
        PATH.reset();
        PATH.addCircle(cx, cy, rad, Path.Direction.CW);
        c.clipPath(PATH);
    }
}

abstract class Gauge {
    private Bitmap face;
    private int fsz;
    boolean overlay;                                   // face is drawn above the dynamic part (attitude indicator)

    abstract void drawFace(Canvas c, float r, Paint p);

    abstract void drawDyn(Canvas c, float cx, float cy, float r, Sim s, GaugeEnv e, Paint p);

    final void draw(Canvas c, float cx, float cy, float r, Sim s, GaugeEnv e, Paint p) {
        int sz = Math.max(8, Math.round(r * 2));
        if (face == null || fsz != sz) {
            face = Bitmap.createBitmap(sz, sz, Bitmap.Config.ARGB_8888);
            Canvas bc = new Canvas(face);
            drawFace(bc, sz / 2f, p);
            fsz = sz;
        }
        float lx = cx - sz / 2f, ly = cy - sz / 2f;
        if (overlay) {
            drawDyn(c, cx, cy, r, s, e, p);
            c.drawBitmap(face, lx, ly, null);
        } else {
            c.drawBitmap(face, lx, ly, null);
            drawDyn(c, cx, cy, r, s, e, p);
        }
    }

    static boolean powered(Sim s) { return s.busV > 18; }
}

/** Single scale round gauge with colour bands, ticks and one or more needles. */
final class ArcGauge extends Gauge {
    interface V { double v(Sim s, GaugeEnv e); }

    static final class Needle {
        V v; double vmin, vmax; float a0, sweep, len, tail, w; int color; boolean elec;
    }

    private static final class Band { double v0, v1; int color; }

    final String title, unit;
    final double vmin, vmax, major, minor, labelStep, labelDiv;
    final float a0, sweep;
    boolean skipLast, lab12, elec;
    private final ArrayList<Band> bands = new ArrayList<>();
    private final ArrayList<Double> reds = new ArrayList<>();
    private final ArrayList<Needle> needles = new ArrayList<>();
    private V digital;
    private String digFmt = "%d";
    private boolean digElec;

    ArcGauge(String title, String unit, double vmin, double vmax, float a0, float sweep, double major, double minor, double labelStep, double labelDiv) {
        this.title = title; this.unit = unit; this.vmin = vmin; this.vmax = vmax; this.a0 = a0; this.sweep = sweep;
        this.major = major; this.minor = minor; this.labelStep = labelStep; this.labelDiv = labelDiv;
    }

    ArcGauge powered() { elec = true; return this; }

    ArcGauge band(double v0, double v1, int color) { Band b = new Band(); b.v0 = v0; b.v1 = v1; b.color = color; bands.add(b); return this; }

    ArcGauge red(double v) { reds.add(v); return this; }

    ArcGauge needle(V v, float len, float w, int color) {
        Needle n = new Needle(); n.v = v; n.vmin = vmin; n.vmax = vmax; n.a0 = a0; n.sweep = sweep; n.len = len; n.tail = 0.12f; n.w = w; n.color = color; n.elec = elec;
        needles.add(n); return this;
    }

    ArcGauge needle2(V v, double nmin, double nmax, float len, float w, int color) {
        Needle n = new Needle(); n.v = v; n.vmin = nmin; n.vmax = nmax; n.a0 = a0; n.sweep = sweep; n.len = len; n.tail = 0.08f; n.w = w; n.color = color; n.elec = elec;
        needles.add(n); return this;
    }

    ArcGauge digital(V v, String fmt, boolean needsPower) { digital = v; digFmt = fmt; digElec = needsPower; return this; }

    float ang(double v) { return (float) (a0 + (Math.max(vmin, Math.min(vmax, v)) - vmin) / (vmax - vmin) * sweep); }

    @Override
    void drawFace(Canvas c, float r, Paint p) {
        GU.dial(c, r, p);
        float rb = r * 0.835f;
        for (Band b : bands) GU.band(c, p, r, r, rb, ang(b.v0), ang(b.v1) - ang(b.v0), b.color, r * 0.05f);
        int n = (int) Math.round((vmax - vmin) / minor);
        for (int i = 0; i <= n; i++) {
            double v = vmin + i * minor;
            double k = (v - vmin) / major;
            boolean maj = Math.abs(k - Math.round(k)) < 1e-6;
            float a = ang(v);
            GU.line(c, p, r, r, a, r * (maj ? 0.72f : 0.78f), r * 0.87f, maj ? r * 0.030f : r * 0.016f, GU.WHITE);
            double kl = (v - vmin) / labelStep;
            if (Math.abs(kl - Math.round(kl)) < 1e-6 && !(skipLast && i == n)) {
                double lv = v / labelDiv;
                String t = (lab12 && Math.abs(lv) < 1e-6) ? "12" : GU.num(lv);
                double ra = Math.toRadians(a);
                GU.text(c, p, t, r + (float) Math.cos(ra) * r * 0.57f, r + (float) Math.sin(ra) * r * 0.57f, r * 0.17f, GU.WHITE, Paint.Align.CENTER, true);
            }
        }
        for (double v : reds) GU.line(c, p, r, r, ang(v), r * 0.66f, r * 0.89f, r * 0.045f, GU.RED);
        if (title != null) GU.text(c, p, title, r, r * 0.66f, r * 0.15f, GU.WHITE, Paint.Align.CENTER, true);
        if (unit != null) GU.text(c, p, unit, r, r * 1.62f, r * 0.13f, GU.GREY, Paint.Align.CENTER, false);
    }

    @Override
    void drawDyn(Canvas c, float cx, float cy, float r, Sim s, GaugeEnv e, Paint p) {
        boolean pw = powered(s);
        if (digital != null) {
            String t = (digElec && !pw) ? "---" : String.format(Locale.US, digFmt, digital.v(s, e));
            GU.box(c, p, cx, cy + r * 1.30f, r * 0.62f, r * 0.24f, t, r * 0.17f, GU.GREEN);
        }
        for (Needle nd : needles) {
            double v = (nd.elec && !pw) ? nd.vmin : nd.v.v(s, e);
            v = Math.max(nd.vmin, Math.min(nd.vmax, v));
            float a = (float) (nd.a0 + (v - nd.vmin) / (nd.vmax - nd.vmin) * nd.sweep);
            GU.needle(c, p, cx, cy, a, r * nd.len, r * nd.tail, r * nd.w, nd.color);
        }
        GU.hub(c, p, cx, cy, r * 0.085f);
    }
}

/** Two scales on one dial: left scale (pressure) and right scale (temperature / amps). */
final class DualGauge extends Gauge {
    private static final class Band { double v0, v1; int color; boolean left; }

    final String title, lTitle, rTitle;
    final double lmin, lmax, rmin, rmax, lStep, rStep, lDiv, rDiv;
    private final ArrayList<Band> bands = new ArrayList<>();
    private final ArcGauge.V lv, rv;
    private final boolean elec;

    DualGauge(String title, String lTitle, String rTitle, double lmin, double lmax, double lStep, double lDiv,
              double rmin, double rmax, double rStep, double rDiv, ArcGauge.V lv, ArcGauge.V rv, boolean elec) {
        this.title = title; this.lTitle = lTitle; this.rTitle = rTitle; this.lmin = lmin; this.lmax = lmax; this.lStep = lStep; this.lDiv = lDiv;
        this.rmin = rmin; this.rmax = rmax; this.rStep = rStep; this.rDiv = rDiv; this.lv = lv; this.rv = rv; this.elec = elec;
    }

    DualGauge band(boolean left, double v0, double v1, int color) { Band b = new Band(); b.left = left; b.v0 = v0; b.v1 = v1; b.color = color; bands.add(b); return this; }

    private float angL(double v) { return (float) (120 + (Math.max(lmin, Math.min(lmax, v)) - lmin) / (lmax - lmin) * 120); }

    private float angR(double v) { return (float) (60 - (Math.max(rmin, Math.min(rmax, v)) - rmin) / (rmax - rmin) * 120); }

    @Override
    void drawFace(Canvas c, float r, Paint p) {
        GU.dial(c, r, p);
        float rb = r * 0.835f;
        for (Band b : bands) {
            if (b.left) GU.band(c, p, r, r, rb, angL(b.v0), angL(b.v1) - angL(b.v0), b.color, r * 0.05f);
            else GU.band(c, p, r, r, rb, angR(b.v0), angR(b.v1) - angR(b.v0), b.color, r * 0.05f);
        }
        int nl = (int) Math.round((lmax - lmin) / lStep);
        for (int i = 0; i <= nl; i++) {
            double v = lmin + i * lStep;
            float a = angL(v);
            GU.line(c, p, r, r, a, r * 0.74f, r * 0.87f, r * 0.028f, GU.WHITE);
            double ra = Math.toRadians(a);
            GU.text(c, p, GU.num(v / lDiv), r + (float) Math.cos(ra) * r * 0.60f, r + (float) Math.sin(ra) * r * 0.60f, r * 0.14f, GU.WHITE, Paint.Align.CENTER, true);
        }
        int nr = (int) Math.round((rmax - rmin) / rStep);
        for (int i = 0; i <= nr; i++) {
            double v = rmin + i * rStep;
            float a = angR(v);
            GU.line(c, p, r, r, a, r * 0.74f, r * 0.87f, r * 0.028f, GU.WHITE);
            double ra = Math.toRadians(a);
            GU.text(c, p, GU.num(v / rDiv), r + (float) Math.cos(ra) * r * 0.60f, r + (float) Math.sin(ra) * r * 0.60f, r * 0.14f, GU.WHITE, Paint.Align.CENTER, true);
        }
        GU.text(c, p, title, r, r * 0.38f, r * 0.15f, GU.WHITE, Paint.Align.CENTER, true);
        GU.text(c, p, lTitle, r * 0.52f, r * 1.50f, r * 0.13f, GU.GREY, Paint.Align.CENTER, false);
        GU.text(c, p, rTitle, r * 1.48f, r * 1.50f, r * 0.13f, GU.GREY, Paint.Align.CENTER, false);
    }

    @Override
    void drawDyn(Canvas c, float cx, float cy, float r, Sim s, GaugeEnv e, Paint p) {
        boolean pw = !elec || powered(s);
        double a = pw ? lv.v(s, e) : lmin, b = pw ? rv.v(s, e) : rmin;
        GU.needle(c, p, cx, cy, angL(a), r * 0.80f, r * 0.10f, r * 0.045f, GU.WHITE);
        GU.needle(c, p, cx, cy, angR(b), r * 0.80f, r * 0.10f, r * 0.045f, GU.ORANGE);
        GU.hub(c, p, cx, cy, r * 0.085f);
    }
}

/** Artificial horizon (needs the inverter). */
final class AdiGauge extends Gauge {
    AdiGauge() { overlay = true; }

    @Override
    void drawFace(Canvas c, float r, Paint p) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(r * 0.20f);
        p.setColor(0xFF1B1C1E);
        c.drawCircle(r, r, r * 0.90f, p);
        p.setStrokeWidth(r * 0.035f);
        p.setColor(0xFF55585E);
        c.drawCircle(r, r, r * 0.795f, p);
        // fixed aircraft symbol
        p.setStrokeWidth(r * 0.06f);
        p.setColor(GU.ORANGE);
        c.drawLine(r * 0.28f, r, r * 0.78f, r, p);
        c.drawLine(r * 1.22f, r, r * 1.72f, r, p);
        c.drawLine(r * 0.78f, r, r * 0.78f, r * 1.12f, p);
        c.drawLine(r * 1.22f, r, r * 1.22f, r * 1.12f, p);
        p.setStyle(Paint.Style.FILL);
        c.drawCircle(r, r, r * 0.045f, p);
        // roll index
        Path t = new Path();
        t.moveTo(r, r * 0.20f);
        t.lineTo(r - r * 0.06f, r * 0.08f);
        t.lineTo(r + r * 0.06f, r * 0.08f);
        t.close();
        p.setColor(GU.WHITE);
        c.drawPath(t, p);
        GU.text(c, p, "ATTITUDE", r, r * 1.72f, r * 0.11f, GU.GREY, Paint.Align.CENTER, false);
    }

    @Override
    void drawDyn(Canvas c, float cx, float cy, float r, Sim s, GaugeEnv e, Paint p) {
        boolean pw = s.inverter && powered(s);
        c.save();
        GU.clipCircle(c, cx, cy, r * 0.80f);
        if (pw) {
            float ppd = r * 0.80f / 24f;
            float hy = cy + (float) Math.toDegrees(s.pitch) * ppd;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF3F86D6);
            c.drawRect(cx - r, hy - 5 * r, cx + r, hy, p);
            p.setColor(0xFF8A5A30);
            c.drawRect(cx - r, hy, cx + r, hy + 5 * r, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(r * 0.03f);
            p.setColor(GU.WHITE);
            c.drawLine(cx - r, hy, cx + r, hy, p);
            for (int d = -20; d <= 20; d += 5) {
                if (d == 0) continue;
                float y = hy - d * ppd, hw = (d % 10 == 0) ? r * 0.30f : r * 0.15f;
                p.setStrokeWidth(r * 0.02f);
                c.drawLine(cx - hw, y, cx + hw, y, p);
                if (d % 10 == 0) {
                    GU.text(c, p, String.valueOf(Math.abs(d)), cx - hw - r * 0.10f, y, r * 0.09f, GU.WHITE, Paint.Align.CENTER, false);
                    GU.text(c, p, String.valueOf(Math.abs(d)), cx + hw + r * 0.10f, y, r * 0.09f, GU.WHITE, Paint.Align.CENTER, false);
                }
            }
        } else {
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF1A1B1D);
            c.drawRect(cx - r, cy - r, cx + r, cy + r, p);
            GU.text(c, p, "OFF", cx, cy - r * 0.35f, r * 0.20f, GU.RED, Paint.Align.CENTER, true);
        }
        c.restore();
    }
}

/** Vertical speed indicator (nonlinear, +-3000 fpm). */
final class VsiGauge extends Gauge {
    static float ang(double fpm) {
        double a = Math.abs(fpm);
        double d = a <= 1000 ? a / 1000.0 * 80 : 80 + Math.min(2000, a - 1000) / 2000.0 * 85;
        return (float) (180 + Math.signum(fpm) * d);
    }

    @Override
    void drawFace(Canvas c, float r, Paint p) {
        GU.dial(c, r, p);
        int[] v = {0, 500, 1000, 1500, 2000, 3000};
        for (int sgn = -1; sgn <= 1; sgn += 2) {
            for (int val : v) {
                if (val == 0 && sgn == 1) continue;
                float a = ang(sgn * val);
                boolean lab = val == 0 || val == 1000 || val == 2000 || val == 3000;
                GU.line(c, p, r, r, a, r * (lab ? 0.72f : 0.78f), r * 0.87f, lab ? r * 0.03f : r * 0.018f, GU.WHITE);
                if (lab) {
                    double ra = Math.toRadians(a);
                    GU.text(c, p, String.valueOf(val / 1000), r + (float) Math.cos(ra) * r * 0.57f, r + (float) Math.sin(ra) * r * 0.57f, r * 0.17f, GU.WHITE, Paint.Align.CENTER, true);
                }
            }
        }
        GU.text(c, p, "UP", r * 1.0f, r * 0.30f, r * 0.13f, GU.WHITE, Paint.Align.CENTER, true);
        GU.text(c, p, "DN", r * 1.0f, r * 1.70f, r * 0.13f, GU.WHITE, Paint.Align.CENTER, true);
        GU.text(c, p, "VERTICAL SPEED", r * 1.12f, r * 0.80f, r * 0.095f, GU.GREY, Paint.Align.CENTER, false);
        GU.text(c, p, "1000 FPM", r * 1.12f, r * 1.20f, r * 0.095f, GU.GREY, Paint.Align.CENTER, false);
    }

    @Override
    void drawDyn(Canvas c, float cx, float cy, float r, Sim s, GaugeEnv e, Paint p) {
        GU.needle(c, p, cx, cy, ang(Math.max(-3000, Math.min(3000, s.vsiFpm))), r * 0.80f, r * 0.12f, r * 0.045f, GU.WHITE);
        GU.hub(c, p, cx, cy, r * 0.085f);
    }
}

/** Radar altimeter (needs power). */
final class RadAltGauge extends Gauge {
    static float ang(double ft) {
        double m = ft <= 100 ? ft / 100.0 * 100 : ft <= 500 ? 100 + (ft - 100) / 400.0 * 100 : 200 + Math.min(1000, ft - 500) / 1000.0 * 70;
        return (float) (135 + m);
    }

    @Override
    void drawFace(Canvas c, float r, Paint p) {
        GU.dial(c, r, p);
        int[] t = {0, 20, 40, 60, 80, 100, 200, 300, 400, 500, 1000, 1500};
        for (int ft : t) {
            boolean lab = ft == 0 || ft == 20 || ft == 50 || ft == 100 || ft == 200 || ft == 500 || ft == 1000 || ft == 1500;
            float a = ang(ft);
            GU.line(c, p, r, r, a, r * (lab ? 0.72f : 0.78f), r * 0.87f, lab ? r * 0.03f : r * 0.016f, GU.WHITE);
            if (lab) {
                double ra = Math.toRadians(a);
                GU.text(c, p, String.valueOf(ft), r + (float) Math.cos(ra) * r * 0.58f, r + (float) Math.sin(ra) * r * 0.58f, r * 0.13f, GU.WHITE, Paint.Align.CENTER, true);
            }
        }
        GU.text(c, p, "RAD ALT", r, r * 0.66f, r * 0.15f, GU.WHITE, Paint.Align.CENTER, true);
        GU.text(c, p, "FEET", r, r * 1.62f, r * 0.13f, GU.GREY, Paint.Align.CENTER, false);
        GU.line(c, p, r, r, ang(50), r * 0.64f, r * 0.90f, r * 0.05f, GU.YELLOW);
    }

    @Override
    void drawDyn(Canvas c, float cx, float cy, float r, Sim s, GaugeEnv e, Paint p) {
        boolean pw = powered(s);
        double ft = pw ? Math.min(1500, s.radAltFt) : 0;
        GU.box(c, p, cx, cy + r * 1.30f, r * 0.62f, r * 0.24f, pw ? String.valueOf((int) ft) : "OFF", r * 0.17f, pw ? GU.GREEN : GU.RED);
        GU.needle(c, p, cx, cy, ang(ft), r * 0.80f, r * 0.12f, r * 0.045f, GU.WHITE);
        GU.hub(c, p, cx, cy, r * 0.085f);
    }
}

/** Heading indicator with RMI pointer to the destination and distance read-out. */
final class HsiGauge extends Gauge {
    @Override
    void drawFace(Canvas c, float r, Paint p) {
        GU.dial(c, r, p);
        Path t = new Path();
        t.moveTo(r, r * 0.13f);
        t.lineTo(r - r * 0.07f, r * 0.01f);
        t.lineTo(r + r * 0.07f, r * 0.01f);
        t.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(GU.ORANGE);
        c.drawPath(t, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(r * 0.04f);
        c.drawLine(r - r * 0.16f, r, r + r * 0.16f, r, p);
        c.drawLine(r, r - r * 0.10f, r, r + r * 0.18f, p);
        GU.text(c, p, "HEADING", r, r * 1.72f, r * 0.11f, GU.GREY, Paint.Align.CENTER, false);
    }

    @Override
    void drawDyn(Canvas c, float cx, float cy, float r, Sim s, GaugeEnv e, Paint p) {
        float h = (float) s.hdg;
        c.save();
        c.rotate(-h, cx, cy);
        String[] card = {"N", "3", "6", "E", "12", "15", "S", "21", "24", "W", "30", "33"};
        for (int d = 0; d < 360; d += 5) {
            boolean b30 = d % 30 == 0, b10 = d % 10 == 0;
            GU.line(c, p, cx, cy, d - 90, r * (b30 ? 0.70f : b10 ? 0.77f : 0.82f), r * 0.87f, b30 ? r * 0.03f : r * 0.016f, GU.WHITE);
            if (b30) {
                String t = card[d / 30];
                c.save();
                float x = cx + (float) Math.cos(Math.toRadians(d - 90)) * r * 0.57f, y = cy + (float) Math.sin(Math.toRadians(d - 90)) * r * 0.57f;
                c.rotate(d, x, y);
                GU.text(c, p, t, x, y, r * 0.17f, t.length() == 1 && !t.equals("3") && !t.equals("6") ? GU.ORANGE : GU.WHITE, Paint.Align.CENTER, true);
                c.restore();
            }
        }
        // RMI bearing pointer to destination (cyan) rotates with the card
        if (s.inverter && powered(s)) {
            GU.needle(c, p, cx, cy, (float) (e.bearingDest - 90), r * 0.66f, r * 0.0f, r * 0.045f, GU.CYAN);
        }
        c.restore();
        boolean pw = s.inverter && powered(s);
        String dist = pw ? String.format(Locale.US, "%.1f NM", Math.abs(e.distDest) / 1852.0) : "-- NM";
        GU.box(c, p, cx, cy + r * 1.30f, r * 0.74f, r * 0.24f, dist, r * 0.15f, pw ? GU.CYAN : GU.GREY);
        GU.box(c, p, cx, cy - r * 0.42f, r * 0.46f, r * 0.20f, String.format(Locale.US, "%03d", ((int) Math.round(s.hdg)) % 360), r * 0.14f, GU.WHITE);
    }
}

/** Turn and slip indicator. */
final class TurnGauge extends Gauge {
    @Override
    void drawFace(Canvas c, float r, Paint p) {
        GU.dial(c, r, p);
        for (int i = -2; i <= 2; i++) {
            float a = 270 + i * 18;
            boolean std = Math.abs(i) == 1;
            GU.line(c, p, r, r, a, r * 0.66f, r * 0.87f, r * (std ? 0.04f : 0.025f), std ? GU.WHITE : GU.GREY);
        }
        GU.text(c, p, "L", r * 0.28f, r * 0.62f, r * 0.20f, GU.WHITE, Paint.Align.CENTER, true);
        GU.text(c, p, "R", r * 1.72f, r * 0.62f, r * 0.20f, GU.WHITE, Paint.Align.CENTER, true);
        GU.text(c, p, "2 MIN", r, r * 0.44f, r * 0.11f, GU.GREY, Paint.Align.CENTER, false);
        GU.text(c, p, "TURN", r, r * 0.30f, r * 0.12f, GU.WHITE, Paint.Align.CENTER, true);
        // slip tube
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF1E2024);
        RectF tube = new RectF(r * 0.45f, r * 1.30f, r * 1.55f, r * 1.58f);
        c.drawRoundRect(tube, r * 0.14f, r * 0.14f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(r * 0.02f);
        p.setColor(GU.GREY);
        c.drawRoundRect(tube, r * 0.14f, r * 0.14f, p);
        c.drawLine(r * 0.88f, r * 1.30f, r * 0.88f, r * 1.58f, p);
        c.drawLine(r * 1.12f, r * 1.30f, r * 1.12f, r * 1.58f, p);
    }

    @Override
    void drawDyn(Canvas c, float cx, float cy, float r, Sim s, GaugeEnv e, Paint p) {
        double rate = Math.max(-6, Math.min(6, s.turnRate));
        float a = (float) (270 + rate / 3.0 * 18);
        GU.needle(c, p, cx, cy, a, r * 0.72f, r * 0.10f, r * 0.045f, GU.WHITE);
        GU.hub(c, p, cx, cy, r * 0.085f);
        p.setStyle(Paint.Style.FILL);
        p.setColor(GU.WHITE);
        c.drawCircle(cx + (float) s.ball * r * 0.32f, cy + r * 0.44f, r * 0.10f, p);
    }
}
