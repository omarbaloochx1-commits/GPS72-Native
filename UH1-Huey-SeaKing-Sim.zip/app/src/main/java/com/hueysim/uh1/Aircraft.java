package com.hueysim.uh1;

/** Per-aircraft constants: UH-1H Iroquois (single engine, skids) and Sea King HAR.3 (twin engine, amphibious hull, retractable gear). */
final class Aircraft {
    static final int HUEY = 0, SEAKING = 1;

    final int id;
    final String name, shortName;
    final int engines;
    final double rotorR, omega100, inertia, ratedKwEach, emptyKg, tref, p0kw, fParBase, vne, vneStart;
    final double fuelCapLb, fuelBaseLbh, fuelSfc;
    final double torqueDiv, torqueLimit;       // kW per torque unit, torque limit (psi or %)
    final double yawRate, pitchOmega, frictionMu;
    final boolean hasGear, amphibious, hasHoist, fuelCockStart;
    final double hullClear;                    // hull bottom above the wheels (m)
    final int[] switches;                      // switch ids in panel order
    final String[] lightNames;
    final String torqueUnit;

    private Aircraft(int id, String name, String shortName, int engines, double rotorR, double omega100, double inertia, double ratedKwEach,
                     double emptyKg, double tref, double p0kw, double fParBase, double vne, double vneStart, double fuelCapLb,
                     double fuelBaseLbh, double fuelSfc, double torqueDiv, double torqueLimit, double yawRate, double pitchOmega,
                     double frictionMu, boolean hasGear, boolean amphibious, boolean hasHoist, boolean fuelCockStart, double hullClear,
                     int[] switches, String[] lightNames, String torqueUnit) {
        this.id = id; this.name = name; this.shortName = shortName; this.engines = engines; this.rotorR = rotorR; this.omega100 = omega100;
        this.inertia = inertia; this.ratedKwEach = ratedKwEach; this.emptyKg = emptyKg; this.tref = tref; this.p0kw = p0kw;
        this.fParBase = fParBase; this.vne = vne; this.vneStart = vneStart; this.fuelCapLb = fuelCapLb; this.fuelBaseLbh = fuelBaseLbh;
        this.fuelSfc = fuelSfc; this.torqueDiv = torqueDiv; this.torqueLimit = torqueLimit; this.yawRate = yawRate; this.pitchOmega = pitchOmega;
        this.frictionMu = frictionMu; this.hasGear = hasGear; this.amphibious = amphibious; this.hasHoist = hasHoist;
        this.fuelCockStart = fuelCockStart; this.hullClear = hullClear; this.switches = switches; this.lightNames = lightNames; this.torqueUnit = torqueUnit;
    }

    static final Aircraft[] ALL = {
        new Aircraft(HUEY, "Bell UH-1H Iroquois", "UH-1H", 1, 7.315, 33.93, 3800, 850, 2365 + 190, 3200, 150, 2.4, 124, 118, 1300, 95, 0.62,
                22.0 / 1.341, 50, 38, 2.0, 0.45, false, false, false, false, 0,
                new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11},
                new String[]{"ENG OIL PRESS", "XMSN OIL PRESS", "XMSN OIL HOT", "ENG CHIP DET", "XMSN CHIP DET", "20 MIN FUEL", "DC GEN", "INVERTER",
                        "HYD PRESS", "GOV EMER", "LOW RPM", "ENGINE OUT", "EGT HIGH", "ROTOR HIGH"}, "PSI"),
        new Aircraft(SEAKING, "Westland Sea King HAR.3", "SEA KING", 2, 9.45, 21.26, 18000, 1100, 6200 + 270, 8400, 270, 3.4, 112, 106, 4000, 130, 0.60,
                11.0, 100, 30, 1.7, 0.10, true, true, true, true, 1.15,
                new int[]{0, 1, 12, 2, 3, 13, 4, 6, 14, 8, 9, 10},
                new String[]{"ENG1 OIL PRESS", "ENG2 OIL PRESS", "XMSN OIL PRESS", "XMSN OIL HOT", "ENG1 FAIL", "ENG2 FAIL", "20 MIN FUEL", "GEN 1 FAIL",
                        "GEN 2 FAIL", "INVERTER", "HYD PRESS", "LOW RPM", "TGT HIGH", "ROTOR HIGH"}, "%")
    };

    static Aircraft get(int id) { return ALL[Math.max(0, Math.min(ALL.length - 1, id))]; }

    /** Panel label of a switch id for this aircraft. */
    String swLabel(int id) {
        switch (id) {
            case 0: return "BATT";
            case 1: return engines > 1 ? "GEN 1" : "GEN";
            case 2: return "INVERTER";
            case 3: return engines > 1 ? "ENG1 FUEL" : "MAIN FUEL";
            case 4: return "START FUEL";
            case 5: return "GOV EMER";
            case 6: return "HYD CONT";
            case 7: return "FORCE TRIM";
            case 8: return "ANTI COL";
            case 9: return "NAV LTS";
            case 10: return "LAND LT";
            case 11: return "STAB AUG";
            case 12: return "GEN 2";
            case 13: return "ENG2 FUEL";
            default: return "GEAR DN";
        }
    }
}
