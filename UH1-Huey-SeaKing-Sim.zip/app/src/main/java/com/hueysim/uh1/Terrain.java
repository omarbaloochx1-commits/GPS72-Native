package com.hueysim.uh1;

/** East-west terrain profiles (maps), helipads and sea level. Heights are metres above sea level. */
final class Terrain {
    private Terrain() { }

    static final int VALLEY = 0, COAST = 1, MOUNTAIN = 2;

    static int map = VALLEY;
    static double[] padX = new double[0], padElev = new double[0], padHalf = new double[0];
    static String[] padName = new String[0];
    static boolean[] padSharp = new boolean[0];
    static boolean seaMap;

    static final double PAD_HALF = 18;

    private static double smooth(double e0, double e1, double v) {
        double t = Math.max(0, Math.min(1, (v - e0) / (e1 - e0)));
        return t * t * (3 - 2 * t);
    }

    private static double sq(double v) { return v * v; }

    static void setMap(int m) {
        map = m;
        seaMap = m == COAST;
        if (m == VALLEY) {
            padX = new double[]{0, 6800, 3300}; padHalf = new double[]{18, 18, 22};
            padName = new String[]{"BASE ALPHA", "FIREBASE BRAVO", "LZ DELTA"};
            padSharp = new boolean[]{false, false, false};
            padElev = new double[]{310, 262, 0};
            padElev[2] = raw(3300);
        } else if (m == COAST) {
            padX = new double[]{0, 1000, 5200, 1950}; padHalf = new double[]{18, 22, 13, 170};
            padName = new String[]{"BASE", "HOSPITAL", "HMS DEFENDER", "AIRFIELD"};
            padSharp = new boolean[]{false, false, true, false};
            padElev = new double[]{38, 0, 9, 0};
            padElev[1] = raw(1000);
            padElev[3] = raw(1950);
        } else {
            padX = new double[]{0, 4200}; padHalf = new double[]{18, 20};
            padName = new String[]{"VALLEY BASE", "RIDGE CAMP"};
            padSharp = new boolean[]{false, false};
            padElev = new double[]{1400, 0};
            padElev[1] = raw(4200);
        }
    }

    /** Natural land profile (may be negative = sea bed on the coast map). */
    static double raw(double x) {
        if (map == VALLEY) {
            double t = Math.max(0, Math.min(1, x / 6800.0));
            double h = 310 - 48 * t;
            double mid = smooth(250, 900, x) * (1 - smooth(5900, 6600, x));
            h += mid * 34 * Math.sin(x / 520.0 + 0.6);
            h += 82 * Math.exp(-sq((x - 2600) / 280.0));
            h += 55 * Math.exp(-sq((x - 4500) / 360.0));
            h += mid * (2.6 * Math.sin(x / 37.0) + 1.4 * Math.sin(x / 11.0));
            if (x < 0) h += Math.min(60, -x * 0.05);
            if (x > 7000) h += Math.min(80, (x - 7000) * 0.04);
            return h;
        } else if (map == COAST) {
            double land = 38 + (14 * Math.sin(x / 420.0 + 0.8) + 4 * Math.sin(x / 90.0)) * smooth(100, 600, x) * (1 - smooth(1900, 2300, x));
            if (x < 0) land += Math.min(40, -x * 0.04);
            double h = land - 78 * smooth(2250, 2900, x);
            if (x > 2900) h -= Math.min(24, (x - 2900) * 0.01);
            return h;
        } else {
            double tt = Math.max(0, Math.min(1, (x - 400) / 3900.0));
            double h = 1400 + 520 * (0.55 * tt + 0.45 * tt * tt * (3 - 2 * tt)) + 90 * Math.exp(-sq((x - 1700) / 260.0));
            h += 18 * Math.sin(x / 210.0) * smooth(300, 3300, x);
            h += 260 * smooth(4300, 5500, x) - 380 * smooth(5900, 7000, x);
            if (x < -200) h += Math.min(120, (-200 - x) * 0.12);
            return h;
        }
    }

    /** Surface height used for ground contact: land, helipads, or the sea surface. */
    static double h(double x) {
        double r = raw(x);
        int best = -1;
        double bd = 1e18;
        for (int i = 0; i < padX.length; i++) {
            double d = Math.abs(x - padX[i]);
            if (d < bd) { bd = d; best = i; }
        }
        double v = r;
        if (best >= 0) {
            if (padSharp[best]) { if (bd <= padHalf[best]) v = padElev[best]; }
            else {
                double w = smooth(padHalf[best], padHalf[best] + 70, bd);
                v = padElev[best] + (r - padElev[best]) * w;
            }
        }
        if (seaMap && v < 0) return 0;
        return v;
    }

    static boolean water(double x) {
        if (!seaMap) return false;
        for (int i = 0; i < padX.length; i++) if (padSharp[i] && Math.abs(x - padX[i]) <= padHalf[i]) return false;
        return raw(x) < 0;
    }

    static double slope(double x) { return (h(x + 2) - h(x - 2)) / 4.0; }

    static double treeLine() { return map == MOUNTAIN ? 1950 : 1e9; }

    /** Deterministic tree density: returns tree height (m) at index i or 0 for none. */
    static double tree(int i) {
        int n = i * 73856093 ^ 19349663;
        n ^= n >>> 13; n *= 0x5bd1e995; n ^= n >>> 15;
        int r = n & 0xff;
        double x = i * 14.0;
        for (int k = 0; k < padX.length; k++) if (Math.abs(x - padX[k]) < padHalf[k] + 70) return 0;
        double hh = h(x);
        if (hh < 1.5 || hh > treeLine()) return 0;
        double dense;
        if (map == VALLEY) dense = smooth(300, 1200, x) * (1 - smooth(6000, 6600, x));
        else if (map == COAST) dense = smooth(100, 600, x) * (1 - smooth(1700, 2200, x)) * 0.8;
        else dense = 0.55 * (1 - smooth(1700, 1950, hh));
        if (r > 40 + 120 * dense) return 0;
        return 5 + (r % 9);
    }
}
