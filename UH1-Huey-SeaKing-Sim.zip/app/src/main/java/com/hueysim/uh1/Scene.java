package com.hueysim.uh1;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import java.util.Locale;
import java.util.Random;

/** Outside view: a vertical east-west slice of the world with the UH-1H in side view. */
final class Scene {
    float camX, camY, zoom = 10f;
    Aircraft ac = Aircraft.get(0);
    double raftX = Double.NaN;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private final Random rnd = new Random(11);
    private boolean camInit;

    // particles: dust (type 0) and exhaust smoke (type 1)
    private static final int MAXP = 90;
    private final float[] px = new float[MAXP], py = new float[MAXP], pvx = new float[MAXP], pvy = new float[MAXP], plife = new float[MAXP], psz = new float[MAXP];
    private final int[] ptype = new int[MAXP];
    private int pc;
    private double clock;

    private float ax, ay, aw, ah;     // current area

    float sx(double wx) { return ax + aw * 0.45f + (float) (wx - camX) * zoom; }

    float sy(double wy) { return ay + ah * 0.58f - (float) (wy - camY) * zoom; }

    void reset(Sim s) { camInit = false; pc = 0; }

    void update(Sim s, double dt) {
        clock += dt;
        if (!camInit) { camX = (float) s.x; camY = (float) s.alt + 2; camInit = true; }
        float k = (float) (1 - Math.exp(-dt * 5));
        camX += ((float) (s.x + s.vx * 0.5) - camX) * k;
        camY += ((float) (s.alt + 3) - camY) * (float) (1 - Math.exp(-dt * 3));
        double agl = Math.max(0, s.agl);
        float zt = (float) (14.5 / (1 + agl / 80.0 + Math.abs(s.vx) / 50.0));
        zoom += (Math.max(3.2f, Math.min(14.5f, zt)) - zoom) * (float) (1 - Math.exp(-dt * 1.5));

        // particles
        float nrN = (float) (s.nr / 100.0);
        if (s.agl < 14 && nrN > 0.7f && s.thrustN > s.massKg() * Sim.G * 0.5 && !s.crashed) {
            int n = (int) (rnd.nextFloat() * 3 * (1 - s.agl / 14.0) + 0.5);
            for (int i = 0; i < n; i++) addP(0, (float) (s.x + (rnd.nextFloat() - 0.5f) * 8), (float) Terrain.h(s.x), (rnd.nextFloat() - 0.5f) * 16, 1 + rnd.nextFloat() * 2, 1.4f, 1.4f + rnd.nextFloat() * 1.8f);
        }
        if (s.lit && s.egt > 430 && rnd.nextFloat() < dt * 22) {
            float face = (float) Math.signum(Math.sin(Math.toRadians(s.hdg)));
            addP(1, (float) (s.x - face * 0.9), (float) (s.alt + 2.9), -face * (2 + rnd.nextFloat() * 3), 1.5f + rnd.nextFloat(), 1.8f, 0.5f + (float) (s.egt - 400) / 600f);
        }
        for (int i = 0; i < pc; i++) {
            plife[i] -= (float) dt;
            px[i] += pvx[i] * (float) dt;
            py[i] += pvy[i] * (float) dt;
            if (ptype[i] == 0) { pvx[i] *= 0.985f; if (py[i] < Terrain.h(px[i])) { py[i] = (float) Terrain.h(px[i]); } pvy[i] *= 0.98f; }
            else { pvy[i] += 0.8f * (float) dt; pvx[i] *= 0.99f; }
        }
        for (int i = pc - 1; i >= 0; i--) if (plife[i] <= 0) removeP(i);
    }

    private void addP(int type, float x, float y, float vx, float vy, float life, float size) {
        if (pc >= MAXP) return;
        px[pc] = x; py[pc] = y; pvx[pc] = vx; pvy[pc] = vy; plife[pc] = life; psz[pc] = size; ptype[pc] = type; pc++;
    }

    private void removeP(int i) {
        pc--;
        px[i] = px[pc]; py[i] = py[pc]; pvx[i] = pvx[pc]; pvy[i] = pvy[pc]; plife[i] = plife[pc]; psz[i] = psz[pc]; ptype[i] = ptype[pc];
    }

    // ------------------------------------------------------------------ drawing
    void draw(Canvas c, RectF a, Sim s, GaugeEnv e) {
        ax = a.left; ay = a.top; aw = a.width(); ah = a.height();
        c.save();
        c.clipRect(a);
        drawSky(c, a);
        drawMountains(c, a);
        drawTerrain(c, a);
        drawStructures(c, a, s);
        drawSea(c, a);
        drawRaft(c, s);
        drawShadow(c, s);
        drawParticles(c, s, 0);
        if (ac.id == Aircraft.SEAKING) drawSeaKing(c, s, e); else drawHuey(c, s, e);
        drawCable(c, s);
        drawParticles(c, s, 1);
        c.restore();
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3);
        p.setColor(0xFF2A2C30);
        c.drawRect(a, p);
    }

    private void drawSky(Canvas c, RectF a) {
        p.setShader(new LinearGradient(0, a.top, 0, a.bottom, new int[]{0xFF2F6DB4, 0xFF7FB1DE, 0xFFD6E6EE, 0xFFF0DDB8}, new float[]{0f, 0.45f, 0.78f, 1f}, Shader.TileMode.CLAMP));
        p.setStyle(Paint.Style.FILL);
        c.drawRect(a, p);
        p.setShader(null);
        // sun with glow (morning, low in the east)
        float sxs = a.left + a.width() * 0.82f - camX * 0.002f * zoom, sys = a.top + a.height() * 0.30f;
        p.setShader(new RadialGradient(sxs, sys, a.height() * 0.28f, new int[]{0xCCFFF3C4, 0x44FFE9A8, 0x00FFE9A8}, new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(sxs, sys, a.height() * 0.28f, p);
        p.setShader(null);
        p.setColor(0xFFFFFBE6);
        c.drawCircle(sxs, sys, a.height() * 0.035f, p);
        // clouds
        float span = a.width() * 3.0f;
        for (int i = 0; i < 9; i++) {
            float baseX = i * span / 9f;
            float x = a.left + mod(baseX - camX * zoom * 0.04f, span) - span * 0.12f;
            float y = a.top + a.height() * (0.07f + 0.30f * frac(i * 0.381f));
            float w = a.width() * (0.10f + 0.07f * frac(i * 0.77f));
            p.setColor(0xCCFFFFFF);
            rf.set(x, y, x + w, y + w * 0.22f);
            c.drawOval(rf, p);
            rf.set(x + w * 0.2f, y - w * 0.10f, x + w * 0.65f, y + w * 0.18f);
            c.drawOval(rf, p);
            rf.set(x + w * 0.45f, y - w * 0.04f, x + w * 0.95f, y + w * 0.22f);
            c.drawOval(rf, p);
        }
    }

    private void drawMountains(Canvas c, RectF a) {
        float horizon = sy(Terrain.h(camX)) - 6 * zoom;
        horizon = Math.min(a.bottom - a.height() * 0.15f, Math.max(a.top + a.height() * 0.35f, horizon));
        for (int layer = 0; layer < 2; layer++) {
            float par = layer == 0 ? 0.015f : 0.035f;
            float amp = a.height() * (layer == 0 ? 0.20f : 0.12f);
            p.setColor(layer == 0 ? 0xFF8EA7BE : 0xFF6F8B7A);
            path.reset();
            path.moveTo(a.left, a.bottom);
            for (float x = a.left; x <= a.right + 16; x += 16) {
                float u = x + camX * zoom * par;
                float h = (float) (0.5 + 0.28 * Math.sin(u * 0.0042 + layer * 2.0) + 0.17 * Math.sin(u * 0.011 + 1.3 * layer) + 0.08 * Math.sin(u * 0.027));
                path.lineTo(x, horizon + 4 - amp * h + (layer == 1 ? 14 : 0));
            }
            path.lineTo(a.right, a.bottom);
            path.close();
            c.drawPath(path, p);
        }
    }

    private void drawTerrain(Canvas c, RectF a) {
        path.reset();
        path.moveTo(a.left, a.bottom + 2);
        for (float x = a.left; x <= a.right + 6; x += 6) path.lineTo(x, sy(Terrain.h(camX + (x - ax - aw * 0.45f) / zoom)));
        path.lineTo(a.right + 6, a.bottom + 2);
        path.close();
        p.setStyle(Paint.Style.FILL);
        int[] tc = Terrain.map == Terrain.MOUNTAIN ? new int[]{0xFF9A8B6E, 0xFF74664F, 0xFF4B4234} : Terrain.map == Terrain.COAST ? new int[]{0xFF7BA356, 0xFF55803C, 0xFF3A5A2C} : new int[]{0xFF6C9A4A, 0xFF4F7A39, 0xFF38552A};
        p.setShader(new LinearGradient(0, a.top + a.height() * 0.45f, 0, a.bottom, tc, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        c.drawPath(path, p);
        p.setShader(null);
        // surface edge
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2, zoom * 0.18f));
        p.setColor(Terrain.map == Terrain.MOUNTAIN ? 0xFFB5A584 : 0xFF8DBE62);
        path.reset();
        boolean first = true;
        for (float x = a.left; x <= a.right + 6; x += 6) {
            float y = sy(Terrain.h(camX + (x - ax - aw * 0.45f) / zoom));
            if (first) { path.moveTo(x, y); first = false; } else path.lineTo(x, y);
        }
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);
        // trees
        double half = aw / zoom * 0.7;
        int i0 = (int) Math.floor((camX - half) / 14.0), i1 = (int) Math.ceil((camX + half) / 14.0);
        for (int i = i0; i <= i1; i++) {
            double th = Terrain.tree(i);
            if (th <= 0) continue;
            double wx = i * 14.0 + (i * 7 % 5);
            float bx = sx(wx), by = sy(Terrain.h(wx));
            float hh = (float) th * zoom, ww = hh * 0.38f;
            p.setColor(0xFF4B3A28);
            c.drawRect(bx - hh * 0.04f, by - hh * 0.25f, bx + hh * 0.04f, by + 1, p);
            p.setColor(((int) th) % 2 == 0 ? 0xFF2E6A3A : 0xFF3A7A40);
            path.reset();
            path.moveTo(bx, by - hh);
            path.lineTo(bx + ww, by - hh * 0.22f);
            path.lineTo(bx - ww, by - hh * 0.22f);
            path.close();
            c.drawPath(path, p);
        }
    }

    private void drawStructures(Canvas c, RectF a, Sim s) {
        for (int i = 0; i < Terrain.padX.length; i++) {
            double wx = Terrain.padX[i], elev = Terrain.padElev[i], half = Terrain.padHalf[i];
            String nm = Terrain.padName[i];
            float x = sx(wx);
            if (x < ax - 700 || x > ax + aw + 700) continue;
            if (nm.equals("HMS DEFENDER")) drawShip(c, wx, elev);
            else if (nm.equals("AIRFIELD")) drawAirfield(c, wx, elev, half);
            else drawPad(c, wx, elev, nm, half);
            scenery(c, nm, wx, elev);
        }
        // kilometre posts on land
        p.setTextAlign(Paint.Align.CENTER);
        for (int k = 1; k <= 7; k++) {
            double wx = k * 1000.0;
            float x = sx(wx);
            if (x < ax - 50 || x > ax + aw + 50 || Terrain.water(wx) || Terrain.seaMap) continue;
            float y = sy(Terrain.h(wx));
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFE8E8E8);
            c.drawRect(x - 2, y - 5 * zoom, x + 2, y, p);
            p.setColor(0xFFFFD21F);
            c.drawRect(x - 4 * zoom, y - 8 * zoom, x + 4 * zoom, y - 5 * zoom, p);
            GU.text(c, p, k + " km", x, y - 6.5f * zoom, Math.max(10, zoom * 1.9f), 0xFF202020, Paint.Align.CENTER, true);
        }
    }

    private void box(Canvas c, double wx, double y0, double y1, double w, int color) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.drawRect(sx(wx), sy(y1), sx(wx + w), sy(y0), p);
    }

    private void tri(Canvas c, double x0, double y0, double x1, double y1, double x2, double y2, int color) {
        path.reset();
        path.moveTo(sx(x0), sy(y0));
        path.lineTo(sx(x1), sy(y1));
        path.lineTo(sx(x2), sy(y2));
        path.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.drawPath(path, p);
    }

    private void mast(Canvas c, double wx, double base, double h, boolean light) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2, zoom * 0.3f));
        p.setColor(0xFFB8BCC0);
        c.drawLine(sx(wx), sy(base), sx(wx), sy(base + h), p);
        p.setStyle(Paint.Style.FILL);
        if (light && ((int) (clock * 1.4)) % 2 == 0) { p.setColor(0xFFFF3030); c.drawCircle(sx(wx), sy(base + h), Math.max(3, zoom * 0.5f), p); }
    }

    private void tent(Canvas c, double wx, double elev, int color) {
        tri(c, wx - 4.5, elev, wx, elev + 4.2, wx + 4.5, elev, color);
    }

    private void scenery(Canvas c, String nm, double wx, double elev) {
        if (nm.equals("BASE ALPHA") || nm.equals("BASE") || nm.equals("VALLEY BASE")) {
            double hx = wx - 95, hy = Terrain.h(hx);
            box(c, hx - 18, hy, hy + 8, 36, 0xFF7C8084);
            tri(c, hx - 19, hy + 8, hx, hy + 12, hx + 19, hy + 8, 0xFF5A5E62);
            box(c, hx - 8, hy, hy + 6, 16, 0xFF2A2C30);
            mast(c, wx + 60, Terrain.h(wx + 60), 14, true);
        } else if (nm.equals("FIREBASE BRAVO")) {
            for (int i = 0; i < 3; i++) tent(c, wx + 70 + i * 11, Terrain.h(wx + 70 + i * 11), i == 1 ? 0xFF6B7A4A : 0xFF59663D);
            mast(c, wx - 85, Terrain.h(wx - 85), 22, true);
        } else if (nm.equals("RIDGE CAMP")) {
            for (int i = 0; i < 2; i++) tent(c, wx + 45 + i * 12, Terrain.h(wx + 45 + i * 12), i == 0 ? 0xFF6B7A4A : 0xFF8A8F5A);
            mast(c, wx - 60, Terrain.h(wx - 60), 20, true);
        } else if (nm.equals("HOSPITAL")) {
            double bx = wx + 40, by = Terrain.h(bx);
            box(c, bx, by, by + 14, 34, 0xFFE9ECEE);
            box(c, bx, by + 13, by + 14.8, 34, 0xFF9AA0A6);
            for (int r = 0; r < 3; r++) for (int k = 0; k < 5; k++) box(c, bx + 2.5 + k * 6, by + 2 + r * 3.8, by + 4.6 + r * 3.8, 3.2, 0xFF6FA8CF);
            box(c, bx + 12.5, by + 15, by + 22, 9, 0xFFFFFFFF);
            box(c, bx + 15.5, by + 16, by + 21, 3, 0xFFD62B2B);
            box(c, bx + 13.5, by + 17.5, by + 19.5, 7, 0xFFD62B2B);
        } else if (nm.equals("LZ DELTA")) {
            for (int k = 0; k < 9; k++) {
                double yy = elev + 2 + k * 4.2, xx = wx + 14 + windNow * 0.5 * k + 1.8 * Math.sin(clock * 1.4 + k * 0.9);
                float rr = (float) ((2.0 + 0.55 * k) * zoom);
                p.setStyle(Paint.Style.FILL);
                p.setColor(((int) (Math.max(0.12, 0.62 - 0.065 * k) * 255)) << 24 | 0xFF7A1F);
                c.drawCircle(sx(xx), sy(yy), rr * 0.55f, p);
            }
            for (int k = 0; k < 3; k++) {                         // medics and stretcher
                double fx = wx - 10 + k * 1.6;
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeWidth(Math.max(2, zoom * 0.22f));
                p.setColor(0xFF2E3A2A);
                c.drawLine(sx(fx), sy(elev), sx(fx), sy(elev + 1.5), p);
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFFE0B48A);
                c.drawCircle(sx(fx), sy(elev + 1.8), Math.max(2, zoom * 0.28f), p);
            }
            box(c, wx - 6.5, elev + 0.2, elev + 0.55, 3.0, 0xFFC03A22);
        }
    }

    private void drawPad(Canvas c, double wx, double elev, String name, double half) {
        float x0 = sx(wx - half), x1 = sx(wx + half), y = sy(elev);
        if (x1 < ax - 100 || x0 > ax + aw + 100) return;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF9A9C9E);
        c.drawRect(x0, y - 0.4f * zoom, x1, y + 0.5f * zoom, p);
        p.setColor(0xFFF2C21B);
        c.drawRect(x0, y - 0.4f * zoom, x0 + 0.5f * zoom, y, p);
        c.drawRect(x1 - 0.5f * zoom, y - 0.4f * zoom, x1, y, p);
        float cx = (x0 + x1) / 2;
        GU.text(c, p, "H", cx, y - 0.2f * zoom, Math.max(8, zoom * 2.6f), 0xFFFFFFFF, Paint.Align.CENTER, true);
        windsock(c, wx + half + 6, elev);
        p.setColor(0xFF1C1E20);
        c.drawRect(cx - 12 * zoom, y - 9 * zoom, cx + 12 * zoom, y - 5.4f * zoom, p);
        GU.text(c, p, name, cx, y - 7.2f * zoom, Math.max(9, zoom * 1.5f), 0xFFFFFFFF, Paint.Align.CENTER, true);
    }

    private void windsock(Canvas c, double wx, double elev) {
        float wxp = sx(wx), y = sy(elev);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2, zoom * 0.25f));
        p.setColor(0xFFDDDDDD);
        c.drawLine(wxp, y, wxp, y - 7 * zoom, p);
        p.setStyle(Paint.Style.FILL);
        double w = windNow;
        float dir = w >= 0 ? 1 : -1;
        float droop = (float) Math.max(0, 1 - Math.abs(w) / 7.0) * 55;
        for (int i = 0; i < 4; i++) {
            float segX = wxp + dir * (i + 0.5f) * 1.1f * zoom * (float) Math.cos(Math.toRadians(droop));
            float segY = y - 7 * zoom + (i + 0.5f) * 1.1f * zoom * (float) Math.sin(Math.toRadians(droop));
            p.setColor(i % 2 == 0 ? 0xFFFF7A1F : 0xFFFFFFFF);
            rf.set(segX - 0.6f * zoom, segY - (0.55f - i * 0.08f) * zoom, segX + 0.6f * zoom, segY + (0.55f - i * 0.08f) * zoom);
            c.drawRect(rf, p);
        }
    }

    private void drawAirfield(Canvas c, double wx, double elev, double half) {
        float x0 = sx(wx - half), x1 = sx(wx + half), y = sy(elev);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF4A4D52);
        c.drawRect(x0, y - 0.3f * zoom, x1, y + 0.6f * zoom, p);
        p.setColor(0xFFF0F0F0);
        for (double d = -half + 25; d < half - 25; d += 24) c.drawRect(sx(wx + d), y - 0.25f * zoom, sx(wx + d + 10), y - 0.05f * zoom, p);
        for (int k = 0; k < 4; k++) { c.drawRect(sx(wx - half + 3), y - (0.3f - 0.05f * k) * zoom, sx(wx - half + 14), y - (0.2f - 0.05f * k) * zoom, p); }
        GU.text(c, p, "AIRFIELD", (x0 + x1) / 2, y - 7.5f * zoom, Math.max(9, zoom * 1.7f), 0xFFFFFFFF, Paint.Align.CENTER, true);
        double tx = wx - half - 28, ty = Terrain.h(tx);
        box(c, tx, ty, ty + 9, 8, 0xFFC9CED2);
        box(c, tx - 1.5, ty + 9, ty + 12, 11, 0xFF6FA8CF);
        box(c, tx - 2, ty + 12, ty + 12.8, 12, 0xFF55595E);
        windsock(c, wx + half - 16, elev);
    }

    private void drawShip(Canvas c, double px, double deck) {
        float u = zoom;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF7E858B);
        path.reset();
        path.moveTo(sx(px - 45), sy(deck));
        path.lineTo(sx(px - 45), sy(-3));
        path.lineTo(sx(px + 50), sy(-5.5));
        path.lineTo(sx(px + 84), sy(7.5));
        path.lineTo(sx(px + 86), sy(deck + 3));
        path.lineTo(sx(px + 70), sy(deck));
        path.close();
        c.drawPath(path, p);
        p.setColor(0xFF5C6368);
        c.drawRect(sx(px - 45), sy(deck), sx(px + 70), sy(deck - 1.0), p);
        box(c, px + 16, deck, deck + 10, 28, 0xFF9AA2A8);
        box(c, px + 20, deck + 6, deck + 8.4, 20, 0xFF3E6A86);
        box(c, px + 27, deck + 10, deck + 17, 8, 0xFF4B5258);
        mast(c, px + 38, deck + 10, 26, true);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2, u * 0.4f));
        p.setColor(0xFFC9CED2);
        c.drawLine(sx(px + 34), sy(deck + 24), sx(px + 42), sy(deck + 24), p);
        box(c, px + 58, deck, deck + 3.2, 4, 0xFF4B5258);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2, u * 0.25f));
        p.setColor(0xFFE8E8E8);
        c.drawLine(sx(px - 45), sy(deck + 1.4), sx(px - 13.5), sy(deck + 1.4), p);
        c.drawLine(sx(px + 13.5), sy(deck + 1.4), sx(px + 16), sy(deck + 1.4), p);
    }

    /** Orange life raft with a waving survivor; the survivor disappears once hooked. */
    private void drawRaft(Canvas c, Sim s) {
        if (Double.isNaN(raftX)) return;
        float x = sx(raftX);
        if (x < ax - 60 || x > ax + aw + 60) return;
        float bob = (float) (0.35 * Math.sin(clock * 1.3) * zoom);
        float y = sy(0) + bob * 0.4f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFF7A1F);
        rf.set(x - 2.6f * zoom, y - 0.55f * zoom, x + 2.6f * zoom, y + 0.45f * zoom);
        c.drawOval(rf, p);
        p.setColor(0xFFB84A0C);
        rf.set(x - 1.8f * zoom, y - 0.30f * zoom, x + 1.8f * zoom, y + 0.15f * zoom);
        c.drawOval(rf, p);
        p.setColor(0x88B0FF70);
        rf.set(x - 6 * zoom, y + 0.1f * zoom, x + 6 * zoom, y + 0.6f * zoom);
        c.drawOval(rf, p);
        if (!s.hookLoaded) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(2, zoom * 0.28f));
            p.setColor(0xFFE23B2E);
            c.drawLine(x, y - 0.4f * zoom, x, y - 1.7f * zoom, p);
            p.setColor(0xFFE0B48A);
            float wv = (float) Math.sin(clock * 5) * 0.5f;
            c.drawLine(x, y - 1.5f * zoom, x + (0.9f + wv * 0.3f) * zoom, y - (2.4f + wv) * zoom, p);
            c.drawLine(x, y - 1.5f * zoom, x - 0.8f * zoom, y - 0.9f * zoom, p);
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(x, y - 2.0f * zoom, Math.max(2.5f, zoom * 0.4f), p);
        }
    }

    private void drawSea(Canvas c, RectF a) {
        if (!Terrain.seaMap) return;
        float y0 = sy(0);
        if (y0 > a.bottom) return;
        float top = Math.max(a.top, y0);
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, top, 0, a.bottom, 0xAA2E86B8, 0xEE0E3A5E, Shader.TileMode.CLAMP));
        c.drawRect(a.left, top, a.right, a.bottom, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2, zoom * 0.22f));
        p.setColor(0xCCCFEFFF);
        path.reset();
        boolean first = true;
        for (float x = a.left; x <= a.right + 8; x += 8) {
            float yy = y0 + (float) (Math.sin(x * 0.035 + clock * 1.8) * 0.28 + Math.sin(x * 0.011 - clock) * 0.45) * zoom * 0.5f;
            if (first) { path.moveTo(x, yy); first = false; } else path.lineTo(x, yy);
        }
        c.drawPath(path, p);
        p.setStrokeWidth(Math.max(1.5f, zoom * 0.12f));
        p.setColor(0x66FFFFFF);
        for (int k = 1; k <= 4; k++) {
            float yy = y0 + k * zoom * 1.6f;
            if (yy > a.bottom) break;
            for (float x = a.left + (k * 37) % 90; x < a.right; x += 90) {
                float xx = x + (float) Math.sin(clock * 0.8 + k) * 12;
                c.drawLine(xx, yy, xx + 26, yy, p);
            }
        }
    }

    double windNow;

    private void drawShadow(Canvas c, Sim s) {
        double gh = Terrain.h(s.x);
        float a = (float) Math.max(0, 0.45 - s.agl / 60.0);
        if (a <= 0) return;
        p.setStyle(Paint.Style.FILL);
        p.setColor((int) (a * 255) << 24);
        float cx = sx(s.x), cy = sy(gh);
        rf.set(cx - 7 * zoom, cy - 0.25f * zoom, cx + 7 * zoom, cy + 0.35f * zoom);
        c.drawOval(rf, p);
    }

    private void drawParticles(Canvas c, Sim s, int type) {
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < pc; i++) {
            if (ptype[i] != type) continue;
            float t = Math.max(0, Math.min(1, plife[i] / 1.6f));
            float rr = psz[i] * zoom * (type == 0 ? (1.2f - 0.5f * t) : (0.7f + (1 - t)));
            if (type == 0) p.setColor((int) (t * 130) << 24 | (Terrain.water(px[i]) ? 0xE8F4FF : 0xC9B58A));
            else p.setColor((int) (t * 150) << 24 | 0x303030);
            c.drawCircle(sx(px[i]), sy(py[i]), Math.max(1.5f, rr * 0.5f), p);
        }
    }

    // ------------------------------------------------------------------ helicopter
    private void poly(Canvas c, float[] pts, int color) {
        path.reset();
        path.moveTo(pts[0], pts[1]);
        for (int i = 2; i < pts.length; i += 2) path.lineTo(pts[i], pts[i + 1]);
        path.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.drawPath(path, p);
    }

    private void drawHuey(Canvas c, Sim s, GaugeEnv e) {
        float face = (float) Math.sin(Math.toRadians(s.hdg));
        float sgn = face >= 0 ? 1 : -1;
        float sxs = sgn * Math.max(0.16f, Math.abs(face));
        float u = zoom;                                   // pixels per metre
        c.save();
        c.translate(sx(s.x), sy(s.alt));
        c.scale(sxs, 1f);
        c.rotate((float) -Math.toDegrees(s.pitch));
        // everything below in metres relative to the skid bottom, x forward, y up = negative
        c.save();
        c.scale(u, u);
        float nrN = (float) (s.nr / 100.0);
        // --- skids
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(0.16f);
        p.setColor(0xFF1E1F21);
        c.drawLine(-2.3f, -0.12f, 2.1f, -0.12f, p);
        c.drawLine(2.1f, -0.12f, 2.7f, -0.55f, p);
        c.drawLine(-1.2f, -0.12f, -1.0f, -0.95f, p);
        c.drawLine(1.1f, -0.12f, 0.95f, -0.95f, p);
        p.setStrokeCap(Paint.Cap.BUTT);
        // --- tail boom + fin
        poly(c, new float[]{-2.0f, -1.45f, -2.0f, -2.20f, -8.5f, -2.05f, -8.7f, -1.75f}, 0xFF485736);
        poly(c, new float[]{-7.3f, -1.95f, -8.55f, -3.85f, -9.05f, -3.85f, -8.95f, -1.7f}, 0xFF485736);
        poly(c, new float[]{-6.6f, -1.95f, -7.9f, -2.0f, -7.7f, -1.55f, -6.5f, -1.65f}, 0xFF3C4A2D);
        p.setColor(0xFFE8C21B);
        c.drawRect(-8.0f, -2.2f, -7.7f, -1.7f, p);
        // --- fuselage
        poly(c, new float[]{-2.4f, -0.85f, -2.5f, -2.0f, -1.6f, -2.45f, 1.2f, -2.5f, 2.6f, -2.25f, 3.3f, -1.5f, 3.4f, -1.0f, 3.0f, -0.80f}, 0xFF51623D);
        poly(c, new float[]{-2.4f, -0.85f, 3.0f, -0.80f, 3.3f, -1.05f, -2.45f, -1.1f}, 0xFF3A4729);
        // engine deck and transmission fairing
        poly(c, new float[]{-1.9f, -2.45f, -1.5f, -3.0f, 0.9f, -3.05f, 1.2f, -2.5f}, 0xFF4A5A38);
        poly(c, new float[]{-1.4f, -2.7f, -1.1f, -3.0f, 0.5f, -3.0f, 0.6f, -2.7f}, 0xFF2D3322);
        // windows
        poly(c, new float[]{1.35f, -2.35f, 2.55f, -2.15f, 3.1f, -1.5f, 1.35f, -1.5f}, 0xCC8FC4E0);
        poly(c, new float[]{-0.9f, -2.30f, 1.15f, -2.30f, 1.15f, -1.5f, -0.9f, -1.5f}, 0xAA7FB3D0);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.07f);
        p.setColor(0xFF2A3220);
        c.drawLine(-1.2f, -2.35f, -1.2f, -0.9f, p);
        c.drawLine(1.25f, -2.4f, 1.25f, -0.9f, p);
        // pilot helmet
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF222426);
        c.drawCircle(1.9f, -1.85f, 0.26f, p);
        c.drawCircle(0.55f, -1.85f, 0.24f, p);
        // lights
        if (s.nav && Gauge.powered(s)) {
            p.setColor(0xFF2BFF5C);
            c.drawCircle(3.15f, -1.15f, 0.12f, p);
            p.setColor(0xFFFFFFFF);
            c.drawCircle(-9.0f, -3.5f, 0.1f, p);
        }
        if (s.acol && Gauge.powered(s) && e.blink) { p.setColor(0xFFFF2A2A); c.drawCircle(-1.0f, -3.1f, 0.2f, p); c.drawCircle(-8.9f, -3.9f, 0.16f, p); }
        if (s.landLt && Gauge.powered(s)) {
            p.setShader(new LinearGradient(3.2f, -1.0f, 14f, 3f, 0x66FFF2B0, 0x00FFF2B0, Shader.TileMode.CLAMP));
            path.reset();
            path.moveTo(3.2f, -1.0f);
            path.lineTo(15f, 0.5f);
            path.lineTo(15f, 5.5f);
            path.close();
            c.drawPath(path, p);
            p.setShader(null);
            p.setColor(0xFFFFF4C0);
            c.drawCircle(3.3f, -1.0f, 0.14f, p);
        }
        // --- tail rotor (seen face-on): spinning two-bladed disc
        float tr = 1.25f, tx = -8.75f, ty = -2.7f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(((int) (Math.min(1, nrN) * 70)) << 24 | 0x202020);
        c.drawCircle(tx, ty, tr, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.14f);
        p.setColor(0xCC15161A);
        double ta = s.rotorAz * 3.1;
        c.drawLine(tx + (float) Math.cos(ta) * tr, ty + (float) Math.sin(ta) * tr, tx - (float) Math.cos(ta) * tr, ty - (float) Math.sin(ta) * tr, p);
        // --- main rotor
        float hubY = -3.7f, hubX = 0.2f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.28f);
        p.setColor(0xFF1A1B1D);
        c.drawLine(hubX, -3.0f, hubX, hubY, p);
        c.save();
        c.rotate((float) Math.toDegrees(s.disc + s.pitch), hubX, hubY);
        float R = (float) ac.rotorR;
        float cone = 0.04f + (nrN < 0.9f ? (0.9f - nrN) * 0.25f : 0f);               // blades droop at low rpm
        float az = (float) s.rotorAz;
        float len = R * (float) Math.abs(Math.cos(az));
        float dir = (float) Math.signum(Math.cos(az));
        if (nrN > 0.35f) {                                      // translucent disc
            rf.set(hubX - R, hubY - 0.35f - cone * R * 0.6f, hubX + R, hubY + 0.18f);
            p.setStyle(Paint.Style.FILL);
            p.setColor(((int) (Math.min(1, nrN) * 52)) << 24 | 0xB0B4B8);
            c.drawOval(rf, p);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.34f);
        p.setColor(0xFF121315);
        float tipY = hubY - cone * len * 0.9f + (nrN < 0.5f ? (0.5f - nrN) * 0.9f * len * 0.1f : 0f);
        c.drawLine(hubX - dir * len, tipY, hubX + dir * len, tipY, p);
        // stabilizer bar and paddles
        float bl = 2.2f * (float) Math.abs(Math.sin(az));
        p.setStrokeWidth(0.09f);
        c.drawLine(hubX - bl, hubY + 0.35f, hubX + bl, hubY + 0.35f, p);
        p.setStyle(Paint.Style.FILL);
        rf.set(hubX + bl - 0.35f, hubY + 0.27f, hubX + bl + 0.35f, hubY + 0.43f);
        c.drawOval(rf, p);
        rf.set(hubX - bl - 0.35f, hubY + 0.27f, hubX - bl + 0.35f, hubY + 0.43f);
        c.drawOval(rf, p);
        c.restore();
        c.restore();   // u scale
        c.restore();   // sprite transform
    }

    /** Small arrow at the screen edge that points to the current objective when it is off-screen. */
    void drawBearing(Canvas c, RectF a, Sim s, double targetX, String name) {
        double d = targetX - s.x;
        float x = sx(targetX);
        if (x > a.left + 30 && x < a.right - 30) return;
        boolean right = d > 0;
        float cx = right ? a.right - 36 : a.left + 36, cy = a.top + a.height() * 0.46f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xCCFFD21F);
        path.reset();
        float k = right ? 1 : -1;
        path.moveTo(cx + 16 * k, cy);
        path.lineTo(cx - 8 * k, cy - 14);
        path.lineTo(cx - 8 * k, cy + 14);
        path.close();
        c.drawPath(path, p);
        GU.text(c, p, String.format(Locale.US, "%s %.1f km", name, Math.abs(d) / 1000.0), cx - 14 * k, cy + 26, 16, 0xFFFFFFFF, right ? Paint.Align.RIGHT : Paint.Align.LEFT, true);
    }

    /** Rescue winch cable with hook (and the survivor once hooked). */
    private void drawCable(Canvas c, Sim s) {
        if (!ac.hasHoist || s.cableLen < 0.2) return;
        float dir = Math.sin(Math.toRadians(s.hdg)) >= 0 ? 1 : -1;
        double wx = s.x + dir * 2.2;
        float x = sx(wx), y0 = sy(s.alt + 3.8), y1 = sy(s.alt + 3.8 - s.cableLen);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2, zoom * 0.14f));
        p.setColor(0xFF1A1B1D);
        c.drawLine(x, y0, x, y1, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFC21F);
        c.drawCircle(x, y1, Math.max(3, zoom * 0.3f), p);
        if (s.hookLoaded) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(2, zoom * 0.28f));
            p.setColor(0xFFE23B2E);
            c.drawLine(x, y1, x, y1 + 1.4f * zoom, p);
            p.setColor(0xFFE0B48A);
            c.drawLine(x, y1 + 0.3f * zoom, x - 0.7f * zoom, y1 + 0.9f * zoom, p);
            c.drawLine(x, y1 + 0.3f * zoom, x + 0.7f * zoom, y1 + 0.9f * zoom, p);
            p.setStyle(Paint.Style.FILL);
            c.drawCircle(x, y1 - 0.1f * zoom, Math.max(2.5f, zoom * 0.35f), p);
        }
    }

    // ------------------------------------------------------------------ Sea King
    private void drawSeaKing(Canvas c, Sim s, GaugeEnv e) {
        float face = (float) Math.sin(Math.toRadians(s.hdg));
        float sgn = face >= 0 ? 1 : -1;
        float sxs = sgn * Math.max(0.16f, Math.abs(face));
        float u = zoom;
        float nrN = (float) (s.nr / 100.0);
        c.save();
        c.translate(sx(s.x), sy(s.alt));
        c.scale(sxs, 1f);
        c.rotate((float) -Math.toDegrees(s.pitch));
        c.save();
        c.scale(u, u);
        int yellow = 0xFFE2B31B, dyellow = 0xFFB98C0C;
        float gp = (float) s.gearPos;
        // --- tail pylon and stabiliser
        poly(c, new float[]{-6.0f, -1.9f, -10.9f, -4.8f, -11.6f, -6.9f, -10.2f, -6.9f, -6.3f, -4.1f}, yellow);
        poly(c, new float[]{-9.6f, -5.4f, -11.8f, -5.0f, -11.8f, -5.4f, -9.9f, -5.8f}, dyellow);
        // --- hull
        poly(c, new float[]{-6.6f, -1.2f, 5.2f, -1.2f, 7.0f, -1.9f, 7.6f, -2.9f, 6.6f, -3.9f, 5.2f, -4.3f, 3.4f, -4.4f, -4.0f, -4.5f, -6.4f, -3.8f}, yellow);
        poly(c, new float[]{-6.6f, -1.2f, 5.2f, -1.2f, 6.2f, -1.7f, -6.5f, -1.7f}, dyellow);
        // sponson
        poly(c, new float[]{-1.6f, -1.3f, 3.2f, -1.3f, 3.5f, -2.3f, -1.3f, -2.3f}, dyellow);
        // engine nacelles and gearbox fairing
        poly(c, new float[]{-2.4f, -4.5f, -1.8f, -5.2f, 1.4f, -5.2f, 1.9f, -4.5f}, 0xFFC99D14);
        poly(c, new float[]{-0.6f, -5.2f, -0.2f, -5.8f, 0.9f, -5.8f, 1.2f, -5.2f}, 0xFF9B7A10);
        // stripe, windows, door and winch
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFD62B2B);
        c.drawRect(-6.2f, -2.75f, 6.3f, -2.5f, p);
        poly(c, new float[]{5.0f, -4.15f, 6.5f, -3.8f, 7.2f, -2.9f, 5.0f, -2.9f}, 0xCC8FC4E0);
        p.setColor(0xCC7FB3D0);
        c.drawCircle(2.9f, -3.55f, 0.30f, p);
        c.drawCircle(1.6f, -3.55f, 0.30f, p);
        c.drawCircle(0.3f, -3.55f, 0.30f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.07f);
        p.setColor(0xFF4C3E08);
        c.drawLine(-2.9f, -4.3f, -2.9f, -1.5f, p);
        c.drawLine(-0.9f, -4.3f, -0.9f, -1.5f, p);
        p.setStrokeWidth(0.18f);
        p.setColor(0xFF2A2C30);
        c.drawLine(-0.9f, -3.9f, 1.8f, -3.9f, p);
        c.drawLine(1.8f, -3.9f, 2.3f, -3.6f, p);
        // helmets
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF222426);
        c.drawCircle(6.0f, -3.35f, 0.26f, p);
        c.drawCircle(4.7f, -3.35f, 0.24f, p);
        // --- landing gear (retracts into the sponson)
        if (gp > 0.05f) {
            float lift = (1 - gp) * 1.0f;
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(0.14f);
            p.setColor(0xFF2A2C30);
            c.drawLine(1.0f, -1.3f, 1.0f, -0.5f - lift, p);
            c.drawLine(-6.3f, -1.8f, -6.4f, -0.55f - lift, p);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF121315);
            c.drawCircle(1.0f, -0.5f - lift, 0.5f, p);
            c.drawCircle(-6.4f, -0.55f - lift, 0.36f, p);
            p.setColor(0xFF6A6E75);
            c.drawCircle(1.0f, -0.5f - lift, 0.2f, p);
        }
        // --- lights
        if (s.nav && Gauge.powered(s)) { p.setColor(0xFF2BFF5C); c.drawCircle(7.3f, -2.5f, 0.12f, p); p.setColor(0xFFFFFFFF); c.drawCircle(-11.5f, -6.9f, 0.1f, p); }
        if (s.acol && Gauge.powered(s) && e.blink) { p.setColor(0xFFFF2A2A); c.drawCircle(0.3f, -6.0f, 0.2f, p); c.drawCircle(-11.0f, -7.0f, 0.16f, p); }
        if (s.landLt && Gauge.powered(s)) {
            p.setShader(new LinearGradient(7.2f, -2.2f, 20f, 3f, 0x66FFF2B0, 0x00FFF2B0, Shader.TileMode.CLAMP));
            path.reset();
            path.moveTo(7.2f, -2.2f);
            path.lineTo(20f, 0.8f);
            path.lineTo(20f, 7f);
            path.close();
            c.drawPath(path, p);
            p.setShader(null);
        }
        // --- tail rotor (4 blades, seen face-on)
        float tr = 1.5f, tx = -11.3f, ty = -6.2f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(((int) (Math.min(1, nrN) * 70)) << 24 | 0x202020);
        c.drawCircle(tx, ty, tr, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.13f);
        p.setColor(0xCC15161A);
        double ta = s.rotorAz * 3.1;
        for (int k = 0; k < 2; k++) {
            double a2 = ta + k * Math.PI / 2;
            c.drawLine(tx + (float) Math.cos(a2) * tr, ty + (float) Math.sin(a2) * tr, tx - (float) Math.cos(a2) * tr, ty - (float) Math.sin(a2) * tr, p);
        }
        // --- main rotor, five blades
        float hubX = 0.3f, hubY = -5.9f, R = (float) ac.rotorR;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.34f);
        p.setColor(0xFF1A1B1D);
        c.drawLine(hubX, -5.2f, hubX, hubY, p);
        c.save();
        c.rotate((float) Math.toDegrees(s.disc + s.pitch), hubX, hubY);
        float cone = 0.04f + (nrN < 0.9f ? (0.9f - nrN) * 0.25f : 0f);
        if (nrN > 0.35f) {
            rf.set(hubX - R, hubY - 0.40f - cone * R * 0.6f, hubX + R, hubY + 0.2f);
            p.setStyle(Paint.Style.FILL);
            p.setColor(((int) (Math.min(1, nrN) * 52)) << 24 | 0xB0B4B8);
            c.drawOval(rf, p);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.32f);
        p.setColor(0xFF121315);
        for (int k = 0; k < 5; k++) {
            double az = s.rotorAz + k * 2 * Math.PI / 5;
            float len = R * (float) Math.cos(az);
            float tipY = hubY - cone * Math.abs(len) * 0.9f;
            c.drawLine(hubX, hubY, hubX + len, tipY, p);
        }
        c.restore();
        c.restore();   // u scale
        c.restore();   // sprite transform
    }

    private static float frac(double v) { return (float) (v - Math.floor(v)); }

    private static float mod(float a, float b) { float r = a % b; return r < 0 ? r + b : r; }
}
