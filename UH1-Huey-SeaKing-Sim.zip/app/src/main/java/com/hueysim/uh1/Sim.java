package com.hueysim.uh1;

/**
 * Helicopter simulation core (pure Java, no Android classes) for the UH-1H and the Sea King.
 *
 * 2-D (vertical east-west slice) flight model built on momentum theory: rotor thrust from collective, rotor speed and inflow,
 * induced + profile + parasite power, ground effect, autorotation; one or two turboshaft engines (N1 gas producer, EGT, torque)
 * driving the rotor through a governor (AUTO) or by hand (EMER); 24 V electrical system, hydraulics, fuel, oils,
 * retractable gear and rescue winch (Sea King) and the caution panel.
 */
final class Sim {
    static final double G = 9.80665;
    static final int NL = 14;

    final Aircraft ac;
    final double discA;
    final boolean[] light = new boolean[NL];

    /** One turboshaft engine. */
    static final class Eng {
        boolean fuelOn, starterBtn, genSw, lit, failed, damaged, hot, starterActive, genOnline, wasLit;
        double n1, egt, torque, pDel, pCmd, lightTimer, overTempT, health = 1, oilP, oilT;
    }

    final Eng[] eng;

    // ---- pilot controls
    double collective, cyclic, pedal, throttle;                 // 0..1, -1..1 (+fwd), -1..1 (+right), 0..1
    boolean batt, gen, fuelMain, fuelStart, inverter, hyd, forceTrim = true, acol, nav, landLt;
    boolean gen2, fuel2, starter2, gearCmd = true;
    boolean govAuto = true, starterBtn;
    boolean assist = true;                                      // stability augmentation
    int hoistCmd;                                               // -1 raise, 0 stop, +1 lower

    // ---- configuration (set before reset)
    double startX = 0, fieldElev = 310, oatField = 22, windBase = 3.5, fuelStartLb = 780, payloadKg = 150;

    // ---- environment
    double windX = 3.5, rho = 1.2, sigma = 1.0, oatNow = 22;

    // ---- aircraft state
    double x, alt, vx, vz, hdg = 90, pitch, pitchRate, disc, yawRate;
    boolean onGround = true, crashed;
    String crashMsg = "";
    double rotorAz, gearPos = 1, cableLen;
    boolean hookLoaded;

    // ---- engine / rotor (legacy aggregate values; for the single-engine UH-1H these are engine 1)
    double n1, n2, nr, egt, torque, pDel, pReq, pCmd, thrustN, vi, tqEq;
    boolean lit, anyLit;
    boolean hotStart, engDamaged, xmsnDamaged;
    double overTorqueT;

    // ---- systems
    double fuelLb = 780, fuelFlow;
    double battCharge = 0.92, battV, busV, amps, hydP;
    double engOilT, engOilP, xmsnOilT, xmsnOilP, fuelP;
    boolean genOnline, starterActive;

    // ---- derived instrument values
    double vsiFpm, turnRate, ball, uf, ias, agl, radAltFt, contact;

    // ---- stats / events used by the mission and the score
    double time, flightTime, lowRpmTime, veryLowRpmTime, highRpmTime, overTorqueTime, vneTime, maxAgl;
    double touchVz, touchSpeed, touchPitch, thump;
    boolean hardLanding, tailStrike, everAirborne, touchWater;

    Sim(Aircraft ac) {
        this.ac = ac;
        this.discA = Math.PI * ac.rotorR * ac.rotorR;
        eng = new Eng[ac.engines];
        for (int i = 0; i < eng.length; i++) eng[i] = new Eng();
        reset();
    }

    void setup(double startX, double oat, double wind, double fuel, double payload) {
        this.startX = startX; this.fieldElev = Terrain.h(startX); this.oatField = oat; this.windBase = wind; this.fuelStartLb = fuel; this.payloadKg = payload;
        reset();
    }

    void reset() {
        collective = 0; cyclic = 0; pedal = 0; throttle = 0;
        batt = gen = fuelMain = fuelStart = inverter = hyd = acol = nav = landLt = starterBtn = false;
        gen2 = fuel2 = starter2 = false; gearCmd = true; hoistCmd = 0;
        forceTrim = true; govAuto = true;
        x = startX; alt = Terrain.h(x); vx = vz = 0; hdg = 90; pitch = pitchRate = disc = yawRate = 0;
        onGround = true; crashed = false; crashMsg = "";
        gearPos = 1; cableLen = 0; hookLoaded = false; contact = 0;
        for (Eng e : eng) {
            e.fuelOn = e.starterBtn = e.genSw = e.lit = e.failed = e.damaged = e.hot = e.starterActive = e.genOnline = e.wasLit = false;
            e.n1 = 0; e.egt = oatField; e.torque = e.pDel = e.pCmd = e.lightTimer = e.overTempT = 0; e.health = 1; e.oilP = 0; e.oilT = oatField;
        }
        n1 = n2 = nr = 0; egt = oatField; torque = pDel = pReq = pCmd = thrustN = vi = tqEq = 0;
        lit = anyLit = false; hotStart = engDamaged = xmsnDamaged = false; overTorqueT = 0;
        fuelLb = fuelStartLb; fuelFlow = 0; battCharge = 0.92; busV = battV = 0; amps = 0; hydP = 0;
        engOilT = xmsnOilT = oatField; engOilP = xmsnOilP = fuelP = 0; genOnline = starterActive = false;
        vsiFpm = turnRate = ball = uf = ias = agl = radAltFt = 0;
        time = flightTime = lowRpmTime = veryLowRpmTime = highRpmTime = overTorqueTime = vneTime = maxAgl = 0;
        touchVz = touchSpeed = touchPitch = thump = 0; hardLanding = tailStrike = everAirborne = touchWater = false;
        for (int i = 0; i < NL; i++) light[i] = false;
        atmosphere();
    }

    double massKg() { return ac.emptyKg + payloadKg + (hookLoaded ? 90 : 0) + fuelLb * 0.45359; }

    private static double clamp(double v, double a, double b) { return v < a ? a : (v > b ? b : v); }
    private static double sq(double v) { return v * v; }

    // ------------------------------------------------------------------ presets
    /** Engines running, generators on, rotor at 100 % (skips the start-up). */
    void presetRunning() {
        batt = true; inverter = true; hyd = true; gen = true; fuelMain = true; gen2 = true; fuel2 = true; fuelStart = false;
        throttle = 1.0; govAuto = true; battCharge = 0.95; nr = 100; n2 = 100;
        for (Eng e : eng) { e.fuelOn = true; e.genSw = true; e.lit = true; e.wasLit = true; e.n1 = 76; e.egt = 430; e.oilP = 60; e.oilT = oatField + 55; }
        xmsnOilP = 50; xmsnOilT = oatField + 40; engOilP = 60; engOilT = oatField + 55; busV = 28.4; battV = 24.8; hydP = 1000; fuelP = 9.5;
        syncLegacy();
    }

    /** Airborne preset (cruise): agl metres above the ground, speed in m/s heading east. */
    void presetAirborne(double aglM, double speed) {
        presetRunning();
        onGround = false; everAirborne = true;
        alt = Terrain.h(x) + aglM; vx = speed; vz = 0; pitch = -0.10 * speed / 45; disc = 0.11 * speed / 45; collective = 0.52; cyclic = 0.42 * speed / 45;
        if (ac.hasGear) { gearCmd = false; gearPos = 0; }
        for (int i = 0; i < 120; i++) step(1.0 / 60);
    }

    // ------------------------------------------------------------------ switches
    boolean swGet(int id) {
        switch (id) {
            case 0: return batt;
            case 1: return gen;
            case 2: return inverter;
            case 3: return fuelMain;
            case 4: return fuelStart;
            case 5: return !govAuto;
            case 6: return hyd;
            case 7: return forceTrim;
            case 8: return acol;
            case 9: return nav;
            case 10: return landLt;
            case 11: return assist;
            case 12: return gen2;
            case 13: return fuel2;
            default: return gearCmd;                   // lit = gear DOWN selected
        }
    }

    void swToggle(int id) {
        switch (id) {
            case 0: batt = !batt; break;
            case 1: gen = !gen; break;
            case 2: inverter = !inverter; break;
            case 3: fuelMain = !fuelMain; break;
            case 4: fuelStart = !fuelStart; break;
            case 5: govAuto = !govAuto; break;
            case 6: hyd = !hyd; break;
            case 7: forceTrim = !forceTrim; break;
            case 8: acol = !acol; break;
            case 9: nav = !nav; break;
            case 10: landLt = !landLt; break;
            case 11: assist = !assist; break;
            case 12: gen2 = !gen2; break;
            case 13: fuel2 = !fuel2; break;
            default: gearCmd = !gearCmd; break;
        }
    }

    // ------------------------------------------------------------------ stepping
    /** Advances the simulation by dt seconds (sub-stepped for stability). */
    void step(double dt) {
        while (dt > 1e-9) {
            double h = Math.min(dt, 1.0 / 120.0);
            sub(h);
            dt -= h;
        }
    }

    private void atmosphere() {
        double hm = Math.max(0, alt);
        double p = 101325 * Math.pow(1 - 2.25577e-5 * hm, 5.25588);
        double tK = 273.15 + oatField - 0.0065 * (hm - fieldElev);
        oatNow = tK - 273.15;
        rho = p / (287.05 * tK);
        sigma = rho / 1.225;
        double gust = 0.9 * Math.sin(time * 0.61) + 0.6 * Math.sin(time * 1.73 + 1.0) + 0.4 * Math.sin(time * 3.1 + 2.0);
        windX = windBase + gust * (assist ? 0.5 : 1.0) * (onGround ? 0.4 : 1.0);
    }

    private double n2Target() {
        if (!anyLit) return 0;
        if (throttle < 0.25) return 46 + clamp((throttle - 0.06) / 0.19, 0, 1) * 4;
        return 50 + (throttle - 0.25) / 0.75 * 50;
    }

    private double n1IdleTarget() { return 63 + clamp((throttle - 0.06) / 0.19, 0, 1) * 3; }

    void failEngine(int i) {
        if (i < 0 || i >= eng.length) return;
        eng[i].failed = true;
        eng[i].lit = false;
    }

    private void sub(double dt) {
        time += dt;
        atmosphere();
        double mass = massKg();
        double nrN = nr / 100.0;
        contact = ac.hasGear ? ac.hullClear * (1 - gearPos) : 0;
        double g = Terrain.h(x);
        agl = alt - contact - g;
        double face = Math.sin(Math.toRadians(hdg));
        double vrelx = vx - windX;
        uf = vrelx * face;
        ias = Math.max(0, uf) * Math.sqrt(sigma) * 1.94384;

        // map the cockpit switches to the engines
        eng[0].fuelOn = fuelMain; eng[0].starterBtn = starterBtn; eng[0].genSw = gen;
        if (eng.length > 1) { eng[1].fuelOn = fuel2; eng[1].starterBtn = starter2; eng[1].genSw = gen2; }

        // ================= electrical =================
        boolean anyGen = false, anyStarter = false;
        for (Eng e : eng) {
            e.genOnline = e.genSw && e.lit && e.n1 >= 50;
            e.starterActive = e.starterBtn && batt && battCharge > 0.08 && e.n1 < 40 && fuelLb > 0 && !e.failed;
            anyGen |= e.genOnline;
            anyStarter |= e.starterActive;
        }
        if (anyStarter) battCharge = Math.max(0, battCharge - 0.011 * dt);
        else if (anyGen) battCharge = Math.min(1, battCharge + 0.0015 * dt);
        else if (batt) battCharge = Math.max(0, battCharge - 0.00005 * dt);
        battV = batt ? 20.6 + 4.2 * battCharge - (anyStarter ? 3.2 : 0) : 0;
        busV = anyGen ? 28.4 : battV;
        double loads = (batt ? 9 : 0) + (inverter && busV > 18 ? 14 : 0) + (acol && busV > 18 ? 4 : 0) + (nav && busV > 18 ? 3 : 0)
                + (landLt && busV > 18 ? 14 : 0) + (hyd && busV > 18 ? 6 : 0);
        if (anyStarter) amps = -(380 + 90 * Math.sin(time * 9));
        else if (anyGen) amps = loads + 18 * (1 - battCharge);
        else amps = batt ? -loads : 0;

        // ================= engines: start, N1, EGT =================
        double pAvailTot = 0;
        int nRun = 0;
        double[] avail = new double[eng.length];
        for (int i = 0; i < eng.length; i++) {
            Eng e = eng[i];
            boolean fuelOk = e.fuelOn && fuelLb > 0.5 && !e.failed;
            if (!e.lit) {
                boolean cond = e.starterActive && fuelOk && throttle >= 0.06 && e.n1 >= 3 && (ac.fuelCockStart || fuelStart);
                if (cond) { e.lightTimer += dt; if (e.lightTimer > 0.6) { e.lit = true; e.lightTimer = 0; e.wasLit = true; } }
                else e.lightTimer = 0;
            } else {
                if (!fuelOk || throttle < 0.05) e.lit = false;
                else if (!ac.fuelCockStart && e.n1 < 45 && !fuelStart) e.lit = false;
                else if (e.n1 < 28 && !e.starterActive) e.lit = false;
            }
            double bf = clamp((battV - 16) / 8.0, 0.25, 1.0);
            if (!e.lit) {
                if (e.starterActive) e.n1 += clamp(25 - e.n1, 0, 3.4 * bf * dt);
                else e.n1 = Math.max(0, e.n1 - (0.9 + 0.035 * e.n1) * dt);
            } else {
                double tgt, tau;
                if (e.n1 < 40) { tgt = e.starterActive ? 48 : 0; tau = 99; }
                else {
                    tgt = throttle < 0.25 ? n1IdleTarget() : 64 + 34 * Math.pow(clamp(e.pCmd / ac.ratedKwEach, 0, 1.15), 0.7);
                    tau = (e.n1 < 62) ? 2.5 : (tgt > e.n1 ? 2.0 : 3.5);
                }
                if (e.n1 < 40) { if (tgt > e.n1) e.n1 += 2.9 * bf * dt; else e.n1 -= 2.5 * dt; }
                else e.n1 += (tgt - e.n1) * Math.min(1, dt / tau);
                e.n1 = clamp(e.n1, 0, 101.5);
            }
            double pf = clamp(e.pDel / ac.ratedKwEach, 0, 1.3);
            double egtT;
            if (e.lit) {
                egtT = 355 + 260 * pf;
                if (e.n1 < 45) egtT += (45 - e.n1) * 9 + (e.n1 < 12 ? (12 - e.n1) * 40 : 0);
            } else egtT = oatNow + 4;
            double egtTau = egtT > e.egt ? (e.lit && e.n1 < 45 ? 0.9 : 1.6) : 4.0;
            e.egt += (egtT - e.egt) * Math.min(1, dt / egtTau);
            if (e.egt > 780) e.overTempT += dt; else e.overTempT = Math.max(0, e.overTempT - dt * 0.5);
            if (e.overTempT > 0.6 && !e.damaged) { e.damaged = true; e.hot = true; e.health = 0.55; }
            double ratedNow = ac.ratedKwEach * e.health * Math.pow(sigma, 0.8);
            double s1 = clamp((e.n1 - 40) / 24.0, 0, 1), s2 = clamp((e.n1 - 62) / 35.0, 0, 1);
            avail[i] = e.lit ? ratedNow * (0.05 * s1 + 0.95 * s2) : 0;
            pAvailTot += avail[i];
            if (e.lit) nRun++;
        }
        anyLit = nRun > 0;

        // ================= rotor thrust / power =================
        double hr = Math.max(0.2, agl + ac.rotorR * 0.52);
        double ge = 1 + 0.10 * Math.exp(-hr / (ac.rotorR * 1.1));
        double cl = 0.10 + 1.70 * Math.pow(clamp(collective, 0, 1), 1.15);
        cl = clamp(cl - vz * 0.11 * (248.0 / (ac.omega100 * ac.rotorR)) / Math.max(0.3, nrN), 0, 2.4);
        thrustN = ac.tref * G * cl * nrN * nrN * sigma * ge;
        double hSpeed = Math.abs(vrelx);
        double vh = Math.sqrt(Math.max(1, thrustN) / (2 * rho * discA));
        vi = vh;
        for (int k = 0; k < 6; k++) {
            double den = Math.sqrt(sq(hSpeed) + sq(vz + vi));
            vi = vh * vh / Math.max(den, 0.5 * vh);
        }
        vi /= (1 + 0.28 * Math.exp(-hr / (ac.rotorR * 0.9)) * (1 - clamp(hSpeed / 15, 0, 1)));
        double pIndW = thrustN * (vi + vz);
        pIndW *= pIndW >= 0 ? 1.15 : 0.95;
        double mu = hSpeed / (ac.omega100 * ac.rotorR * Math.max(0.3, nrN));
        double pProf = ac.p0kw * 1000 * nrN * nrN * nrN * (1 + 4.6 * mu * mu) * sigma;
        double vneK = ias > ac.vneStart ? 1 + sq((ias - ac.vneStart) / 14.0) : 1;
        double fPar = (ac.fParBase + 3.0 * (1 - Math.abs(face))) * vneK * (1 - 0.14 * (1 - gearPos));
        double pPar = 0.5 * rho * fPar * hSpeed * hSpeed * hSpeed;
        pReq = (1.08 * (pIndW + pProf) + pPar) / 1000.0 + 6;
        if (nr < 1) pReq = 0;

        double ratedTot = ac.ratedKwEach * ac.engines;
        double nTgt = n2Target();
        if (!anyLit) pCmd = 0;
        else if (govAuto) {
            pCmd = pReq + 28 * (ratedTot / 850.0) * (nTgt - nr);
            if (nr > nTgt + 0.5) pCmd = Math.min(pCmd, pReq * 0.4);
            pCmd = clamp(pCmd, 0, ratedTot * 1.1);
        } else {
            double pFrac = throttle < 0.25 ? 0.04 : clamp((throttle - 0.25) / 0.75, 0, 1);
            pCmd = pFrac * ratedTot;
        }
        double pDelTot = anyLit ? Math.min(pCmd, pAvailTot) : 0;
        for (int i = 0; i < eng.length; i++) {
            Eng e = eng[i];
            e.pDel = (anyLit && pAvailTot > 0) ? pDelTot * avail[i] / pAvailTot : 0;
            e.pCmd = e.lit && nRun > 0 ? pCmd / nRun : 0;
        }
        pDel = pDelTot;
        double omega = Math.max(2.0, nrN * ac.omega100);
        double dOm = (pDelTot - pReq) * 1000.0 / (ac.inertia * omega);
        if (nr < 0.5 && dOm < 0) dOm = 0;
        nr = clamp(nr + dOm / ac.omega100 * 100.0 * dt, 0, 135);
        if (!anyLit && nr > 0 && pReq < 5) nr = Math.max(0, nr - 0.4 * dt);
        nrN = nr / 100.0;
        n2 = anyLit ? (nr <= nTgt + 0.3 ? nr : nTgt) : 0;
        double maxTq = 0;
        for (Eng e : eng) { e.torque = e.pDel / ac.torqueDiv / Math.max(0.4, nrN); maxTq = Math.max(maxTq, e.torque); }
        tqEq = pDelTot / ratedTot * 50 / Math.max(0.4, nrN);
        if (maxTq > ac.torqueLimit) overTorqueT += dt; else overTorqueT = Math.max(0, overTorqueT - dt * 0.3);
        if (maxTq > ac.torqueLimit * 1.04 && overTorqueT > 4 && !xmsnDamaged) xmsnDamaged = true;

        // ================= flight dynamics =================
        double hydG = (hyd && nr > 40 && busV > 18) ? 1.0 : 0.55;
        double inst = assist ? 0.30 : 1.0;
        double aCmd = clamp(cyclic, -1, 1) * hydG * (cyclic < 0 ? 0.40 : 0.28)
                + inst * 0.0045 * uf * Math.max(0, 1 - Math.abs(uf) / 15.0)
                - 0.0010 * Math.max(0, Math.abs(uf) - 10) * Math.signum(uf);
        if (!assist && !onGround) aCmd += 0.004 * Math.sin(time * 2.3) * (1 - Math.abs(face));
        disc += (aCmd - disc) * (1 - Math.exp(-dt / 0.45));
        boolean water = Terrain.water(x);
        double pitchGround = 0;
        double sgn = Math.abs(face) > 0.2 ? Math.signum(face) : 0;
        if (onGround && !water) pitchGround = Math.atan(Terrain.slope(x) * sgn);
        if (onGround && thrustN < mass * G * 0.97) {
            pitch += (pitchGround - pitch) * (1 - Math.exp(-dt / 0.15));
            pitchRate = 0;
            disc *= Math.exp(-dt / 0.6);
        } else {
            double w0 = ac.pitchOmega;
            double thetaT = -0.95 * disc + 0.03;
            double acc = w0 * w0 * (thetaT - pitch) - 2 * 0.55 * w0 * pitchRate;
            pitchRate += acc * dt;
            pitch += pitchRate * dt;
            pitch = clamp(pitch, -0.7, 0.7);
        }

        double dragX = -0.5 * rho * fPar * vrelx * Math.abs(vrelx);
        double dragZ = -0.5 * rho * 1.8 * vz * Math.abs(vz);
        double ax = (thrustN * Math.sin(disc) * face + dragX) / mass;
        double az = (thrustN * Math.cos(disc) + dragZ) / mass - G;

        boolean heavyOnSkids = onGround && thrustN < mass * G * 0.97;
        double yawT = pedal * hydG * ac.yawRate * (0.35 + 0.65 * clamp(nrN, 0, 1.1))
                + (heavyOnSkids ? 0 : (tqEq - 25) * 0.22 * (assist ? 0.15 : 1.0) * (nr > 30 ? 1 : 0));
        if (heavyOnSkids) yawT *= 0.5;
        if (nr < 30) yawT = pedal * 4;
        yawRate += (yawT - yawRate) * (1 - Math.exp(-dt / 0.35));
        hdg = (hdg + yawRate * dt + 360) % 360;

        // ================= landing gear and winch =================
        if (ac.hasGear) gearPos = clamp(gearPos + (gearCmd ? 1 : -1) * dt / 8.0, 0, 1);
        if (ac.hasHoist) cableLen = clamp(cableLen + (hoistCmd > 0 ? 1.5 : hoistCmd < 0 ? -1.1 : 0) * dt, 0, 70);

        // ================= ground / integration =================
        if (crashed) {
            vx = 0; vz = 0; ax = 0; az = 0;
        } else {
            if (onGround && az <= 0) {                           // supported by the ground (or floating)
                double normal = Math.max(0, mass * G - thrustN * Math.cos(disc)) / mass;
                double mu0 = water ? 0.03 : ac.frictionMu + (ac.hasGear && collective < 0.15 ? 0.5 : 0);
                double fric = mu0 * normal;
                if (Math.abs(vx) < 0.06 && Math.abs(ax) <= fric) { vx = 0; ax = 0; }
                else {
                    double dir = Math.abs(vx) > 0.06 ? Math.signum(vx) : Math.signum(ax);
                    ax -= dir * fric;
                    if (Math.abs(vx) < fric * dt && Math.abs(ax) < fric * 1.2) { vx = 0; ax = 0; }
                }
                vz = 0; az = 0;
            }
            vx += ax * dt;
            vz += az * dt;
            x += vx * dt;
            alt += vz * dt;
            double gNew = Terrain.h(x) + contact;
            if (alt <= gNew) {
                if (!onGround && vz < -0.05) touchdown(vz, face, pitchGround);
                if (!crashed) { alt = gNew; if (vz < 0) vz = 0; onGround = true; }
            } else if (alt > gNew + 0.03 && az > 0.05 && onGround) {
                onGround = false; everAirborne = true;
            } else if (alt > gNew + 0.25) onGround = false;
            if (!onGround) everAirborne = everAirborne || alt - gNew > 1.0;
            double ahead = x + sgn * 9;
            if (!onGround && sgn != 0 && Terrain.h(ahead) + contact > alt + 2.6 && Math.abs(uf) > 3) crash("Terrain collision / Impact with terrain");
        }
        agl = alt - contact - Terrain.h(x);
        if (!onGround) { flightTime += dt; maxAgl = Math.max(maxAgl, agl); }
        thump = Math.max(0, thump - dt * 2);

        // ================= instruments & systems =================
        vsiFpm += (vz * 196.85 - vsiFpm) * (1 - Math.exp(-dt / 1.4));
        turnRate = yawRate;
        ball += (clamp((tqEq - 25) * 0.03 - pedal * 0.5 - (yawRate - yawT) * 0.02, -1, 1) - ball) * (1 - Math.exp(-dt / 0.5));
        radAltFt = Math.max(0, agl) * 3.2808;
        rotorAz += nrN * 5.4 * 2 * Math.PI * dt * 0.33;

        fuelFlow = 0;
        for (Eng e : eng) if (e.lit) fuelFlow += ac.fuelBaseLbh + ac.fuelSfc * e.pDel * 1.341;
        fuelLb = Math.max(0, fuelLb - fuelFlow / 3600.0 * dt);
        if (fuelLb <= 0) for (Eng e : eng) e.lit = false;
        boolean anyFuelOn = false;
        for (Eng e : eng) anyFuelOn |= e.fuelOn;
        fuelP += (((anyFuelOn && fuelLb > 0 && (batt || anyGen)) ? 9.5 : 0) - fuelP) * Math.min(1, dt / 1.0);

        for (Eng e : eng) {
            double pf = clamp(e.pDel / ac.ratedKwEach, 0, 1.3);
            double oTt = e.lit ? oatNow + 38 + 50 * pf + 18 * (e.n1 / 100) : oatNow;
            e.oilT += (oTt - e.oilT) * Math.min(1, dt / (e.lit ? 70.0 : 240.0));
            double oPt = e.n1 > 3 ? clamp(8 + 0.62 * e.n1, 0, 75) * (1.12 - 0.003 * (e.oilT - 20)) : 0;
            e.oilP += (oPt - e.oilP) * Math.min(1, dt / 1.2);
        }
        double pfTot = clamp(pDelTot / ratedTot, 0, 1.3);
        double xOilTt = oatNow + (nr / 100) * (28 + 42 * pfTot);
        xmsnOilT += (xOilTt - xmsnOilT) * Math.min(1, dt / (nr > 20 ? 80.0 : 260.0));
        double xOilPt = nr > 5 ? clamp(8 + 0.42 * nr, 0, 62) : 0;
        xmsnOilP += (xOilPt - xmsnOilP) * Math.min(1, dt / 1.2);
        hydP += (((hyd && nr > 40 && busV > 18) ? 1000 : 0) - hydP) * Math.min(1, dt / 1.5);

        if (!onGround) {
            if (nr < 95) lowRpmTime += dt;
            if (nr < 88) veryLowRpmTime += dt;
            if (ias > ac.vne) vneTime += dt;
        }
        if (nr > 104.5) highRpmTime += dt;
        if (maxTq > ac.torqueLimit) overTorqueTime += dt;

        syncLegacy();
        computeLights();
    }

    private void syncLegacy() {
        Eng e0 = eng[0];
        n1 = e0.n1; egt = e0.egt; torque = e0.torque; lit = e0.lit; anyLit = false;
        for (Eng e : eng) anyLit |= e.lit;
        if (eng.length > 1) { torque = (eng[0].torque + eng[1].torque) / 2; n1 = (eng[0].n1 + eng[1].n1) / 2; egt = Math.max(eng[0].egt, eng[1].egt); }
        engOilP = e0.oilP; engOilT = e0.oilT;
        hotStart = false; engDamaged = false; genOnline = false; starterActive = false;
        for (Eng e : eng) { hotStart |= e.hot; engDamaged |= e.damaged; genOnline |= e.genOnline; starterActive |= e.starterActive; }
    }

    private void computeLights() {
        boolean powered = busV > 18;
        Eng e0 = eng[0];
        if (ac.id == Aircraft.HUEY) {
            light[0] = powered && e0.n1 > 30 && e0.oilP < 25;
            light[1] = powered && nr > 30 && xmsnOilP < 20;
            light[2] = powered && xmsnOilT > 110;
            light[3] = powered && e0.damaged;
            light[4] = powered && xmsnDamaged;
            light[5] = powered && fuelLb < 150;
            light[6] = powered && e0.n1 > 50 && !e0.genOnline;
            light[7] = batt && powered && !inverter;
            light[8] = powered && (!hyd || (hydP < 500 && nr > 40));
            light[9] = powered && !govAuto;
            light[10] = powered && nr > 20 && nr < 97 && (anyLit || !onGround);
            light[11] = powered && everAirborne && !anyLit && nr > 20 && !onGround;
            light[12] = powered && e0.egt > 640;
            light[13] = powered && nr > 104;
        } else {
            Eng e1 = eng[1];
            light[0] = powered && e0.n1 > 30 && e0.oilP < 25;
            light[1] = powered && e1.n1 > 30 && e1.oilP < 25;
            light[2] = powered && nr > 30 && xmsnOilP < 20;
            light[3] = powered && xmsnOilT > 110;
            light[4] = powered && e0.wasLit && !e0.lit;
            light[5] = powered && e1.wasLit && !e1.lit;
            light[6] = powered && fuelLb < 400;
            light[7] = powered && e0.n1 > 50 && !e0.genOnline;
            light[8] = powered && e1.n1 > 50 && !e1.genOnline;
            light[9] = batt && powered && !inverter;
            light[10] = powered && (!hyd || (hydP < 500 && nr > 40));
            light[11] = powered && nr > 20 && nr < 97 && (anyLit || !onGround);
            light[12] = powered && Math.max(e0.egt, e1.egt) > 640;
            light[13] = powered && nr > 104;
        }
    }

    private void touchdown(double impactVz, double face, double pitchGround) {
        touchVz = -impactVz;
        touchSpeed = Math.abs(vx);
        touchPitch = Math.toDegrees(pitch - pitchGround);
        thump = Math.min(1, touchVz / 3.0);
        boolean water = Terrain.water(x);
        touchWater = water;
        if (water) {
            if (!ac.amphibious) { crash("Ditched in the water - the aircraft sank"); return; }
            if (gearPos > 0.3) { crash("Water landing with the wheels down - aircraft capsized"); return; }
        } else if (ac.hasGear && gearPos < 0.9) { crash("Gear-up landing on land"); return; }
        double crashVz = ac.hasGear ? 5.6 : 4.8;
        if (touchVz > crashVz || Math.abs(vx) > 22) { crash("Hard impact: sink rate " + (int) (touchVz * 196.85) + " fpm"); return; }
        if (touchPitch > 18) { crash("Tail strike on landing"); return; }
        if (touchPitch < -20) { crash("Nose dug in on landing"); return; }
        if (touchVz > crashVz - 2.2 || Math.abs(vx) > 12) hardLanding = true;
        if (touchPitch > 11) tailStrike = true;
    }

    void crash(String why) {
        if (crashed) return;
        crashed = true; crashMsg = why;
        vx = 0; vz = 0;
    }

    // ---- helpers for the UI ----
    double altFt() { return alt * 3.2808; }
    double fuelMinutes() { return fuelFlow > 1 ? fuelLb / fuelFlow * 60 : 999; }
    double groundSpeedKt() { return Math.abs(vx) * 1.94384; }
}
