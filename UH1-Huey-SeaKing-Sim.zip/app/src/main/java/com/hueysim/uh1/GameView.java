package com.hueysim.uh1;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.Locale;

/** The whole game: loop, layout, touch controls, panels and every screen. */
final class GameView extends View {
    static final int ST_MENU = 0, ST_BRIEF = 1, ST_FLIGHT = 2, ST_PAUSE = 3, ST_MANUAL = 4, ST_DEBRIEF = 5, ST_SETTINGS = 6, ST_SELECT = 7;
    private static final int C_NONE = 0, C_COLL = 1, C_THR = 2, C_CYC = 3, C_PL = 4, C_PR = 5, C_START1 = 6, C_START2 = 7, C_WDN = 8, C_WUP = 9;

    interface Host { void exitApp(); }

    Sim sim;
    Mission mis;
    Panel panel;
    Aircraft ac;
    Mission.Def def;
    int selIdx;
    final Scene scene = new Scene();
    final SoundEngine snd = new SoundEngine();
    final GaugeEnv env = new GaugeEnv();
    private final SharedPreferences prefs;
    private final Host host;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    int state = ST_MENU;
    boolean fa, coach, soundOn;
    final int[] best = new int[Mission.DEFS.length];
    private int manualPage, manualFrom = ST_MENU, settingsFrom = ST_MENU;
    private long lastNs;
    private double endTimer, missionClock;
    private float u = 1f;

    // layout
    private final RectF rScene = new RectF(), rSw = new RectF(), rCaut = new RectF(), rGauge = new RectF();
    private final RectF rColl = new RectF(), rThr = new RectF(), rCyc = new RectF(), rPedL = new RectF(), rPedR = new RectF();
    private final RectF rTmp = new RectF(), rTmp2 = new RectF();
    private final RectF rBtnMenu = new RectF(), rBtnMan = new RectF(), rBtnCoach = new RectF();
    private final RectF rStart1 = new RectF(), rStart2 = new RectF(), rWdn = new RectF(), rWup = new RectF();

    // input
    private final int[] ctl = new int[32];
    private final float[] grab = new float[32];
    private float pedalTarget;
    private boolean start1Held, start2Held, wdnHeld, wupHeld;
    private long lastCycTap, lastTapMs;

    // buttons are rebuilt each frame
    private final ArrayList<RectF> btnR = new ArrayList<>();
    private final ArrayList<Integer> btnId = new ArrayList<>();
    private static final int B_START = 1, B_MANUAL = 2, B_SETTINGS = 3, B_EXIT = 4, B_FLY = 5, B_BACK = 6, B_RESUME = 7, B_RESTART = 8, B_MENU = 9,
            B_PREV = 10, B_NEXT = 11, B_LANG = 12, B_COACH = 13, B_SOUND = 14, B_ASSIST = 15, B_RETRY = 16, B_SELBACK = 17, B_SEL = 100;

    private final RectF[] swR = new RectF[12];

    // toast / events
    private String toast = "";
    private double toastT;
    private boolean prevHot, prevDamaged, prevHard, prevFail, prevHook;
    private double prevPayload;
    private float lastThump;

    GameView(Context ctx, SharedPreferences prefs, Host host) {
        super(ctx);
        this.prefs = prefs;
        this.host = host;
        for (int i = 0; i < swR.length; i++) swR[i] = new RectF();
        fa = prefs.getBoolean("fa", true);
        coach = prefs.getBoolean("coach", true);
        soundOn = prefs.getBoolean("sound", true);
        for (int i = 0; i < best.length; i++) best[i] = prefs.getInt("best" + i, 0);
        for (int i = 0; i < ctl.length; i++) ctl[i] = -1;
        backdropSim();
        setKeepScreenOn(true);
    }

    String T(String en, String fas) { return fa ? fas : en; }

    private void backdropSim() {
        Terrain.setMap(Terrain.VALLEY);
        ac = Aircraft.get(Aircraft.HUEY);
        sim = new Sim(ac);
        sim.setup(0, 22, 3.5, 780, 150);
        sim.assist = prefs.getBoolean("assist", true);
        panel = new Panel(ac);
        scene.ac = ac;
        scene.raftX = Double.NaN;
        scene.reset(sim);
    }

    // ------------------------------------------------------------------ lifecycle
    void onResumeGame() { lastNs = 0; snd.start(); invalidate(); }

    void onPauseGame() {
        if (state == ST_FLIGHT) state = ST_PAUSE;
        snd.stop();
        start1Held = start2Held = wdnHeld = wupHeld = false;
    }

    private void save() {
        SharedPreferences.Editor ed = prefs.edit().putBoolean("fa", fa).putBoolean("coach", coach).putBoolean("sound", soundOn).putBoolean("assist", sim.assist);
        for (int i = 0; i < best.length; i++) ed.putInt("best" + i, best[i]);
        ed.apply();
    }

    private void toMenu() {
        backdropSim();
        state = ST_MENU;
    }

    /** Android BACK: returns true when the game handled it. */
    boolean onBack() {
        switch (state) {
            case ST_FLIGHT: state = ST_PAUSE; return true;
            case ST_PAUSE: state = ST_FLIGHT; lastNs = 0; return true;
            case ST_MANUAL: state = manualFrom == ST_FLIGHT ? ST_PAUSE : manualFrom; return true;
            case ST_SETTINGS: save(); state = settingsFrom; return true;
            case ST_BRIEF: state = ST_SELECT; return true;
            case ST_SELECT: toMenu(); return true;
            case ST_DEBRIEF: state = ST_SELECT; backdropSim(); return true;
            default: return false;
        }
    }

    private void startMission(int idx) {
        def = Mission.DEFS[idx];
        selIdx = idx;
        Terrain.setMap(def.map);
        ac = Aircraft.get(def.aircraft);
        boolean assist = prefs.getBoolean("assist", true);
        sim = new Sim(ac);
        sim.setup(def.startX, def.oat, def.wind, def.fuel, def.payload);
        sim.assist = assist;
        if (def.airborne) sim.presetAirborne(def.airAgl, def.airSpeed);
        else if (!def.cold) sim.presetRunning();
        mis = new Mission(def);
        mis.startTime = sim.time;
        panel = new Panel(ac);
        scene.ac = ac;
        scene.raftX = def.raftX > 0 ? def.raftX : Double.NaN;
        scene.reset(sim);
        missionClock = 0; endTimer = 0; pedalTarget = 0;
        start1Held = start2Held = wdnHeld = wupHeld = false;
        prevHot = prevDamaged = prevHard = prevFail = prevHook = false; prevPayload = sim.payloadKg; lastThump = 0; toast = ""; toastT = 0;
        for (int i = 0; i < ctl.length; i++) ctl[i] = -1;
        state = ST_FLIGHT;
        lastNs = 0;
    }

    // ------------------------------------------------------------------ layout
    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        float W = w, H = h;
        u = H / 1080f;
        rColl.set(0.010f * W, 0.075f * H, 0.058f * W, 0.935f * H);
        rThr.set(0.067f * W, 0.075f * H, 0.108f * W, 0.935f * H);
        rCyc.set(0.940f * W, 0.075f * H, 0.988f * W, 0.935f * H);
        rScene.set(0.118f * W, 0.012f * H, 0.600f * W, 0.640f * H);
        rSw.set(0.118f * W, 0.652f * H, 0.600f * W, 0.835f * H);
        rCaut.set(0.118f * W, 0.845f * H, 0.600f * W, 0.988f * H);
        rGauge.set(0.608f * W, 0.012f * H, 0.935f * W, 0.988f * H);
        float pw = 190 * u, ph = 70 * u, pm = 10 * u;
        rPedL.set(rScene.left + pm, rScene.bottom - ph - pm, rScene.left + pm + pw, rScene.bottom - pm);
        rPedR.set(rScene.right - pm - pw, rScene.bottom - ph - pm, rScene.right - pm, rScene.bottom - pm);
        float hw = 150 * u;
        rWdn.set(rScene.centerX() - hw - 8 * u, rScene.bottom - ph - pm, rScene.centerX() - 8 * u, rScene.bottom - pm);
        rWup.set(rScene.centerX() + 8 * u, rScene.bottom - ph - pm, rScene.centerX() + hw + 8 * u, rScene.bottom - pm);
        float bw = 128 * u, bh = 44 * u;
        rBtnCoach.set(rScene.right - pm - bw, rScene.top + pm, rScene.right - pm, rScene.top + pm + bh);
        rBtnMan.set(rBtnCoach.left - 8 * u - bw, rScene.top + pm, rBtnCoach.left - 8 * u, rScene.top + pm + bh);
        rBtnMenu.set(rBtnMan.left - 8 * u - bw, rScene.top + pm, rBtnMan.left - 8 * u, rScene.top + pm + bh);
        float pad = 6 * u, cw = (rSw.width() - 2 * pad) / 7f, chh = (rSw.height() - 2 * pad) / 2f;
        for (int i = 0; i < swR.length; i++) {
            int col = i % 6, row = i / 6;
            swR[i].set(rSw.left + pad + col * cw + 2, rSw.top + pad + row * chh + 2, rSw.left + pad + (col + 1) * cw - 2, rSw.top + pad + (row + 1) * chh - 2);
        }
        float sl = rSw.left + pad + 6 * cw + 4, sr = rSw.right - pad - 2, st = rSw.top + pad + 2, sb = rSw.bottom - pad - 2;
        rStart1.set(sl, st, sr, sb);
        rStart2.set(0, 0, 0, 0);
    }

    private void layoutStarters() {
        float pad = 6 * u, cw = (rSw.width() - 2 * pad) / 7f;
        float sl = rSw.left + pad + 6 * cw + 4, sr = rSw.right - pad - 2, st = rSw.top + pad + 2, sb = rSw.bottom - pad - 2;
        if (ac.engines > 1) {
            float mid = (st + sb) / 2;
            rStart1.set(sl, st, sr, mid - 2);
            rStart2.set(sl, mid + 2, sr, sb);
        } else { rStart1.set(sl, st, sr, sb); rStart2.set(0, 0, 0, 0); }
    }

    // ------------------------------------------------------------------ main loop / draw
    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        double dt = lastNs == 0 ? 0.016 : (now - lastNs) / 1e9;
        lastNs = now;
        dt = Math.max(0.001, Math.min(0.05, dt));
        int w = getWidth(), h = getHeight();
        if (w <= 0) { postInvalidateOnAnimation(); return; }
        if (rScene.width() <= 0) onSizeChanged(w, h, 0, 0);
        layoutStarters();

        if (state == ST_FLIGHT) updateFlight(dt);
        env.clock = missionClock;
        if (mis != null && state != ST_MENU && state != ST_SELECT) {
            double dd = mis.distTarget(sim);
            env.distDest = dd;
            env.bearingDest = dd >= 0 ? 90 : 270;
        } else { env.distDest = Terrain.padX[Math.min(1, Terrain.padX.length - 1)] - sim.x; env.bearingDest = 90; }
        env.blink = ((int) (now / 600000000L)) % 2 == 0;

        c.drawColor(0xFF0B0C0E);
        btnR.clear();
        btnId.clear();
        switch (state) {
            case ST_FLIGHT: drawFlight(c); break;
            case ST_PAUSE: drawFlight(c); drawPause(c); break;
            case ST_MENU: drawMenu(c, dt); break;
            case ST_SELECT: drawSelect(c); break;
            case ST_SETTINGS: drawSettings(c, dt); break;
            case ST_BRIEF: drawBrief(c); break;
            case ST_MANUAL: drawManual(c); break;
            default: drawDebrief(c); break;
        }
        postInvalidateOnAnimation();
    }

    private void updateFlight(double dt) {
        sim.pedal += (pedalTarget - sim.pedal) * Math.min(1, dt * 4.0);
        if (!sim.forceTrim && !holding(C_CYC)) sim.cyclic *= Math.exp(-dt * 3.0);
        sim.starterBtn = start1Held;
        sim.starter2 = start2Held;
        sim.hoistCmd = wdnHeld ? 1 : (wupHeld ? -1 : 0);
        sim.step(dt);
        if (!mis.complete && !mis.failed) missionClock += dt; else endTimer += dt;
        mis.update(sim, dt);
        scene.windNow = sim.windX;
        scene.update(sim, dt);
        if (sim.hotStart && !prevHot) { prevHot = true; toast(T("HOT START - engine overtemp, power reduced", "استارت داغ - دمای بیش از حد، قدرت موتور کم شد")); }
        if (sim.hardLanding && !prevHard) { prevHard = true; toast(T("HARD LANDING", "فرود سخت")); }
        if (sim.xmsnDamaged && !prevDamaged) { prevDamaged = true; toast(T("TRANSMISSION OVER-TORQUE", "اورتورک گیربکس")); }
        if (mis.failTriggered && !prevFail) { prevFail = true; toast(T("ENGINE FAILURE!", "خرابی موتور!")); }
        if (sim.hookLoaded && !prevHook) { prevHook = true; toast(T("SURVIVOR HOOKED - raise the winch", "نجات‌یافته وصل شد - وینچ را بالا بکشید")); }
        if (sim.payloadKg > prevPayload + 1) { prevPayload = sim.payloadKg; toast(T("PATIENT LOADED", "مجروح سوار شد")); }
        if (toastT > 0) toastT -= dt;
        double mx1 = 0;
        for (Sim.Eng e : sim.eng) mx1 = Math.max(mx1, e.n1);
        snd.n1 = (float) mx1; snd.nr = (float) sim.nr; snd.load = (float) Math.min(1.2, sim.tqEq / 45.0); snd.speed = (float) sim.ias;
        snd.slapHz100 = ac.id == Aircraft.SEAKING ? 16.9f : 10.8f;
        snd.starter = sim.starterActive; snd.horn = sim.everAirborne && !sim.onGround && sim.nr < 95 && sim.nr > 20 && !sim.crashed;
        snd.muted = !soundOn;
        if (sim.thump > lastThump + 0.15f) snd.thumpReq = (float) sim.thump;
        lastThump = (float) sim.thump;
        if ((mis.complete && endTimer > 3.0) || (mis.failed && endTimer > 2.5)) {
            state = ST_DEBRIEF;
            if (mis.complete && mis.score > best[selIdx]) { best[selIdx] = (int) mis.score; save(); }
        }
    }

    private boolean holding(int c) {
        for (int i = 0; i < ctl.length; i++) if (ctl[i] == c) return true;
        return false;
    }

    private void toast(String s) { toast = s; toastT = 4.0; }

    // ------------------------------------------------------------------ drawing helpers
    private void tx(Canvas c, String s, float x, float y, float size, int color, Paint.Align al, boolean bold) {
        GU.text(c, p, s, x, y, size, color, al, bold);
    }

    private void fill(Canvas c, RectF r, int color, float rad) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.drawRoundRect(r, rad, rad, p);
    }

    private void stroke(Canvas c, RectF r, int color, float w, float rad) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(w);
        p.setColor(color);
        c.drawRoundRect(r, rad, rad, p);
    }

    private void button(Canvas c, RectF r, String label, int id, boolean on) {
        fill(c, r, on ? 0xFF2F6B3F : 0xFF24272B, 12 * u);
        stroke(c, r, on ? 0xFF58C77A : 0xFF5A5E66, 2 * u, 12 * u);
        tx(c, label, r.centerX(), r.centerY(), Math.min(r.height() * 0.42f, 34 * u), 0xFFF2F2F2, Paint.Align.CENTER, true);
        btnR.add(new RectF(r));
        btnId.add(id);
    }

    private ArrayList<String> wrap(String text, float maxW, float size, boolean bold) {
        ArrayList<String> out = new ArrayList<>();
        p.setTextSize(size);
        p.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        String[] words = text.split(" ");
        StringBuilder line = new StringBuilder();
        for (String wd : words) {
            String t = line.length() == 0 ? wd : line + " " + wd;
            if (p.measureText(t) > maxW && line.length() > 0) { out.add(line.toString()); line = new StringBuilder(wd); }
            else { line.setLength(0); line.append(t); }
        }
        if (line.length() > 0) out.add(line.toString());
        return out;
    }

    private float para(Canvas c, String text, float x, float y, float maxW, float size, int color, boolean bold, boolean rtl) {
        ArrayList<String> lines = wrap(text, maxW, size, bold);
        for (String l : lines) {
            tx(c, l, rtl ? x + maxW : x, y + size * 0.5f, size, color, rtl ? Paint.Align.RIGHT : Paint.Align.LEFT, bold);
            y += size * 1.32f;
        }
        return y;
    }

    // ------------------------------------------------------------------ flight screen
    private void drawFlight(Canvas c) {
        scene.draw(c, rScene, sim, env);
        scene.drawBearing(c, rScene, sim, sim.x + env.distDest, mis.targetName());
        drawSceneHud(c);
        panel.draw(c, rGauge, sim, env, p);
        drawSwitches(c);
        drawCautions(c);
        drawLevers(c);
        drawPedals(c);
        if (ac.hasHoist) drawWinch(c);
        if (toastT > 0) {
            rTmp.set(rScene.left + rScene.width() * 0.12f, rScene.top + rScene.height() * 0.42f, rScene.right - rScene.width() * 0.12f, rScene.top + rScene.height() * 0.42f + 64 * u);
            fill(c, rTmp, 0xDD7A1A12, 12 * u);
            tx(c, toast, rTmp.centerX(), rTmp.centerY(), 28 * u, 0xFFFFFFFF, Paint.Align.CENTER, true);
        }
        if (sim.crashed) {
            tx(c, T("CRASHED", "سقوط"), rScene.centerX(), rScene.top + rScene.height() * 0.30f, 70 * u, env.blink ? 0xFFFF4A3A : 0xFFAA2A20, Paint.Align.CENTER, true);
            tx(c, sim.crashMsg, rScene.centerX(), rScene.top + rScene.height() * 0.30f + 54 * u, 24 * u, 0xFFFFFFFF, Paint.Align.CENTER, false);
        }
    }

    private void drawWinch(Canvas c) {
        boolean dn = wdnHeld, up = wupHeld;
        fill(c, rWdn, dn ? 0xFF3B5A87 : 0xFF202327, 12 * u);
        stroke(c, rWdn, 0xFF6A6E75, 2 * u, 12 * u);
        tx(c, T("WINCH DOWN", "وینچ پایین"), rWdn.centerX(), rWdn.centerY(), 19 * u, 0xFFFFFFFF, Paint.Align.CENTER, true);
        fill(c, rWup, up ? 0xFF3B5A87 : 0xFF202327, 12 * u);
        stroke(c, rWup, 0xFF6A6E75, 2 * u, 12 * u);
        tx(c, T("WINCH UP", "وینچ بالا"), rWup.centerX(), rWup.centerY(), 19 * u, 0xFFFFFFFF, Paint.Align.CENTER, true);
        if (sim.cableLen > 0.2) tx(c, String.format(Locale.US, "CABLE %d m", Math.round(sim.cableLen)), rScene.centerX(), rWdn.top - 14 * u, 18 * u, 0xFFFFD21F, Paint.Align.CENTER, true);
    }

    private void drawSceneHud(Canvas c) {
        button(c, rBtnMenu, "MENU", B_MENU, false);
        button(c, rBtnMan, T("MANUAL", "راهنما"), B_MANUAL, false);
        button(c, rBtnCoach, "COACH", B_COACH, coach);
        double distKm = Math.abs(env.distDest) / 1000.0;
        String info = String.format(Locale.US, "GS %d kt   WIND 270/%d kt   %s %.2f km", Math.round(sim.groundSpeedKt()), Math.round(Math.abs(sim.windX) * 1.944), mis.targetName(), distKm);
        tx(c, info, rScene.left + 12 * u, rScene.bottom - 98 * u, 20 * u, 0xFFFFFFFF, Paint.Align.LEFT, true);
        if (!coach) return;
        float bw = rScene.width() * 0.60f, bx = rScene.left + 10 * u, by = rScene.top + 10 * u;
        Mission.Step st = mis.cur();
        int idx = Math.min(mis.step, mis.n() - 1);
        String head = String.format(Locale.US, T("STEP %d / %d", "قدم %d از %d"), idx + 1, mis.n());
        String txt = fa ? st.fa : st.en;
        String hint = fa ? st.hFa : st.hEn;
        float ts = 23 * u, hs = 19 * u;
        ArrayList<String> l1 = wrap(txt, bw - 24 * u, ts, true);
        ArrayList<String> l2 = wrap(hint, bw - 24 * u, hs, false);
        float bh = 14 * u + 26 * u + l1.size() * ts * 1.3f + 8 * u + l2.size() * hs * 1.3f + 8 * u;
        rTmp.set(bx, by, bx + bw, by + bh);
        fill(c, rTmp, 0xB0101418, 12 * u);
        stroke(c, rTmp, 0xFF58C77A, 2 * u, 12 * u);
        tx(c, head, bx + 12 * u, by + 20 * u, 18 * u, 0xFF58C77A, Paint.Align.LEFT, true);
        float y = by + 38 * u;
        for (String l : l1) { tx(c, l, fa ? bx + bw - 12 * u : bx + 12 * u, y + ts * 0.5f, ts, 0xFFFFFFFF, fa ? Paint.Align.RIGHT : Paint.Align.LEFT, true); y += ts * 1.3f; }
        y += 6 * u;
        for (String l : l2) { tx(c, l, fa ? bx + bw - 12 * u : bx + 12 * u, y + hs * 0.5f, hs, 0xFFB8C4CC, fa ? Paint.Align.RIGHT : Paint.Align.LEFT, false); y += hs * 1.3f; }
    }

    private void drawSwitches(Canvas c) {
        fill(c, rSw, 0xFF16181B, 14 * u);
        stroke(c, rSw, 0xFF2D3035, 2 * u, 14 * u);
        for (int i = 0; i < swR.length; i++) {
            int id = ac.switches[i];
            RectF r = swR[i];
            boolean on = sim.swGet(id);
            fill(c, r, 0xFF202327, 8 * u);
            stroke(c, r, 0xFF3A3E44, 1.5f * u, 8 * u);
            tx(c, ac.swLabel(id), r.centerX(), r.top + r.height() * 0.17f, Math.min(r.height() * 0.17f, r.width() * 0.14f), 0xFFDADDE0, Paint.Align.CENTER, true);
            float cx = r.centerX(), cy = r.top + r.height() * 0.66f, rr = r.height() * 0.17f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF0E0F11);
            c.drawCircle(cx, cy, rr, p);
            int lampColor = id == 5 ? 0xFFFFB000 : 0xFF38C25A;
            if (id == 14 && sim.gearPos > 0.05 && sim.gearPos < 0.95) lampColor = 0xFFFFB000;
            boolean lampOn = on && (id != 14 || sim.gearPos > 0.05);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(rr * 0.55f);
            p.setColor(on ? lampColor : 0xFF8A8D92);
            c.drawLine(cx, cy, cx, cy + (on ? -rr * 1.9f : rr * 1.9f), p);
            p.setStrokeCap(Paint.Cap.BUTT);
            p.setStyle(Paint.Style.FILL);
            p.setColor(lampOn ? lampColor : 0xFF3C3F44);
            c.drawCircle(r.right - r.width() * 0.14f, r.top + r.height() * 0.17f, r.height() * 0.045f, p);
        }
        drawStarter(c, rStart1, start1Held, ac.engines > 1 ? "START 1" : "STARTER");
        if (ac.engines > 1) drawStarter(c, rStart2, start2Held, "START 2");
    }

    private void drawStarter(Canvas c, RectF r, boolean act, String label) {
        fill(c, r, 0xFF202327, 10 * u);
        stroke(c, r, 0xFF3A3E44, 1.5f * u, 10 * u);
        float cx = r.centerX(), cy = r.centerY() + r.height() * 0.08f, rr = Math.min(r.width(), r.height()) * 0.30f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(act ? 0xFFFF7A2E : 0xFFC03A22);
        c.drawCircle(cx, cy, rr, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(rr * 0.12f);
        p.setColor(0xFF2A1410);
        c.drawCircle(cx, cy, rr, p);
        tx(c, label, cx, r.top + r.height() * 0.15f, Math.min(r.height() * 0.15f, r.width() * 0.15f), 0xFFDADDE0, Paint.Align.CENTER, true);
    }

    private boolean isRed(int i) {
        if (ac.id == Aircraft.SEAKING) return i == 0 || i == 1 || i == 2 || i == 4 || i == 5 || i == 12;
        return i == 0 || i == 1 || i == 3 || i == 4 || i == 11 || i == 12;
    }

    private boolean flashes(int i) {
        if (ac.id == Aircraft.SEAKING) return i == 4 || i == 5 || i == 11 || i == 13;
        return i == 10 || i == 11 || i == 13;
    }

    private void drawCautions(Canvas c) {
        fill(c, rCaut, 0xFF16181B, 14 * u);
        stroke(c, rCaut, 0xFF2D3035, 2 * u, 14 * u);
        float pad = 6 * u, cw = (rCaut.width() - 2 * pad) / 7f, chh = (rCaut.height() - 2 * pad) / 2f;
        for (int i = 0; i < Sim.NL; i++) {
            int col = i % 7, row = i / 7;
            rTmp.set(rCaut.left + pad + col * cw + 3, rCaut.top + pad + row * chh + 3, rCaut.left + pad + (col + 1) * cw - 3, rCaut.top + pad + (row + 1) * chh - 3);
            boolean lit = sim.light[i];
            boolean flash = flashes(i) && !env.blink;
            boolean show = lit && !flash;
            fill(c, rTmp, show ? (isRed(i) ? 0xFFD8352B : 0xFFFFB000) : 0xFF26282C, 6 * u);
            stroke(c, rTmp, 0xFF3C4046, 1.5f * u, 6 * u);
            String lab = ac.lightNames[i];
            float fs = Math.min(rTmp.height() * 0.22f, rTmp.width() * 0.13f);
            int tc = show ? 0xFF1A1000 : 0xFF6B7076;
            String[] parts = lab.split(" ", 2);
            if (parts.length == 2) {
                tx(c, parts[0], rTmp.centerX(), rTmp.centerY() - fs * 0.6f, fs, tc, Paint.Align.CENTER, true);
                tx(c, parts[1], rTmp.centerX(), rTmp.centerY() + fs * 0.8f, fs, tc, Paint.Align.CENTER, true);
            } else tx(c, lab, rTmp.centerX(), rTmp.centerY(), fs, tc, Paint.Align.CENTER, true);
        }
    }

    private void lever(Canvas c, RectF r, double v01, String top, String bottom, boolean centerMark, boolean detents) {
        fill(c, r, 0xFF16181B, 12 * u);
        stroke(c, r, 0xFF2D3035, 2 * u, 12 * u);
        float gx = r.centerX(), gt = r.top + 34 * u, gb = r.bottom - 34 * u;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(8 * u);
        p.setColor(0xFF050607);
        p.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(gx, gt, gx, gb, p);
        p.setStrokeCap(Paint.Cap.BUTT);
        p.setStrokeWidth(2 * u);
        p.setColor(0xFF6A6E75);
        for (int i = 0; i <= 10; i++) {
            float y = gb - (gb - gt) * i / 10f;
            float len = (i % 5 == 0) ? 14 * u : 8 * u;
            c.drawLine(r.left + 6 * u, y, r.left + 6 * u + len, y, p);
            c.drawLine(r.right - 6 * u, y, r.right - 6 * u - len, y, p);
        }
        if (centerMark) { p.setColor(GU.ORANGE); float y = (gt + gb) / 2; c.drawLine(r.left + 4 * u, y, r.right - 4 * u, y, p); }
        if (detents) {
            float yIdle = gb - (gb - gt) * 0.15f;
            p.setColor(GU.YELLOW);
            c.drawLine(r.left + 4 * u, yIdle, r.right - 4 * u, yIdle, p);
            tx(c, "IDLE", r.centerX(), yIdle - 12 * u, 12 * u, GU.YELLOW, Paint.Align.CENTER, true);
        }
        float ky = (float) (gb - (gb - gt) * v01);
        rTmp2.set(r.left + 4 * u, ky - 20 * u, r.right - 4 * u, ky + 20 * u);
        p.setShader(new LinearGradient(0, ky - 20 * u, 0, ky + 20 * u, 0xFF8A8E95, 0xFF35383D, Shader.TileMode.CLAMP));
        p.setStyle(Paint.Style.FILL);
        c.drawRoundRect(rTmp2, 9 * u, 9 * u, p);
        p.setShader(null);
        stroke(c, rTmp2, 0xFFD0D3D8, 1.5f * u, 9 * u);
        tx(c, top, r.centerX(), r.top + 16 * u, 13 * u, 0xFFDADDE0, Paint.Align.CENTER, true);
        tx(c, bottom, r.centerX(), r.bottom - 14 * u, 13 * u, 0xFFDADDE0, Paint.Align.CENTER, true);
    }

    private void drawLevers(Canvas c) {
        lever(c, rColl, sim.collective, "COLL", String.format(Locale.US, "%d%%", Math.round(sim.collective * 100)), false, false);
        lever(c, rThr, sim.throttle, ac.engines > 1 ? "ESL" : "THR", String.format(Locale.US, "%d%%", Math.round(sim.throttle * 100)), false, true);
        lever(c, rCyc, (sim.cyclic + 1) / 2, "FWD", "AFT", true, false);
    }

    private void drawPedals(Canvas c) {
        boolean l = sim.pedal < -0.2, r = sim.pedal > 0.2;
        fill(c, rPedL, l ? 0xFF3B5A87 : 0xFF202327, 12 * u);
        stroke(c, rPedL, 0xFF6A6E75, 2 * u, 12 * u);
        tx(c, "< " + T("LEFT PEDAL", "پدال چپ"), rPedL.centerX(), rPedL.centerY(), 22 * u, 0xFFFFFFFF, Paint.Align.CENTER, true);
        fill(c, rPedR, r ? 0xFF3B5A87 : 0xFF202327, 12 * u);
        stroke(c, rPedR, 0xFF6A6E75, 2 * u, 12 * u);
        tx(c, T("RIGHT PEDAL", "پدال راست") + " >", rPedR.centerX(), rPedR.centerY(), 22 * u, 0xFFFFFFFF, Paint.Align.CENTER, true);
    }

    private void drawPause(Canvas c) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xCC000000);
        c.drawRect(0, 0, getWidth(), getHeight(), p);
        float W = getWidth(), H = getHeight(), bw = 460 * u, bh = 84 * u, x = (W - bw) / 2, y = H * 0.24f;
        tx(c, T("PAUSED", "توقف"), W / 2, y - 50 * u, 56 * u, 0xFFFFFFFF, Paint.Align.CENTER, true);
        String[] lab = {T("RESUME", "ادامه"), T("RESTART MISSION", "شروع دوباره"), T("MANUAL", "دفترچه راهنما"), T("MAIN MENU", "منوی اصلی")};
        int[] id = {B_RESUME, B_RESTART, B_MANUAL, B_MENU};
        for (int i = 0; i < 4; i++) { rTmp.set(x, y + i * (bh + 18 * u), x + bw, y + i * (bh + 18 * u) + bh); button(c, rTmp, lab[i], id[i], false); }
    }

    // ------------------------------------------------------------------ menus
    private void backdrop(Canvas c, double dt) {
        rTmp.set(0, 0, getWidth(), getHeight());
        sim.agl = 0;
        scene.windNow = sim.windX;
        scene.update(sim, dt);
        scene.draw(c, rTmp, sim, env);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x88000000);
        c.drawRect(rTmp, p);
    }

    private void drawMenu(Canvas c, double dt) {
        backdrop(c, dt);
        float W = getWidth(), H = getHeight();
        tx(c, "UH-1H HUEY  +  SEA KING", W / 2, H * 0.14f, 84 * u, 0xFFFFFFFF, Paint.Align.CENTER, true);
        tx(c, T("2D HELICOPTER FLIGHT SIMULATOR  -  7 MISSIONS", "شبیه‌ساز پرواز دوبعدی هلیکوپتر - ۷ ماموریت"), W / 2, H * 0.14f + 66 * u, 30 * u, 0xFFD8E2EA, Paint.Align.CENTER, false);
        float bw = 560 * u, bh = 88 * u, x = (W - bw) / 2, y = H * 0.40f, gap = 20 * u;
        String[] lab = {T("MISSIONS", "ماموریت‌ها"), T("MANUAL", "دفترچه راهنما"), T("SETTINGS", "تنظیمات"), T("EXIT", "خروج")};
        int[] id = {B_START, B_MANUAL, B_SETTINGS, B_EXIT};
        for (int i = 0; i < 4; i++) { rTmp.set(x, y + i * (bh + gap), x + bw, y + i * (bh + gap) + bh); button(c, rTmp, lab[i], id[i], i == 0); }
        int total = 0;
        for (int b : best) total += b;
        if (total > 0) tx(c, T("Total score: ", "مجموع امتیاز: ") + total + " / " + (best.length * 100), W / 2, H * 0.94f, 28 * u, 0xFFFFD21F, Paint.Align.CENTER, true);
    }

    private void drawSelect(Canvas c) {
        float W = getWidth(), H = getHeight();
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, 0, H, 0xFF18222B, 0xFF0A0D10, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(null);
        tx(c, T("SELECT A MISSION", "یک ماموریت انتخاب کنید"), W / 2, H * 0.07f, 52 * u, 0xFFFFFFFF, Paint.Align.CENTER, true);
        float cw = W * 0.43f, ch = H * 0.17f, gx = W * 0.035f, gy = H * 0.02f, x0 = (W - 2 * cw - gx) / 2, y0 = H * 0.13f;
        for (int i = 0; i < Mission.DEFS.length; i++) {
            Mission.Def d = Mission.DEFS[i];
            int col = i % 2, row = i / 2;
            rTmp.set(x0 + col * (cw + gx), y0 + row * (ch + gy), x0 + col * (cw + gx) + cw, y0 + row * (ch + gy) + ch);
            boolean sea = d.aircraft == Aircraft.SEAKING;
            fill(c, rTmp, sea ? 0xFF1E3447 : 0xFF2A3322, 14 * u);
            stroke(c, rTmp, best[i] > 0 ? 0xFF58C77A : 0xFF5A5E66, 2.5f * u, 14 * u);
            tx(c, (i + 1) + ". " + (fa ? d.titleFa : d.titleEn), rTmp.left + 20 * u, rTmp.top + ch * 0.28f, 30 * u, 0xFFFFFFFF, Paint.Align.LEFT, true);
            String sub = Aircraft.get(d.aircraft).shortName + "  -  " + (d.map == Terrain.VALLEY ? T("Valley", "دره") : d.map == Terrain.COAST ? T("Coast", "ساحل") : T("Mountains", "کوهستان"))
                    + "  -  " + (d.cold ? T("cold start", "استارت سرد") : d.airborne ? T("airborne", "در هوا") : T("engine running", "موتور روشن"));
            tx(c, sub, rTmp.left + 20 * u, rTmp.top + ch * 0.56f, 21 * u, 0xFFB8C4CC, Paint.Align.LEFT, false);
            tx(c, best[i] > 0 ? T("Best: ", "بهترین: ") + best[i] + " / 100" : T("not flown yet", "هنوز پرواز نشده"), rTmp.left + 20 * u, rTmp.top + ch * 0.82f, 22 * u, best[i] > 0 ? 0xFFFFD21F : 0xFF7E8A93, Paint.Align.LEFT, true);
            btnR.add(new RectF(rTmp));
            btnId.add(B_SEL + i);
        }
        rTmp.set(W * 0.5f - 200 * u, H * 0.92f - 30 * u, W * 0.5f + 200 * u, H * 0.92f + 40 * u);
        button(c, rTmp, T("BACK", "بازگشت"), B_SELBACK, false);
    }

    private void drawSettings(Canvas c, double dt) {
        backdrop(c, dt);
        float W = getWidth(), H = getHeight();
        tx(c, T("SETTINGS", "تنظیمات"), W / 2, H * 0.12f, 60 * u, 0xFFFFFFFF, Paint.Align.CENTER, true);
        float bw = 700 * u, bh = 84 * u, x = (W - bw) / 2, y = H * 0.24f, gap = 18 * u;
        String[] lab = {
                T("Language: English", "زبان: فارسی"),
                T("Coach hints: ", "راهنمای مرحله‌ای: ") + (coach ? "ON" : "OFF"),
                T("Sound: ", "صدا: ") + (soundOn ? "ON" : "OFF"),
                T("Flight assist (stability): ", "کمک پروازی (پایداری): ") + (prefs.getBoolean("assist", true) ? "ON" : "OFF"),
                T("BACK", "بازگشت")};
        int[] id = {B_LANG, B_COACH, B_SOUND, B_ASSIST, B_BACK};
        boolean[] on = {false, coach, soundOn, prefs.getBoolean("assist", true), false};
        for (int i = 0; i < 5; i++) { rTmp.set(x, y + i * (bh + gap), x + bw, y + i * (bh + gap) + bh); button(c, rTmp, lab[i], id[i], on[i]); }
    }

    private void drawBrief(Canvas c) {
        float W = getWidth(), H = getHeight();
        Mission.Def d = Mission.DEFS[selIdx];
        Terrain.setMap(d.map);
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, 0, H, 0xFF18222B, 0xFF0A0D10, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(null);
        tx(c, (selIdx + 1) + ".  " + (fa ? d.titleFa : d.titleEn).toUpperCase(Locale.US), W / 2, H * 0.075f, 44 * u, 0xFFFFFFFF, Paint.Align.CENTER, true);
        tx(c, Aircraft.get(d.aircraft).name, W / 2, H * 0.075f + 46 * u, 26 * u, 0xFFFFD21F, Paint.Align.CENTER, true);
        float x = W * 0.06f, mw = W * 0.50f, y = H * 0.19f;
        String[] txt = fa ? d.briefFa : d.briefEn;
        for (String s : txt) y = para(c, s, x, y, mw, 25 * u, 0xFFE6ECF0, false, fa) + 10 * u;
        y = para(c, fa ? d.weatherFa : d.weatherEn, x, y + 6 * u, mw, 23 * u, 0xFF9FD3FF, false, fa);
        // elevation profile with pads
        rTmp.set(W * 0.60f, H * 0.17f, W * 0.95f, H * 0.64f);
        fill(c, rTmp, 0xFF10161B, 12 * u);
        stroke(c, rTmp, 0xFF3A4650, 2 * u, 12 * u);
        float pl = rTmp.left + 18 * u, pr = rTmp.right - 18 * u, pb = rTmp.bottom - 36 * u, pt = rTmp.top + 44 * u;
        double xmin = -300, xmax = 100;
        for (int i = 0; i < Terrain.padX.length; i++) xmax = Math.max(xmax, Terrain.padX[i]);
        if (d.raftX > 0) xmax = Math.max(xmax, d.raftX);
        xmax += 500;
        if (d.startX < xmin) xmin = d.startX - 200;
        double lo = 1e9, hi = -1e9;
        for (int i = 0; i <= 120; i++) { double h2 = Terrain.h(xmin + i * (xmax - xmin) / 120); lo = Math.min(lo, h2); hi = Math.max(hi, h2); }
        lo -= 20; hi += 30;
        path.reset();
        path.moveTo(pl, pb);
        for (int i = 0; i <= 120; i++) {
            double wx = xmin + i * (xmax - xmin) / 120;
            float px = pl + (float) ((wx - xmin) / (xmax - xmin)) * (pr - pl);
            float py = pb - (float) ((Terrain.h(wx) - lo) / (hi - lo)) * (pb - pt);
            path.lineTo(px, py);
        }
        path.lineTo(pr, pb);
        path.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(d.map == Terrain.MOUNTAIN ? 0xFF7A6B52 : 0xFF3D6B3A);
        c.drawPath(path, p);
        if (Terrain.seaMap) {
            float sy0 = pb - (float) ((0 - lo) / (hi - lo)) * (pb - pt);
            p.setColor(0x992E86B8);
            c.drawRect(pl, sy0, pr, pb, p);
        }
        for (int i = 0; i < Terrain.padX.length; i++) {
            float px = pl + (float) ((Terrain.padX[i] - xmin) / (xmax - xmin)) * (pr - pl);
            float py = pb - (float) ((Terrain.h(Terrain.padX[i]) - lo) / (hi - lo)) * (pb - pt);
            p.setStyle(Paint.Style.FILL);
            p.setColor(i == d.landPad ? 0xFFFFD21F : 0xFFE6ECF0);
            c.drawCircle(px, py - 4 * u, 6 * u, p);
            tx(c, Terrain.padName[i], px, py - 24 * u - (i % 2) * 22 * u, 15 * u, i == d.landPad ? 0xFFFFD21F : 0xFFB8C4CC, Paint.Align.CENTER, true);
        }
        if (d.raftX > 0) {
            float px = pl + (float) ((d.raftX - xmin) / (xmax - xmin)) * (pr - pl);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFF7A1F);
            c.drawCircle(px, pb - (float) ((0 - lo) / (hi - lo)) * (pb - pt) - 4 * u, 7 * u, p);
            tx(c, "RAFT", px, pb - (float) ((0 - lo) / (hi - lo)) * (pb - pt) - 24 * u, 15 * u, 0xFFFF9A4E, Paint.Align.CENTER, true);
        }
        tx(c, T("Route profile", "نیمرخ مسیر"), rTmp.centerX(), rTmp.bottom - 16 * u, 18 * u, 0xFFB8C4CC, Paint.Align.CENTER, false);
        float bw = 360 * u, bh = 84 * u;
        rTmp.set(W * 0.5f - bw - 16 * u, H * 0.84f, W * 0.5f - 16 * u, H * 0.84f + bh);
        button(c, rTmp, T("BACK", "بازگشت"), B_SELBACK, false);
        rTmp.set(W * 0.5f + 16 * u, H * 0.84f, W * 0.5f + 16 * u + bw, H * 0.84f + bh);
        button(c, rTmp, T("FLY", "پرواز"), B_FLY, true);
    }

    private void drawManual(Canvas c) {
        float W = getWidth(), H = getHeight();
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF10151A);
        c.drawRect(0, 0, W, H, p);
        String[] pg = Manual.page(fa, manualPage);
        float mx = W * 0.07f, mw = W * 0.86f;
        tx(c, pg[0], fa ? mx + mw : mx, H * 0.09f, 48 * u, 0xFFFFD21F, fa ? Paint.Align.RIGHT : Paint.Align.LEFT, true);
        float y = H * 0.17f;
        for (int i = 1; i < pg.length; i++) {
            String t = pg[i];
            if (t.startsWith("- ")) t = "\u2022 " + t.substring(2);
            y = para(c, t, mx, y, mw, 26 * u, 0xFFE6ECF0, false, fa) + 8 * u;
        }
        tx(c, (manualPage + 1) + " / " + Manual.pages(), W / 2, H * 0.935f, 24 * u, 0xFFB8C4CC, Paint.Align.CENTER, false);
        float bh = 72 * u, by = H * 0.90f, bw = 250 * u;
        rTmp.set(W * 0.07f, by, W * 0.07f + bw, by + bh);
        button(c, rTmp, T("< PREV", "قبلی >"), B_PREV, false);
        rTmp.set(W * 0.07f + bw + 14 * u, by, W * 0.07f + 2 * bw + 14 * u, by + bh);
        button(c, rTmp, T("NEXT >", "< بعدی"), B_NEXT, false);
        rTmp.set(W * 0.93f - bw, by, W * 0.93f, by + bh);
        button(c, rTmp, T("BACK", "بازگشت"), B_BACK, false);
        rTmp.set(W * 0.93f - 2 * bw - 14 * u, by, W * 0.93f - bw - 14 * u, by + bh);
        button(c, rTmp, fa ? "English" : "فارسی", B_LANG, false);
    }

    private void drawDebrief(Canvas c) {
        float W = getWidth(), H = getHeight();
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, 0, H, mis.complete ? 0xFF12301F : 0xFF3A1512, 0xFF0A0D10, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(null);
        boolean ok = mis.complete;
        tx(c, ok ? T("MISSION COMPLETE", "ماموریت موفق") : T("MISSION FAILED", "ماموریت ناموفق"), W / 2, H * 0.12f, 70 * u, ok ? 0xFF58C77A : 0xFFFF5A4A, Paint.Align.CENTER, true);
        tx(c, (fa ? def.titleFa : def.titleEn), W / 2, H * 0.19f, 30 * u, 0xFFD8E2EA, Paint.Align.CENTER, false);
        float y = H * 0.28f, x = W * 0.30f, w = W * 0.40f;
        if (ok) {
            String k0 = def.procMode == 0 ? T("Start-up", "استارت") : def.procMode == 2 ? T("Emergency handling", "مدیریت اضطراری") : T("Procedure", "روال");
            String k3 = def.bonusMode == 1 ? T("Time", "زمان") : T("Fuel", "سوخت");
            String[] k = {k0, T("Flight", "پرواز"), T("Landing", "فرود"), k3};
            double[] v = {mis.sStart, mis.sFlight, mis.sLand, mis.sBonus};
            double[] mx = {30, 30, 30, 10};
            for (int i = 0; i < 4; i++) {
                tx(c, k[i], x, y, 34 * u, 0xFFE6ECF0, Paint.Align.LEFT, false);
                tx(c, String.format(Locale.US, "%.0f / %.0f", v[i], mx[i]), x + w, y, 34 * u, 0xFFFFFFFF, Paint.Align.RIGHT, true);
                y += 56 * u;
            }
            tx(c, T("TOTAL", "مجموع"), x, y + 10 * u, 44 * u, 0xFFFFD21F, Paint.Align.LEFT, true);
            tx(c, String.format(Locale.US, "%.0f", mis.score), x + w, y + 10 * u, 56 * u, 0xFFFFD21F, Paint.Align.RIGHT, true);
            tx(c, mis.rating, W / 2, y + 86 * u, 54 * u, 0xFF58C77A, Paint.Align.CENTER, true);
            tx(c, String.format(Locale.US, "Touchdown: %.0f fpm, %.1f kt, %.0f m from the centre", sim.touchVz * 196.85, sim.touchSpeed * 1.944,
                    Math.abs(sim.x - Terrain.padX[Math.max(0, def.steps[def.steps.length - 1].pad)])), W / 2, y + 150 * u, 24 * u, 0xFFB8C4CC, Paint.Align.CENTER, false);
        } else {
            para(c, mis.failMsg.isEmpty() ? T("Mission failed.", "ماموریت ناموفق بود.") : mis.failMsg, W * 0.20f, y, W * 0.60f, 36 * u, 0xFFFFFFFF, true, false);
        }
        float bw = 360 * u, bh = 84 * u;
        rTmp.set(W * 0.5f - bw - 16 * u, H * 0.84f, W * 0.5f - 16 * u, H * 0.84f + bh);
        button(c, rTmp, T("MISSIONS", "ماموریت‌ها"), B_SELBACK, false);
        rTmp.set(W * 0.5f + 16 * u, H * 0.84f, W * 0.5f + 16 * u + bw, H * 0.84f + bh);
        button(c, rTmp, T("TRY AGAIN", "تلاش دوباره"), B_RETRY, true);
    }

    // ------------------------------------------------------------------ input
    private int hitFlight(float x, float y) {
        rTmp.set(rColl); rTmp.inset(-12 * u, 0);
        if (rTmp.contains(x, y)) return C_COLL;
        rTmp.set(rThr); rTmp.inset(-8 * u, 0);
        if (rTmp.contains(x, y)) return C_THR;
        rTmp.set(rCyc); rTmp.inset(-12 * u, 0);
        if (rTmp.contains(x, y)) return C_CYC;
        if (rPedL.contains(x, y)) return C_PL;
        if (rPedR.contains(x, y)) return C_PR;
        if (rStart1.contains(x, y)) return C_START1;
        if (ac.engines > 1 && rStart2.contains(x, y)) return C_START2;
        if (ac.hasHoist && rWdn.contains(x, y)) return C_WDN;
        if (ac.hasHoist && rWup.contains(x, y)) return C_WUP;
        return C_NONE;
    }

    private float sliderVal(RectF r, float y) {
        float gt = r.top + 34 * u, gb = r.bottom - 34 * u;
        return Math.max(0, Math.min(1, (gb - y) / (gb - gt)));
    }

    private void applyControl(int ctrl, int id, float y, boolean down) {
        switch (ctrl) {
            case C_COLL: {
                float v = sliderVal(rColl, y);
                if (down) grab[id] = (Math.abs(v - (float) sim.collective) < 0.12f) ? v - (float) sim.collective : 0;
                sim.collective = Math.max(0, Math.min(1, v - grab[id]));
                break;
            }
            case C_THR: {
                float v = sliderVal(rThr, y);
                if (down) grab[id] = (Math.abs(v - (float) sim.throttle) < 0.12f) ? v - (float) sim.throttle : 0;
                sim.throttle = Math.max(0, Math.min(1, v - grab[id]));
                break;
            }
            case C_CYC: {
                float v = sliderVal(rCyc, y) * 2 - 1;
                if (down) grab[id] = (Math.abs(v - (float) sim.cyclic) < 0.25f) ? v - (float) sim.cyclic : 0;
                sim.cyclic = Math.max(-1, Math.min(1, v - grab[id]));
                break;
            }
            default: break;
        }
    }

    private void releaseControl(int ctrl) {
        if (ctrl == C_PL || ctrl == C_PR) pedalTarget = 0;
        if (ctrl == C_START1) start1Held = false;
        if (ctrl == C_START2) start2Held = false;
        if (ctrl == C_WDN) wdnHeld = false;
        if (ctrl == C_WUP) wupHeld = false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN || a == MotionEvent.ACTION_POINTER_DOWN) {
            int idx = e.getActionIndex(), id = Math.min(31, e.getPointerId(idx));
            float x = e.getX(idx), y = e.getY(idx);
            long now = System.currentTimeMillis();
            if (state == ST_FLIGHT) {
                int ctrl = hitFlight(x, y);
                if (ctrl != C_NONE) {
                    ctl[id] = ctrl;
                    if (ctrl == C_PL) pedalTarget = -1;
                    else if (ctrl == C_PR) pedalTarget = 1;
                    else if (ctrl == C_START1) { start1Held = true; performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); }
                    else if (ctrl == C_START2) { start2Held = true; performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); }
                    else if (ctrl == C_WDN) wdnHeld = true;
                    else if (ctrl == C_WUP) wupHeld = true;
                    else {
                        if (ctrl == C_CYC) { if (now - lastCycTap < 320) sim.cyclic = 0; lastCycTap = now; }
                        applyControl(ctrl, id, y, true);
                    }
                    return true;
                }
                for (int i = 0; i < swR.length; i++) {
                    if (swR[i].contains(x, y)) {
                        int sid = ac.switches[i];
                        sim.swToggle(sid);
                        if (sid == 11) { prefs.edit().putBoolean("assist", sim.assist).apply(); }
                        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
                        return true;
                    }
                }
            }
            if (now - lastTapMs > 180) { if (tapButton(x, y)) lastTapMs = now; }
            return true;
        }
        if (a == MotionEvent.ACTION_MOVE) {
            if (state == ST_FLIGHT) {
                for (int i = 0; i < e.getPointerCount(); i++) {
                    int id = Math.min(31, e.getPointerId(i));
                    if (ctl[id] > 0) applyControl(ctl[id], id, e.getY(i), false);
                }
            }
            return true;
        }
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_POINTER_UP || a == MotionEvent.ACTION_CANCEL) {
            int idx = e.getActionIndex(), id = Math.min(31, e.getPointerId(idx));
            if (a == MotionEvent.ACTION_CANCEL) { for (int i = 0; i < ctl.length; i++) { releaseControl(ctl[i]); ctl[i] = -1; } }
            else { releaseControl(ctl[id]); ctl[id] = -1; }
            return true;
        }
        return true;
    }

    private boolean tapButton(float x, float y) {
        for (int i = btnR.size() - 1; i >= 0; i--) {
            if (!btnR.get(i).contains(x, y)) continue;
            performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP);
            int bid = btnId.get(i);
            if (bid >= B_SEL) {
                selIdx = bid - B_SEL;
                Terrain.setMap(Mission.DEFS[selIdx].map);
                state = ST_BRIEF;
                return true;
            }
            switch (bid) {
                case B_START: state = ST_SELECT; break;
                case B_FLY: case B_RETRY: case B_RESTART: startMission(selIdx); break;
                case B_SELBACK:
                    if (state == ST_DEBRIEF) backdropSim();
                    state = ST_SELECT;
                    break;
                case B_MANUAL: manualFrom = state; manualPage = 0; state = ST_MANUAL; break;
                case B_SETTINGS: settingsFrom = state; state = ST_SETTINGS; break;
                case B_EXIT: host.exitApp(); break;
                case B_MENU:
                    if (state == ST_FLIGHT) state = ST_PAUSE;
                    else toMenu();
                    break;
                case B_RESUME: state = ST_FLIGHT; lastNs = 0; break;
                case B_BACK:
                    if (state == ST_MANUAL) state = manualFrom == ST_FLIGHT ? ST_PAUSE : manualFrom;
                    else if (state == ST_SETTINGS) { save(); state = settingsFrom; }
                    else toMenu();
                    break;
                case B_PREV: manualPage = Math.max(0, manualPage - 1); break;
                case B_NEXT: manualPage = Math.min(Manual.pages() - 1, manualPage + 1); break;
                case B_LANG: fa = !fa; save(); break;
                case B_COACH: coach = !coach; save(); break;
                case B_SOUND: soundOn = !soundOn; save(); break;
                case B_ASSIST: {
                    boolean v = !prefs.getBoolean("assist", true);
                    prefs.edit().putBoolean("assist", v).apply();
                    sim.assist = v;
                    break;
                }
                default: break;
            }
            return true;
        }
        return false;
    }
}
