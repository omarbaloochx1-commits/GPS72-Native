package com.hueysim.uh1;

import java.util.ArrayList;

/** Mission definitions (7 missions, 2 aircraft, 3 maps) and the runtime checklist / scoring. */
final class Mission {
    // ---- step types
    static final int U_BATT = 1, U_FUEL = 2, U_INV = 3, U_THR_CLOSED = 4, U_N1_15 = 5, U_IDLE = 6, U_N1_62 = 7, U_STARTFUEL_OFF = 8, U_GEN = 9, U_HYD = 10, U_THR_FULL = 11, U_CHECK = 12;
    static final int K_BATT = 20, K_INV = 21, K_THR_IDLE = 22, K_E1_15 = 23, K_E1_LIT = 24, K_E1_62 = 25, K_E2_15 = 26, K_E2_LIT = 27, K_E2_62 = 28, K_GEN = 29, K_HYD = 30, K_THR_FULL = 31, K_CHECK = 32;
    static final int F_TAKEOFF = 40, F_HOVER = 41, F_CLIMB = 42, F_GEARUP = 43, F_GEARDN = 44, F_REACH = 45, F_NEAR = 46, F_LAND = 47, F_LAND_WAIT = 48,
            F_HOIST_POS = 50, F_HOIST_LOWER = 51, F_HOIST_LOAD = 52, F_HOIST_RAISE = 53, F_FAIL = 60, F_AUTOLAND = 61;

    static final class Step {
        int type, pad;
        double a, b, c;
        String en, fa, hEn, hFa;
    }

    static final class Def {
        int id, aircraft, map;
        String titleEn, titleFa, weatherEn, weatherFa;
        String[] briefEn, briefFa;
        boolean cold, airborne;
        double startX, oat, wind, fuel, payload, airAgl, airSpeed;
        int landPad, bonusMode, procMode;                 // bonus: 0 fuel, 1 time; proc: 0 start-up, 1 none, 2 rotor management
        double timeTarget, failX, landTol;
        int failEng = -1;
        boolean ignoreLowRpm;
        double raftX;
        Step[] steps;
    }

    static final Def[] DEFS = build();

    // ------------------------------------------------------------------ runtime
    Def def;
    int step;
    boolean complete, failed;
    String failMsg = "";
    double hoverT, landedT, checkT, waitT, posT, hookT, startTime;
    boolean failTriggered;
    String pendingFail;
    double failTime;
    double score, sStart, sFlight, sLand, sBonus;
    String rating = "";
    boolean scored;

    Mission(Def d) { def = d; reset(); }

    void reset() {
        step = 0; complete = failed = scored = false; failMsg = ""; pendingFail = null; hoverT = landedT = checkT = waitT = posT = hookT = 0; failTriggered = false; failTime = 0;
        score = sStart = sFlight = sLand = sBonus = 0; rating = "";
    }

    int n() { return def.steps.length; }

    Step cur() { return def.steps[Math.min(step, def.steps.length - 1)]; }

    double padX(int i) { return Terrain.padX[Math.max(0, Math.min(Terrain.padX.length - 1, i))]; }

    private boolean isHoist(int t) { return t == F_HOIST_POS || t == F_HOIST_LOWER || t == F_HOIST_LOAD || t == F_HOIST_RAISE; }

    private boolean isPadStep(int t) { return t == F_AUTOLAND || t == F_LAND || t == F_NEAR || t == F_LAND_WAIT; }

    /** Signed distance (m, +east) from the aircraft to the current objective. */
    double distTarget(Sim s) {
        Step c = cur();
        double tx;
        if (isHoist(c.type)) tx = def.raftX;
        else if (c.type == F_REACH) tx = c.a;
        else tx = padX(isPadStep(c.type) ? c.pad : def.landPad);
        return tx - s.x;
    }

    String targetName() {
        Step c = cur();
        if (isHoist(c.type)) return "SURVIVOR";
        if (c.type == F_REACH) return "WAYPOINT";
        int p = isPadStep(c.type) ? c.pad : def.landPad;
        return Terrain.padName[Math.max(0, Math.min(Terrain.padName.length - 1, p))];
    }

    private boolean ok(int i, Sim s, double dt) {
        Step st = def.steps[i];
        Sim.Eng e0 = s.eng[0], e1 = s.eng.length > 1 ? s.eng[1] : s.eng[0];
        switch (st.type) {
            case U_BATT: return s.batt;
            case U_FUEL: return s.fuelMain && s.fuelStart;
            case U_INV: return s.inverter;
            case U_THR_CLOSED: return s.throttle < 0.04 || s.lit;
            case U_N1_15: return s.n1 >= 15 || s.lit;
            case U_IDLE: return s.lit;
            case U_N1_62: return s.lit && s.n1 >= 62 && !s.starterBtn;
            case U_STARTFUEL_OFF: return s.lit && !s.fuelStart;
            case U_GEN: return s.genOnline;
            case U_HYD: return s.hyd;
            case U_THR_FULL: return s.throttle > 0.95 && s.nr >= 98;
            case U_CHECK: case K_CHECK: {
                boolean good = s.engOilP >= 38 && s.xmsnOilP >= 38 && s.egt < 610 && s.nr >= 98;
                if (s.eng.length > 1) good &= e1.oilP >= 38;
                for (int k = 0; k < Sim.NL; k++) if (s.light[k]) good = false;
                checkT = good ? checkT + dt : 0;
                return checkT > 2.0;
            }
            case K_BATT: return s.batt;
            case K_INV: return s.inverter;
            case K_THR_IDLE: return (s.throttle >= 0.06 && s.throttle <= 0.30) || e0.lit;
            case K_E1_15: return e0.n1 >= 15 || e0.lit;
            case K_E1_LIT: return e0.lit;
            case K_E1_62: return e0.lit && e0.n1 >= 62 && !s.starterBtn;
            case K_E2_15: return e1.n1 >= 15 || e1.lit;
            case K_E2_LIT: return e1.lit;
            case K_E2_62: return e1.lit && e1.n1 >= 62 && !s.starter2;
            case K_GEN: return e0.genOnline && e1.genOnline;
            case K_HYD: return s.hyd;
            case K_THR_FULL: return s.throttle > 0.95 && s.nr >= 98;
            case F_TAKEOFF: return !s.onGround && s.agl >= 2.0;
            case F_HOVER: {
                boolean hov = !s.onGround && s.agl >= 1.5 && s.agl <= 9 && Math.abs(s.vx) < 2.5 && s.nr > 96;
                hoverT = hov ? hoverT + dt : Math.max(0, hoverT - dt);
                return hoverT >= st.a;
            }
            case F_CLIMB: return s.agl >= st.a && s.ias >= st.b;
            case F_GEARUP: return s.gearPos < 0.05 && !s.onGround;
            case F_GEARDN: return s.gearPos > 0.95;
            case F_REACH: return st.b >= 0 ? s.x >= st.a : s.x <= st.a;
            case F_NEAR: return Math.abs(padX(st.pad) - s.x) < st.a && s.ias < st.b && s.agl < st.c;
            case F_LAND: {
                double half = Terrain.padHalf[st.pad] + 4;
                boolean down = s.onGround && Math.abs(s.x - padX(st.pad)) <= half && Math.abs(s.vx) < 1.0;
                landedT = down ? landedT + dt : 0;
                return landedT >= 3;
            }
            case F_LAND_WAIT: {
                double half = Terrain.padHalf[st.pad] + 4;
                boolean down = s.onGround && Math.abs(s.x - padX(st.pad)) <= half && Math.abs(s.vx) < 1.0;
                waitT = down ? waitT + dt : 0;
                if (waitT >= st.a) { s.payloadKg += st.b; return true; }
                return false;
            }
            case F_HOIST_POS: {
                boolean on = !s.onGround && Math.abs(s.x - def.raftX) < 12 && s.agl >= 12 && s.agl <= 48 && Math.abs(s.vx) < 3;
                posT = on ? posT + dt : Math.max(0, posT - dt);
                return posT >= 4;
            }
            case F_HOIST_LOWER: return s.cableLen >= Math.max(5, s.agl - 3) && Math.abs(s.x - def.raftX) < 20;
            case F_HOIST_LOAD: {
                boolean on = s.cableLen >= Math.max(5, s.agl - 3.5) && Math.abs(s.x - def.raftX) < 10 && Math.abs(s.vx) < 3;
                hookT = on ? hookT + dt : Math.max(0, hookT - dt * 0.5);
                if (hookT >= 4) { s.hookLoaded = true; return true; }
                return false;
            }
            case F_HOIST_RAISE: return s.hookLoaded && s.cableLen <= 1.0;
            case F_FAIL: return failTriggered && s.time - failTime > 1.0;
            case F_AUTOLAND: {
                boolean stopped = s.onGround && Math.abs(s.vx) < 1.0;
                landedT = stopped ? landedT + dt : 0;
                if (landedT >= 3) {
                    if (Math.abs(s.x - padX(st.pad)) <= st.a) return true;
                    pendingFail = "You stopped " + (int) Math.abs(s.x - padX(st.pad)) + " m from the pad - outside the " + (int) st.a + " m landing zone.";
                }
                return false;
            }
            default: return false;
        }
    }

    private boolean skippable(int t) { return t == F_HOVER || t == F_CLIMB || t == F_REACH; }

    private boolean skipTarget(int t) { return t == F_CLIMB || t == F_REACH || t == F_NEAR; }

    /** Advances the checklist and the scripted events. */
    void update(Sim s, double dt) {
        if (complete || failed) return;
        if (s.crashed) { failed = true; failMsg = s.crashMsg; return; }
        if (def.failEng >= 0 && !failTriggered && s.x >= def.failX && !s.onGround) {
            failTriggered = true; failTime = s.time; s.failEngine(def.failEng);
        }
        int guard = 0;
        while (step < n() && guard++ < n() * 2) {
            if (ok(step, s, dt)) { step++; continue; }
            boolean jumped = false;
            if (skippable(def.steps[step].type)) {
                for (int j = Math.min(n() - 1, step + 4); j > step; j--) {
                    if (skipTarget(def.steps[j].type) && ok(j, s, 0)) { step = j + 1; jumped = true; break; }
                }
            }
            if (!jumped) break;
        }
        if (pendingFail != null) { failed = true; failMsg = pendingFail; return; }
        if (step >= n()) { complete = true; computeScore(s); }
    }

    void computeScore(Sim s) {
        if (scored) return;
        scored = true;
        if (def.procMode == 0) {
            sStart = 30;
            if (s.hotStart || s.engDamaged) sStart -= 18;
            if (s.battCharge < 0.45) sStart -= 4;
        } else if (def.procMode == 2) sStart = 30 - Math.min(30, s.veryLowRpmTime * 2.0);
        else sStart = 30;
        sStart = Math.max(0, sStart);
        sFlight = 30;
        if (!def.ignoreLowRpm) sFlight -= Math.min(10, s.lowRpmTime * 2);
        sFlight -= Math.min(6, s.highRpmTime * 2);
        sFlight -= Math.min(6, s.vneTime * 3);
        sFlight -= Math.min(8, s.overTorqueTime * 1.0);
        if (s.xmsnDamaged) sFlight -= 6;
        sFlight = Math.max(0, sFlight);
        Step last = def.steps[n() - 1];
        double tol = def.landTol > 0 ? def.landTol : Terrain.padHalf[Math.max(0, last.pad)];
        double dx = Math.abs(s.x - padX(last.pad));
        double prec = 10 * (1 - Math.min(1, dx / tol));
        double soft = s.touchVz <= 0.5 ? 10 : (s.touchVz <= 1.5 ? 10 - (s.touchVz - 0.5) * 5 : Math.max(0, 5 - (s.touchVz - 1.5) * 4.5));
        double spd = s.touchSpeed <= 1 ? 10 : Math.max(0, 10 - (s.touchSpeed - 1) * (def.procMode == 2 || def.failEng >= 0 ? 0.8 : 2));
        sLand = prec + soft + spd;
        if (s.hardLanding) sLand -= 6;
        if (s.tailStrike) sLand -= 4;
        sLand = Math.max(0, Math.min(30, sLand));
        if (def.bonusMode == 1) {
            double t = s.time - startTime;
            sBonus = Math.max(0, Math.min(10, 10 * (1 - (t - def.timeTarget) / def.timeTarget)));
        } else sBonus = Math.max(0, Math.min(10, 10 * ((s.fuelLb / Math.max(1, def.fuel)) - 0.35) / 0.45));
        score = Math.round(sStart + sFlight + sLand + sBonus);
        rating = score >= 90 ? "ACE" : score >= 75 ? "PILOT" : score >= 55 ? "TRAINEE" : "ROOKIE";
    }

    // ------------------------------------------------------------------ definitions
    private static Step st(int type, int pad, double a, double b, double c, String en, String fa, String hEn, String hFa) {
        Step s = new Step();
        s.type = type; s.pad = pad; s.a = a; s.b = b; s.c = c; s.en = en; s.fa = fa; s.hEn = hEn; s.hFa = hFa;
        return s;
    }

    private static void hueyStart(ArrayList<Step> l) {
        l.add(st(U_BATT, 0, 0, 0, 0, "BATTERY switch ON", "کلید BATTERY را روشن کنید", "Switch is on the left of the switch panel (tap it).", "کلید در سمت چپ پنل کلیدها است (لمس کنید)."));
        l.add(st(U_FUEL, 0, 0, 0, 0, "MAIN FUEL ON and START FUEL ON", "کلیدهای MAIN FUEL و START FUEL را روشن کنید",
                "Both fuel switches are needed: MAIN opens the valve, START feeds the igniter fuel.", "هر دو لازم‌اند: MAIN شیر سوخت را باز می‌کند و START سوخت جرقه‌زن را می‌دهد."));
        l.add(st(U_INV, 0, 0, 0, 0, "INVERTER ON", "کلید INVERTER را روشن کنید", "The inverter powers the attitude indicator and RMI.", "اینورتر برق شاخص وضعیت (ADI) و RMI را تأمین می‌کند."));
        l.add(st(U_THR_CLOSED, 0, 0, 0, 0, "Throttle CLOSED (twist grip fully down)", "دسته گاز (Throttle) را کاملاً ببندید (پایین)",
                "The throttle slider is next to the collective. 0 = closed (cut-off).", "اسلایدر گاز کنار کلکتیو است. صفر = بسته (قطع سوخت)."));
        l.add(st(U_N1_15, 0, 0, 0, 0, "Hold START until N1 reaches 15 %", "دکمهٔ START را نگه دارید تا N1 به ۱۵٪ برسد",
                "Press and HOLD the STARTER button. Battery voltage will sag - that is normal.", "دکمهٔ STARTER را بزنید و نگه دارید. افت ولتاژ باتری طبیعی است."));
        l.add(st(U_IDLE, 0, 0, 0, 0, "Open throttle to IDLE (about 15 %) - watch EGT", "گاز را روی IDLE (حدود ۱۵٪) بیاورید - EGT را ببینید",
                "Open the throttle slightly when N1 is 15 %. Too early (below about 10 %) = HOT START (EGT above 780 C).", "وقتی N1 به ۱۵٪ رسید گاز را کمی باز کنید. خیلی زود (زیر حدود ۱۰٪) = استارت داغ (EGT بالای ۷۸۰)."));
        l.add(st(U_N1_62, 0, 0, 0, 0, "Hold START to N1 40 %, release, wait for N1 about 64 %", "START را تا N1 برابر ۴۰٪ نگه دارید، رها کنید، تا N1 حدود ۶۴٪",
                "Keep holding START until 40 %. If you let go sooner the engine stalls.", "تا ۴۰٪ نگه دارید. اگر زودتر رها کنید موتور خفه می‌شود."));
        l.add(st(U_STARTFUEL_OFF, 0, 0, 0, 0, "START FUEL OFF", "START FUEL را خاموش کنید", "After the engine is self-sustaining the start fuel must be turned off.", "وقتی موتور خودکفا شد، سوخت استارت باید خاموش شود."));
        l.add(st(U_GEN, 0, 0, 0, 0, "GEN ON - bus 28 V", "GEN را روشن کنید - ولتاژ ۲۸ ولت", "The generator takes over from the battery. DC GEN light goes out.", "ژنراتور جای باتری را می‌گیرد. چراغ DC GEN خاموش می‌شود."));
        l.add(st(U_HYD, 0, 0, 0, 0, "HYD CONT ON", "HYD CONT را روشن کنید", "Hydraulics make the controls light. Without them the controls are heavy.", "هیدرولیک کنترل‌ها را سبک می‌کند. بدون آن کنترل‌ها سنگین‌اند."));
        l.add(st(U_THR_FULL, 0, 0, 0, 0, "Roll throttle FULL OPEN - rotor to 100 %", "گاز را کامل باز کنید - دور روتور به ۱۰۰٪",
                "Take your time. The governor holds 100 %. Do NOT raise the collective yet.", "عجله نکنید. گاورنر دور را روی ۱۰۰٪ نگه می‌دارد. هنوز کلکتیو را بالا نبرید."));
        l.add(st(U_CHECK, 0, 0, 0, 0, "Check gauges: oil pressures green, no cautions", "ابزارها را چک کنید: فشار روغن سبز، بدون هشدار",
                "Look for: ENG OIL 40-70 psi, XMSN OIL about 50 psi, EGT under 610 C, rotor 100 %.", "بررسی: فشار روغن موتور ۴۰ تا ۷۰، فشار روغن گیربکس حدود ۵۰، EGT زیر ۶۱۰، دور روتور ۱۰۰٪."));
    }

    private static void seaKingStart(ArrayList<Step> l) {
        l.add(st(K_BATT, 0, 0, 0, 0, "BATTERY ON", "کلید BATTERY را روشن کنید", "Switch is on the left of the switch panel.", "کلید در سمت چپ پنل کلیدها است."));
        l.add(st(K_INV, 0, 0, 0, 0, "INVERTER ON", "کلید INVERTER را روشن کنید", "The inverter powers the attitude indicator and RMI.", "اینورتر برق شاخص وضعیت و RMI را می‌دهد."));
        l.add(st(K_THR_IDLE, 0, 0, 0, 0, "Throttle to the IDLE detent (about 15 %)", "گاز را روی IDLE (حدود ۱۵٪) بگذارید",
                "On the Sea King the engine speed lever stays at GROUND IDLE while starting.", "در Sea King اهرم دور موتور هنگام استارت روی GROUND IDLE می‌ماند."));
        l.add(st(K_E1_15, 0, 0, 0, 0, "Hold START 1 until engine 1 N1 reaches 15 %", "START 1 را نگه دارید تا N1 موتور ۱ به ۱۵٪ برسد",
                "The two start buttons are at the right of the switch panel. Do NOT open the fuel yet.", "دو دکمهٔ استارت سمت راست پنل کلیدها هستند. هنوز سوخت را باز نکنید."));
        l.add(st(K_E1_LIT, 0, 0, 0, 0, "ENG1 FUEL ON at 15 % - light-off", "در ۱۵٪ ENG1 FUEL را روشن کنید - احتراق",
                "Opening the fuel cock too early (N1 below about 10 %) gives a HOT START.", "باز کردن زودهنگام شیر سوخت (N1 زیر حدود ۱۰٪) استارت داغ می‌دهد."));
        l.add(st(K_E1_62, 0, 0, 0, 0, "Hold START 1 to 40 %, release; engine 1 N1 about 64 %", "START 1 را تا ۴۰٪ نگه دارید، رها کنید؛ N1 موتور ۱ حدود ۶۴٪",
                "Release at 40 %. EGT should peak near 550 C.", "در ۴۰٪ رها کنید. اوج EGT باید نزدیک ۵۵۰ باشد."));
        l.add(st(K_E2_15, 0, 0, 0, 0, "Hold START 2 until engine 2 N1 reaches 15 %", "START 2 را نگه دارید تا N1 موتور ۲ به ۱۵٪ برسد", "Same procedure for the second engine.", "همان روال برای موتور دوم."));
        l.add(st(K_E2_LIT, 0, 0, 0, 0, "ENG2 FUEL ON at 15 % - light-off", "در ۱۵٪ ENG2 FUEL را روشن کنید - احتراق", "Watch EGT of engine 2.", "EGT موتور ۲ را ببینید."));
        l.add(st(K_E2_62, 0, 0, 0, 0, "Hold START 2 to 40 %, release; engine 2 N1 about 64 %", "START 2 را تا ۴۰٪ نگه دارید، رها کنید؛ N1 موتور ۲ حدود ۶۴٪",
                "Both engines now at ground idle.", "هر دو موتور حالا روی دور آرام هستند."));
        l.add(st(K_GEN, 0, 0, 0, 0, "GEN 1 and GEN 2 ON", "GEN 1 و GEN 2 را روشن کنید", "Bus voltage rises to 28 V; GEN FAIL lights go out.", "ولتاژ باس به ۲۸ ولت می‌رسد؛ چراغ‌های GEN FAIL خاموش می‌شوند."));
        l.add(st(K_HYD, 0, 0, 0, 0, "HYD CONT ON", "HYD CONT را روشن کنید", "Hydraulics are needed for the controls.", "برای کنترل‌ها هیدرولیک لازم است."));
        l.add(st(K_THR_FULL, 0, 0, 0, 0, "Throttle FULL OPEN - rotor to 100 %", "گاز کامل باز - دور روتور به ۱۰۰٪", "Five blades spool up slowly. Keep the collective down.", "روتور پنج‌پره آرام بالا می‌آید. کلکتیو پایین بماند."));
        l.add(st(K_CHECK, 0, 0, 0, 0, "Check gauges: both engines, oil, no cautions", "ابزارها را چک کنید: هر دو موتور، روغن، بدون هشدار", "Torque of both engines should read about the same.", "گشتاور دو موتور باید تقریباً برابر باشد."));
    }

    private static Def base(int id, String te, String tf, int ac, int map, boolean cold, double startX, double oat, double wind, double fuel, double payload) {
        Def d = new Def();
        d.id = id; d.titleEn = te; d.titleFa = tf; d.aircraft = ac; d.map = map; d.cold = cold; d.startX = startX; d.oat = oat; d.wind = wind; d.fuel = fuel; d.payload = payload;
        d.procMode = cold ? 0 : 1; d.landTol = 0;
        return d;
    }

    private static Def[] build() {
        ArrayList<Def> defs = new ArrayList<>();
        ArrayList<Step> l;

        // 1. Delivery flight (UH-1H, valley, cold start)
        Def d1 = base(0, "Delivery Flight", "پرواز تحویل محموله", Aircraft.HUEY, Terrain.VALLEY, true, 0, 22, 3.5, 780, 150);
        d1.weatherEn = "Wind 270 at 7 kt with gusts, OAT 22 C, clear. Fuel 780 lb. Hills at 2.6 km (+80 m) and 4.5 km (+55 m).";
        d1.weatherFa = "باد ۲۷۰ با ۷ نات و وزش‌های ناگهانی، دمای هوا ۲۲ درجه، صاف. سوخت ۷۸۰ پوند. تپه‌ها در ۲٫۶ کیلومتر (+۸۰ متر) و ۴٫۵ کیلومتر (+۵۵ متر).";
        d1.briefEn = new String[]{"Fly the Huey from Base Alpha to Firebase Bravo, 6.8 km east, and deliver 150 kg of supplies.",
                "You start cold and dark on the pad: battery off, engine stopped. Start the engine, bring the rotor to 100 %, take off, fly the route and land on the Bravo pad."};
        d1.briefFa = new String[]{"با هلیکوپتر Huey از بیس آلفا تا فایربیس براوو، ۶٫۸ کیلومتر شرق، پرواز کنید و ۱۵۰ کیلوگرم بار برسانید.",
                "سرد و خاموش روی پد شروع می‌کنید: باتری خاموش، موتور متوقف. موتور را روشن کنید، دور روتور را به ۱۰۰٪ برسانید، بلند شوید، مسیر را بروید و روی پد براوو بنشینید."};
        l = new ArrayList<>();
        hueyStart(l);
        l.add(st(F_TAKEOFF, 0, 0, 0, 0, "Raise collective slowly - lift off to a 3-5 m hover", "کلکتیو را آرام بالا ببرید - بلند شوید و در ارتفاع ۳ تا ۵ متر هاور کنید",
                "Hover needs about 55-58 % collective. Add a little left pedal as power rises.", "هاور حدود ۵۵ تا ۵۸٪ کلکتیو می‌خواهد. با بالا رفتن قدرت کمی پدال چپ بدهید."));
        l.add(st(F_HOVER, 0, 5, 0, 0, "Hover check for 5 seconds (torque, rotor 100 %)", "۵ ثانیه هاور: گشتاور و دور روتور ۱۰۰٪ را چک کنید",
                "Keep the nose steady. Torque for a hover is about 30 psi.", "دماغه را ثابت نگه دارید. گشتاور هاور حدود ۳۰ psi است."));
        l.add(st(F_CLIMB, 0, 50, 20, 0, "Accelerate (forward cyclic) and climb above 50 m", "با سیکلیک جلو شتاب بگیرید و بالای ۵۰ متر صعود کنید",
                "Push the cyclic forward gently; the nose drops and speed builds. Keep rotor at 100 %.", "سیکلیک را آرام جلو ببرید؛ دماغه پایین می‌آید و سرعت زیاد می‌شود. دور روتور ۱۰۰٪ بماند."));
        l.add(st(F_REACH, 1, 5800, 1, 0, "Cruise east to Firebase Bravo (6.8 km)", "به سمت شرق، تا فایربیس براوو (۶٫۸ کیلومتر) پرواز کنید",
                "Cruise 80-100 kt. Never exceed 124 kt (Vne). Hills at 2.6 km and 4.5 km.", "سرعت کروز ۸۰ تا ۱۰۰ نات. هرگز از ۱۲۴ نات (Vne) بیشتر نشوید. تپه‌ها در ۲٫۶ و ۴٫۵ کیلومتری."));
        l.add(st(F_NEAR, 1, 250, 25, 60, "Approach: slow below 25 kt, descend to the pad", "نزدیک شدن: سرعت زیر ۲۵ نات، فرود به سمت پد",
                "Flare by pulling the cyclic back. Lower the collective to keep a steady descent.", "با کشیدن سیکلیک به عقب فلر کنید. کلکتیو را پایین بیاورید تا نزول یکنواخت بماند."));
        l.add(st(F_LAND, 1, 0, 0, 0, "LAND on the pad: sink < 300 fpm, speed < 4 kt", "روی پد بنشینید: نرخ فرود < ۳۰۰ فوت/دقیقه، سرعت < ۴ نات",
                "Level the nose, arrest the sink rate with collective just before touchdown.", "دماغه را تراز کنید و درست قبل از تماس با کلکتیو نرخ فرود را بگیرید."));
        d1.steps = l.toArray(new Step[0]);
        d1.landPad = 1;
        defs.add(d1);

        // 2. Medevac (UH-1H, valley, engines running)
        Def d2 = base(1, "Medevac", "امداد پزشکی", Aircraft.HUEY, Terrain.VALLEY, false, 0, 22, 3.5, 700, 100);
        d2.bonusMode = 1; d2.timeTarget = 420;
        d2.weatherEn = "Wind 270 at 7 kt, OAT 22 C. Fuel 700 lb. Engine running. Time counts!";
        d2.weatherFa = "باد ۲۷۰ با ۷ نات، دمای هوا ۲۲ درجه. سوخت ۷۰۰ پوند. موتور روشن است. زمان مهم است!";
        d2.briefEn = new String[]{"A casualty waits at LZ Delta, 3.3 km east of Base Alpha. Fly there, land, load the patient and return to the Base Alpha pad where the ambulance is waiting.",
                "You start with the engine running and the rotor at 100 %. Target time: 7 minutes. Landing gently matters for the patient."};
        d2.briefFa = new String[]{"یک مجروح در LZ دلتا، ۳٫۳ کیلومتر شرق بیس آلفا منتظر است. به آنجا پرواز کنید، بنشینید، مجروح را سوار کنید و به پد بیس آلفا برگردید که آمبولانس آنجاست.",
                "با موتور روشن و دور روتور ۱۰۰٪ شروع می‌کنید. زمان هدف: ۷ دقیقه. فرود نرم برای مجروح مهم است."};
        l = new ArrayList<>();
        l.add(st(F_TAKEOFF, 0, 0, 0, 0, "Take off from Base Alpha", "از بیس آلفا بلند شوید", "Collective up to about 57 %, a little left pedal.", "کلکتیو تا حدود ۵۷٪، کمی پدال چپ."));
        l.add(st(F_CLIMB, 0, 30, 25, 0, "Climb above 30 m and head east", "بالای ۳۰ متر صعود کنید و به شرق بروید", "Ridge at 2.6 km (+80 m): climb to clear it.", "خط‌الرأس در ۲٫۶ کیلومتری (+۸۰ متر): برای عبور بالا بروید."));
        l.add(st(F_NEAR, 2, 300, 25, 60, "Approach LZ Delta: slow down", "نزدیک شدن به LZ دلتا: سرعت را کم کنید", "The LZ is a flat patch between the two ridges.", "LZ یک محوطهٔ هموار بین دو خط‌الرأس است."));
        l.add(st(F_LAND_WAIT, 2, 10, 85, 0, "LAND at LZ Delta and wait while the patient is loaded", "در LZ دلتا بنشینید و تا سوار شدن مجروح صبر کنید", "Stay down about 10 seconds with the rotor turning.", "حدود ۱۰ ثانیه با روتور در حال چرخش روی زمین بمانید."));
        l.add(st(F_TAKEOFF, 2, 0, 0, 0, "Take off with the patient (heavier now)", "با مجروح بلند شوید (حالا سنگین‌تر)", "The aircraft is heavier: more collective is needed.", "هلیکوپتر سنگین‌تر شده: کلکتیو بیشتری لازم است."));
        l.add(st(F_CLIMB, 0, 40, 25, 0, "Climb above 40 m and turn west with the pedals", "بالای ۴۰ متر صعود کنید و با پدال‌ها به غرب بپیچید", "Use the pedals to turn to 270, then fly back to Base Alpha.", "با پدال‌ها به ۲۷۰ بچرخید و به بیس آلفا برگردید."));
        l.add(st(F_NEAR, 0, 250, 25, 60, "Approach Base Alpha", "نزدیک شدن به بیس آلفا", "Slow down and descend towards the pad.", "سرعت را کم کنید و به سمت پد پایین بیایید."));
        l.add(st(F_LAND, 0, 0, 0, 0, "LAND gently on the pad", "نرم روی پد بنشینید", "Sink under 300 ft/min.", "نرخ فرود زیر ۳۰۰ فوت/دقیقه."));
        d2.steps = l.toArray(new Step[0]);
        d2.landPad = 0;
        defs.add(d2);

        // 3. Hot and high resupply (UH-1H, mountains, cold start)
        Def d3 = base(2, "Hot & High Resupply", "تأمین‌رسانی در ارتفاع بالا", Aircraft.HUEY, Terrain.MOUNTAIN, true, 0, 14, 2.5, 640, 350);
        d3.weatherEn = "Valley base at 1,400 m, ridge camp at 1,950 m. Thin air: less lift and less power. Wind 270 at 5 kt, OAT 14 C. Cargo 350 kg.";
        d3.weatherFa = "بیس دره در ۱٬۴۰۰ متر، کمپ خط‌الرأس در ۱٬۹۵۰ متر. هوای رقیق: لیفت و قدرت کمتر. باد ۲۷۰ با ۵ نات، دمای ۱۴ درجه. بار ۳۵۰ کیلوگرم.";
        d3.briefEn = new String[]{"Deliver 350 kg of supplies to Ridge Camp, 4.2 km east at 1,950 m. In thin air the UH-1H has little power to spare.",
                "Start cold. Watch torque and rotor rpm: never exceed 50 psi, never let the rotor fall below 91 %. Use translational lift for the climb and land gently."};
        d3.briefFa = new String[]{"۳۵۰ کیلوگرم تدارکات را به کمپ خط‌الرأس، ۴٫۲ کیلومتر شرق در ارتفاع ۱٬۹۵۰ متر برسانید. در هوای رقیق UH-1H قدرت اضافی کمی دارد.",
                "سرد شروع کنید. گشتاور و دور روتور را ببینید: هرگز از ۵۰ psi بالاتر نروید و دور روتور زیر ۹۱٪ نیاید. برای صعود از لیفت انتقالی استفاده کنید و نرم بنشینید."};
        l = new ArrayList<>();
        hueyStart(l);
        l.add(st(F_TAKEOFF, 0, 0, 0, 0, "Lift off to a hover - the air is thin, collective is higher", "بلند شوید و هاور کنید - هوا رقیق است، کلکتیو بیشتر لازم است", "Expect about 65-70 % collective and a torque near 40 psi.", "حدود ۶۵ تا ۷۰٪ کلکتیو و گشتاور نزدیک ۴۰ psi انتظار داشته باشید."));
        l.add(st(F_CLIMB, 0, 60, 20, 0, "Accelerate and climb above 60 m", "شتاب بگیرید و بالای ۶۰ متر صعود کنید", "Do not stay in a hover: forward speed lowers the power needed.", "در هاور نمانید: سرعت جلو توان لازم را کم می‌کند."));
        l.add(st(F_REACH, 1, 3200, 1, 0, "Follow the valley up towards Ridge Camp", "دره را تا نزدیک کمپ خط‌الرأس بالا بروید", "The ground rises 550 m over 3.9 km. Climb with it.", "زمین در ۳٫۹ کیلومتر ۵۵۰ متر بالا می‌رود. همراه آن بالا بروید."));
        l.add(st(F_NEAR, 1, 250, 25, 60, "Approach Ridge Camp: slow down and descend", "نزدیک شدن به کمپ خط‌الرأس: کند شوید و پایین بیایید", "Keep the rotor above 95 % in the flare.", "در فلر دور روتور بالای ۹۵٪ بماند."));
        l.add(st(F_LAND, 1, 0, 0, 0, "LAND on the camp pad", "روی پد کمپ بنشینید", "Sink under 300 ft/min, speed under 4 kt.", "نرخ فرود زیر ۳۰۰ فوت/دقیقه، سرعت زیر ۴ نات."));
        d3.steps = l.toArray(new Step[0]);
        d3.landPad = 1;
        defs.add(d3);

        // 4. Autorotation drill (UH-1H, valley)
        Def d4 = base(3, "Autorotation Drill", "تمرین اتوروتیشن", Aircraft.HUEY, Terrain.VALLEY, false, -1800, 22, 3.5, 500, 100);
        d4.airborne = true; d4.airAgl = 220; d4.airSpeed = 36; d4.failX = -1200; d4.failEng = 0; d4.procMode = 2; d4.ignoreLowRpm = true; d4.landTol = 160; d4.timeTarget = 300;
        d4.weatherEn = "Wind 270 at 7 kt, OAT 22 C. You start in cruise at 220 m, 70 kt. The engine will fail near the base.";
        d4.weatherFa = "باد ۲۷۰ با ۷ نات، دمای ۲۲ درجه. در کروز ۲۲۰ متری با ۷۰ نات شروع می‌کنید. موتور نزدیک بیس خاموش می‌شود.";
        d4.briefEn = new String[]{"Emergency training. The engine will fail on the way to Base Alpha. Lower the collective at once, keep the rotor between 91 and 100 %, glide at 60-70 kt and flare to touch down near the pad.",
                "Success: touch down within 160 m of the pad, soft and slow. Points are lost for low rotor speed."};
        d4.briefFa = new String[]{"تمرین اضطراری. موتور در مسیر بیس آلفا خاموش می‌شود. فوراً کلکتیو را پایین بیاورید، دور روتور را بین ۹۱ و ۱۰۰٪ نگه دارید، با ۶۰ تا ۷۰ نات سر بخورید و فلر کنید تا نزدیک پد بنشینید.",
                "موفقیت: نشستن در ۱۶۰ متری پد، نرم و آرام. با دور روتور پایین امتیاز کم می‌شود."};
        l = new ArrayList<>();
        l.add(st(F_FAIL, 0, 0, 0, 0, "Fly east to Base Alpha - the engine will fail", "به شرق، به سمت بیس آلفا پرواز کنید - موتور خاموش می‌شود", "Hold 70 kt and 220 m. Be ready.", "سرعت ۷۰ نات و ارتفاع ۲۲۰ متر را نگه دارید. آماده باشید."));
        l.add(st(F_AUTOLAND, 0, 160, 0, 0, "ENGINE FAILURE! Lower the collective, autorotate and land near the pad", "خرابی موتور! کلکتیو را پایین بیاورید، اتوروتیشن کنید و نزدیک پد بنشینید",
                "Collective down within 1 s, rotor 91-100 %. Flare at 15-35 m, level and cushion with the collective.", "کلکتیو در ۱ ثانیه پایین، دور روتور ۹۱ تا ۱۰۰٪. در ۱۵ تا ۳۵ متری فلر، تراز و با کلکتیو نرم کنید."));
        d4.steps = l.toArray(new Step[0]);
        d4.landPad = 0;
        defs.add(d4);

        // 5. Sea King familiarisation (twin engine, coast, cold start)
        Def d5 = base(4, "Sea King Familiarisation", "آشنایی با Sea King", Aircraft.SEAKING, Terrain.COAST, true, 0, 16, 4.0, 3000, 300);
        d5.weatherEn = "Coast. Wind 270 at 8 kt, OAT 16 C. Fuel 3,000 lb. Land on the deck of HMS Defender, 5.2 km east at sea.";
        d5.weatherFa = "ساحل. باد ۲۷۰ با ۸ نات، دمای ۱۶ درجه. سوخت ۳٬۰۰۰ پوند. روی عرشهٔ ناو HMS Defender، ۵٫۲ کیلومتر شرق روی دریا بنشینید.";
        d5.briefEn = new String[]{"The Sea King is a twin-engine, five-blade, amphibious helicopter with retractable landing gear. Start both engines, take off, retract the gear and fly out to the frigate HMS Defender.",
                "Lower the gear again before landing on the small deck. A gear-up landing on land is a crash; a water landing needs the gear UP."};
        d5.briefFa = new String[]{"Sea King یک هلیکوپتر دوموتوره، پنج‌پره و آبی‌خاکی با ارابهٔ فرود جمع‌شو است. هر دو موتور را روشن کنید، بلند شوید، ارابه را جمع کنید و به سمت ناوچهٔ HMS Defender پرواز کنید.",
                "پیش از فرود روی عرشهٔ کوچک ارابه را دوباره پایین بیاورید. فرود با ارابهٔ جمع روی خشکی سقوط است؛ فرود روی آب ارابهٔ جمع لازم دارد."};
        l = new ArrayList<>();
        seaKingStart(l);
        l.add(st(F_TAKEOFF, 0, 0, 0, 0, "Raise collective - lift off to a hover", "کلکتیو را بالا ببرید - بلند شوید و هاور کنید", "Hover needs about 55 % collective; torque about 55 % each engine.", "هاور حدود ۵۵٪ کلکتیو می‌خواهد؛ گشتاور هر موتور حدود ۵۵٪."));
        l.add(st(F_GEARUP, 0, 0, 0, 0, "Gear UP (GEAR DN switch off) once airborne", "ارابه را جمع کنید (کلید GEAR DN را خاموش کنید) بعد از بلند شدن", "The wheels take about 8 seconds to retract. Drag drops by about 14 %.", "جمع شدن چرخ‌ها حدود ۸ ثانیه طول می‌کشد. پسا حدود ۱۴٪ کم می‌شود."));
        l.add(st(F_CLIMB, 0, 50, 25, 0, "Accelerate and climb above 50 m", "شتاب بگیرید و بالای ۵۰ متر صعود کنید", "Cruise 80-100 kt. Vne is 112 kt.", "کروز ۸۰ تا ۱۰۰ نات. Vne برابر ۱۱۲ نات است."));
        l.add(st(F_REACH, 2, 3700, 1, 0, "Fly east out over the sea towards HMS Defender", "به شرق، روی دریا به سمت HMS Defender پرواز کنید", "The cliff is at 2.3 km. The ship is at 5.2 km.", "صخره در ۲٫۳ کیلومتری است. ناو در ۵٫۲ کیلومتری است."));
        l.add(st(F_GEARDN, 0, 0, 0, 0, "Gear DOWN for the deck landing", "ارابه را برای فرود روی عرشه پایین بیاورید", "Switch GEAR DN on. Wait for the wheels to extend.", "کلید GEAR DN را روشن کنید. تا باز شدن چرخ‌ها صبر کنید."));
        l.add(st(F_NEAR, 2, 250, 25, 60, "Approach the ship: slow below 25 kt", "نزدیک شدن به ناو: سرعت زیر ۲۵ نات", "The deck is small: aim carefully.", "عرشه کوچک است: دقیق هدف بگیرید."));
        l.add(st(F_LAND, 2, 0, 0, 0, "LAND on the deck", "روی عرشه بنشینید", "Sink under 300 ft/min; the deck is 26 m wide.", "نرخ فرود زیر ۳۰۰ فوت/دقیقه؛ عرشه ۲۶ متر عرض دارد."));
        d5.steps = l.toArray(new Step[0]);
        d5.landPad = 2;
        defs.add(d5);

        // 6. Search and rescue (Sea King, coast, engines running)
        Def d6 = base(5, "Search and Rescue", "جست‌وجو و نجات", Aircraft.SEAKING, Terrain.COAST, false, 0, 16, 4.0, 2600, 250);
        d6.bonusMode = 1; d6.timeTarget = 500; d6.raftX = 6900;
        d6.weatherEn = "Coast. Wind 270 at 8 kt, OAT 16 C. Survivor in a raft at 6.9 km. Winch hoist, then the hospital pad (1.0 km).";
        d6.weatherFa = "ساحل. باد ۲۷۰ با ۸ نات، دمای ۱۶ درجه. نجات‌یافته در قایق پنوماتیک در ۶٫۹ کیلومتری. بالابر وینچ، سپس پد بیمارستان (۱ کیلومتر).";
        d6.briefEn = new String[]{"A survivor floats in a life raft 6.9 km offshore. Fly out, hover 12-45 m above the raft, lower the winch, hook the survivor and raise the winch. Then return to the hospital pad.",
                "Hold the hover steady: the survivor is only attached while you stay within 10 m of the raft. Use the LOWER / STOP / RAISE winch buttons in the outside view."};
        d6.briefFa = new String[]{"یک نجات‌یافته در قایق پنوماتیک ۶٫۹ کیلومتر دور از ساحل شناور است. پرواز کنید، ۱۲ تا ۴۵ متر بالای قایق هاور کنید، وینچ را پایین بیاورید، نجات‌یافته را وصل و وینچ را بالا بکشید. بعد به پد بیمارستان برگردید.",
                "هاور را ثابت نگه دارید: نجات‌یافته فقط وقتی وصل می‌شود که در ۱۰ متری قایق بمانید. از دکمه‌های LOWER / STOP / RAISE وینچ در صفحهٔ بیرون استفاده کنید."};
        l = new ArrayList<>();
        l.add(st(F_TAKEOFF, 0, 0, 0, 0, "Take off from the base", "از بیس بلند شوید", "Engines are running. Collective to about 55-57 %.", "موتورها روشن‌اند. کلکتیو تا حدود ۵۵ تا ۵۷٪."));
        l.add(st(F_GEARUP, 0, 0, 0, 0, "Gear UP", "ارابه را جمع کنید", "GEAR DN switch off.", "کلید GEAR DN را خاموش کنید."));
        l.add(st(F_CLIMB, 0, 40, 25, 0, "Accelerate and climb above 40 m", "شتاب بگیرید و بالای ۴۰ متر صعود کنید", "Head east, out over the sea.", "به شرق بروید، روی دریا."));
        l.add(st(F_REACH, 0, 5800, 1, 0, "Fly 5.8 km east to the raft area", "۵٫۸ کیلومتر به شرق تا منطقهٔ قایق پرواز کنید", "The raft is at 6.9 km; look for the orange raft.", "قایق در ۶٫۹ کیلومتری است؛ قایق نارنجی را پیدا کنید."));
        l.add(st(F_HOIST_POS, 0, 0, 0, 0, "Hover 12-45 m above the raft (hold 4 s)", "۱۲ تا ۴۵ متر بالای قایق هاور کنید (۴ ثانیه)", "Slow to a stop over the raft. Small cyclic inputs.", "روی قایق متوقف شوید. سیکلیک را کم و کوچک حرکت دهید."));
        l.add(st(F_HOIST_LOWER, 0, 0, 0, 0, "LOWER the winch to the water", "وینچ را تا آب پایین بیاورید", "Press LOWER; the hook descends 1.5 m/s. Keep the hover.", "LOWER را بزنید؛ قلاب با ۱٫۵ متر بر ثانیه پایین می‌رود. هاور را نگه دارید."));
        l.add(st(F_HOIST_LOAD, 0, 0, 0, 0, "Hold the hover while the survivor is hooked (4 s)", "هاور را نگه دارید تا نجات‌یافته وصل شود (۴ ثانیه)", "Stay within 10 m of the raft.", "در ۱۰ متری قایق بمانید."));
        l.add(st(F_HOIST_RAISE, 0, 0, 0, 0, "RAISE the winch - survivor aboard", "وینچ را بالا بکشید - نجات‌یافته سوار شود", "Press RAISE; keep the hover until the cable is stowed.", "RAISE را بزنید؛ تا جمع شدن کابل هاور را نگه دارید."));
        l.add(st(F_REACH, 1, 3000, -1, 0, "Turn west with the pedals and fly back to the coast", "با پدال‌ها به غرب بپیچید و به ساحل برگردید", "Pedals turn the nose: aim for heading 270.", "پدال‌ها دماغه را می‌چرخانند: هدینگ ۲۷۰."));
        l.add(st(F_GEARDN, 0, 0, 0, 0, "Gear DOWN for the pad landing", "ارابه را برای فرود روی پد پایین بیاورید", "GEAR DN switch on.", "کلید GEAR DN را روشن کنید."));
        l.add(st(F_NEAR, 1, 250, 25, 60, "Approach the hospital pad", "نزدیک شدن به پد بیمارستان", "Slow below 25 kt.", "سرعت زیر ۲۵ نات."));
        l.add(st(F_LAND, 1, 0, 0, 0, "LAND on the hospital pad", "روی پد بیمارستان بنشینید", "Gentle touchdown for the patient.", "فرود نرم برای مجروح."));
        d6.steps = l.toArray(new Step[0]);
        d6.landPad = 1;
        defs.add(d6);

        // 7. Single-engine emergency (Sea King, coast, airborne)
        Def d7 = base(6, "Single-Engine Emergency", "اضطراری تک‌موتوره", Aircraft.SEAKING, Terrain.COAST, false, 0, 16, 4.0, 1800, 300);
        d7.airborne = true; d7.airAgl = 110; d7.airSpeed = 40; d7.failX = 1000; d7.failEng = 1; d7.procMode = 2; d7.ignoreLowRpm = true; d7.landTol = 170;
        d7.weatherEn = "Coast. Wind 270 at 8 kt, OAT 16 C. In cruise at 110 m, 78 kt. Fuel 1,800 lb. Engine 2 will fail.";
        d7.weatherFa = "ساحل. باد ۲۷۰ با ۸ نات، دمای ۱۶ درجه. در کروز ۱۱۰ متری با ۷۸ نات. سوخت ۱٬۸۰۰ پوند. موتور ۲ خاموش می‌شود.";
        d7.briefEn = new String[]{"Engine 2 will fail on the way to the airfield. A fully loaded Sea King cannot hover on one engine, so make a running landing: keep the rotor at 100 %, reduce power, fly to the airfield and land on the runway at 20-40 kt.",
                "Watch the torque of the good engine: the limit is 100 %. Success: stop on the airfield (the runway is 340 m long)."};
        d7.briefFa = new String[]{"موتور ۲ در مسیر فرودگاه خاموش می‌شود. Sea King پرسنگین با یک موتور نمی‌تواند هاور کند، پس فرود با سرعت انجام دهید: دور روتور ۱۰۰٪ بماند، قدرت را کم کنید، به فرودگاه بروید و روی باند با ۲۰ تا ۴۰ نات بنشینید.",
                "گشتاور موتور سالم را ببینید: حد آن ۱۰۰٪ است. موفقیت: توقف روی فرودگاه (طول باند ۳۴۰ متر)."};
        l = new ArrayList<>();
        l.add(st(F_FAIL, 0, 0, 0, 0, "Fly east to the airfield - an engine will fail", "به شرق به سمت فرودگاه پرواز کنید - یک موتور خاموش می‌شود", "Hold 78 kt, 110 m.", "سرعت ۷۸ نات و ارتفاع ۱۱۰ متر."));
        l.add(st(F_NEAR, 3, 500, 40, 80, "ENGINE 2 FAILED: reduce power, keep 100 % rotor, fly to the airfield", "موتور ۲ خاموش شد: قدرت را کم کنید، دور روتور ۱۰۰٪، به فرودگاه بروید",
                "Lower the collective a little. Do not hover: keep 40-60 kt for translational lift.", "کلکتیو را کمی پایین بیاورید. هاور نکنید: ۴۰ تا ۶۰ نات برای لیفت انتقالی."));
        l.add(st(F_GEARDN, 0, 0, 0, 0, "Gear DOWN for the landing", "ارابه را برای فرود پایین بیاورید", "The gear extends in 8 s: do it early.", "ارابه در ۸ ثانیه باز می‌شود: زود انجامش بدهید."));
        l.add(st(F_LAND, 3, 0, 0, 0, "Running landing: touch down on the airfield and stop", "فرود با سرعت: روی فرودگاه بنشینید و توقف کنید", "Touch down at 20-30 kt, lower the collective fully; the wheel brakes work with the collective down.", "با ۲۰ تا ۳۰ نات بنشینید، کلکتیو را کامل پایین بیاورید؛ ترمز چرخ‌ها با کلکتیو پایین کار می‌کنند."));
        d7.steps = l.toArray(new Step[0]);
        d7.landPad = 3;
        defs.add(d7);

        return defs.toArray(new Def[0]);
    }
}
