# Helicopter Simulator (UH-1H Huey + Sea King) - Operating Manual

## 1. Welcome

UH-1H Huey Simulator is a 2-D side-view simulator of the Bell UH-1H Iroquois. The world is a vertical slice that runs east-west: you watch the helicopter from the side, while a full physical model runs underneath.

- Rotor thrust, induced / profile / parasite power, ground effect, translational lift and autorotation are calculated from momentum theory.

- The engine (Lycoming T53-L-13 type) has a gas producer (N1), power turbine (N2), EGT, torque, a governor and a real start sequence.

- Electrical bus, battery, generator, inverter, hydraulics, fuel, oil temperatures and pressures all exist and every caution light works.

Mission 1 teaches the complete procedure: cold start, take-off, a 6.8 km delivery flight east to Firebase Bravo, and landing.

Keep the COACH ON until you know the checklist. It always shows the next step and a hint.

## 2. Controls

- COLLECTIVE (far-left lever): rotor blade pitch. Up = climb, down = descend. Hover needs about 55-58 %.

- THROTTLE (twist grip, next to the collective): 0 = closed (fuel cut-off), 6-25 % = IDLE detent, 100 % = FULL OPEN. With GOV AUTO the governor holds rotor speed once the throttle is open.

- CYCLIC (far-right lever): forward tilts the rotor disc and the helicopter accelerates; aft slows it down. Double-tap the lever to centre it. With FORCE TRIM off the lever springs back to centre.

- PEDALS (LEFT / RIGHT buttons under the outside view): turn the helicopter. Heading changes the direction of travel; at 000/180 you face the camera and cannot move east-west.

- Torque reaction: more power pushes the nose to the right. Add LEFT pedal when you raise the collective.

- STARTER: press and hold. Switches: tap to toggle. The top bar has MENU, MANUAL and COACH.

## 3. Flight instruments

- AIRSPEED: knots. Green 40-100, yellow 100-124, red line 124 kt (Vne, never exceed).

- ATTITUDE: pitch attitude (2-D flight has no roll). Needs the INVERTER; otherwise it shows OFF.

- ALTITUDE: three-hand style: long hand = hundreds of feet, short hand = thousands. Base Alpha is 1017 ft, Firebase Bravo 860 ft MSL.

- VERTICAL SPEED: +-3000 ft/min with the usual lag of about 1.5 s.

- HEADING (RMI): rotating compass card; the cyan pointer shows the bearing to Firebase Bravo and the box shows the distance in nautical miles. Needs the INVERTER.

- TURN: needle shows yaw rate (marks = standard 3 deg/s). The ball shows slip caused by torque / pedals.

- RAD ALT: height above ground in feet (needs power). Yellow bug at 50 ft.

- CLOCK: mission time starting at 08:00.

## 4. Engine and system instruments

- TORQUE (psi): green up to 48, limit 50. Above 50 for more than 4 s damages the transmission (XMSN CHIP).

- TACH: white needle = rotor Nr, orange needle = engine N2. Operating range 91-100.5 % (294-324 rpm). Above 104.6 % is red.

- N1 (gas producer %): ground idle 63-66 %. Above 100 % is red.

- EGT (deg C): continuous limit 610, start limit 780. Above 780 for a moment = hot start, engine damaged (power reduced).

- FUEL: quantity in lb x100 plus fuel pressure (small needle). The 20 MIN FUEL light comes on at 150 lb.

- ENG OIL and XMSN OIL: pressure (left scale, white needle) and temperature (right scale, orange needle). Oil temperatures rise slowly; do not fly at full power with cold oil.

- DC: volts (left) and amps (right). Battery about 24 V; generator 28 V. During start the battery sags.

## 5. Caution panel

- ENG OIL PRESS / XMSN OIL PRESS: pressure low. XMSN OIL HOT: transmission oil above 110 C.

- ENG CHIP / XMSN CHIP: metal in the oil. Engine damaged / transmission over-torqued.

- 20 MIN FUEL: about 20 minutes of fuel left. Plan to land.

- DC GEN: generator not supplying power. INVERTER: inverter off. HYD PRESS: hydraulics off or low - controls are heavy.

- GOV EMER: governor in manual mode - you must set the rotor speed with the throttle.

- LOW RPM (with horn): rotor below 97 %. Lower the collective at once.

- ENGINE OUT: engine stopped in flight - autorotate. EGT HIGH: above 640 C. ROTOR HIGH: above 104 %.

## 6. Cold start checklist

1. BATT ON. 2. MAIN FUEL ON, START FUEL ON. 3. INVERTER ON. 4. Throttle fully CLOSED.

5. Press and HOLD STARTER. N1 rises (battery voltage drops - normal).

6. At N1 15 % roll the throttle to the IDLE detent (about 15 %). Light-off: EGT rises to about 550 C. If you open the throttle too early (N1 below about 10 %) EGT overshoots 780 C = hot start.

7. Keep holding STARTER until N1 reaches 40 %, then release. N1 settles at about 64 %.

8. START FUEL OFF. 9. GEN ON (volts 28, DC GEN light off). 10. HYD CONT ON.

11. Roll the throttle FULL OPEN. Rotor Nr rises to 100 %. Keep the collective DOWN.

12. Check: oil pressures green, EGT below 610, no caution lights. Then you are ready.

## 7. Take-off and hover

- Raise the collective slowly. At about 55 % the skids get light; at 57-58 % the helicopter lifts off.

- Add left pedal as power rises to hold the heading. Use small cyclic corrections: the hover is slightly unstable.

- Hover at 3-5 m for a moment. Torque for a hover is about 30 psi. Rotor must stay at 100 %.

- Ground effect: near the ground the rotor needs less power; just above it you may need more collective as you climb out.

- To depart: push the cyclic forward gently. The nose drops, the speed builds and translational lift improves the climb. Keep the rotor at 100 % and climb through 50 m.

## 8. Cruise and navigation

- Cruise at 80-100 kt. Never exceed 124 kt (Vne). Hold the altitude with the collective, the speed with the cyclic.

- Firebase Bravo is 6.8 km east of Base Alpha. Kilometre signs stand along the route. The heading card pointer and distance box show the way.

- Terrain: ridges at 2.6 km (+80 m) and 4.5 km (+55 m). Stay at least 50 m above the ground.

- Wind: about 7 kt from the west (the wind sock at the pads shows it). Gusts shake the aircraft.

- Fuel: about 560 lb per hour at cruise. You start with 780 lb.

## 9. Approach and landing

- Start slowing about 1 km before Bravo. Pull the cyclic back to reduce speed; lower the collective to keep a steady descent.

- Aim for the pad (+-18 m). Final approach at 30-40 kt, sink 300-500 ft/min.

- Flare at 10-15 m: nose up to kill the forward speed, then level the nose and cushion the touchdown with the collective.

- Successful landing: on the pad, sink rate below 300 ft/min (1.5 m/s), ground speed below 4 kt, stay down 3 seconds.

- Hard landing above 2.6 m/s sink (or 23 kt ground speed). Crash above 4.8 m/s sink, 43 kt ground speed, nose-up above 18 deg (tail strike), or hitting a hillside.

- Score: start-up 30, flight 30, landing 30, fuel 10 = 100.

## 10. Shutdown (practice)

1. Collective DOWN, throttle to IDLE.

2. Let the engine cool for two minutes (EGT and oil temperatures fall).

3. GEN OFF, INVERTER OFF, HYD OFF.

4. Throttle CLOSED (fuel cut-off). The rotor and N1 spin down slowly.

5. MAIN FUEL OFF, BATT OFF.

## 11. Emergencies

- ENGINE FAILURE: lower the collective immediately (within 1 s). Keep the rotor at 91-100 %. Glide at 60 kt (descent about 1500-1700 ft/min). Flare at 15-25 m and cushion with the collective.

- LOW RPM: lower the collective, check the throttle is full open and GOV is AUTO.

- GOVERNOR FAILURE (GOV EMER): hold rotor speed with the twist grip; move it slowly.

- HOT START: if EGT goes above 780, close the throttle at once. The engine may be damaged.

- HYDRAULIC FAILURE: the controls get heavy and less precise; land as soon as practical.

- OVER-TORQUE: reduce collective; do not stay above 50 psi.

- FUEL EXHAUSTED: the engine quits. Autorotate.

## 12. Aircraft data (UH-1H)

- Engine: Lycoming T53-L-13, 1,400 shp (derated to about 1,100 shp). Rotor: 2 blades, diameter 48 ft (14.6 m), 324 rpm.

- Weights: empty about 5,200 lb (2,365 kg); maximum gross 9,500 lb (4,310 kg). Fuel 1,300 lb (about 220 US gal).

- Speeds: Vne 124 kt; cruise about 100-110 kt. Service ceiling 12,600 ft. Length (fuselage) 12.8 m, height 4.4 m.

- Crew 2 + up to 11 troops. In this mission: crew 2 + 150 kg cargo.

- This simulator is an educational model. It is not a certified training device.

## 13. Sea King HAR.3 - overview

The Westland Sea King (Sikorsky S-61) is a twin-engine, five-blade, amphibious search-and-rescue helicopter. Two Rolls-Royce Gnome turboshafts (about 1,100 kW each) drive a 18.9 m rotor at 203 rpm.

- It weighs about 6.5 t empty and up to 9.5 t loaded. Hover needs about 55 % collective at 8 t.

- Retractable main wheels (GEAR DN switch, 8 seconds). Gear must be DOWN on land and UP on water. Gear-up on land = crash; gear down on water = capsize.

- The hull floats: with the gear up you can land on the sea. A UH-1H cannot - it sinks.

- Rescue winch: WINCH DOWN / WINCH UP buttons appear under the outside view. Cable length is shown.

- Instruments: two needles on torque, NG and TGT (white = engine 1, orange = engine 2). Engine oil shows both engines. Vne 112 kt.

- Panel switches: BATT, GEN 1, GEN 2, INVERTER, ENG1 FUEL, ENG2 FUEL, START FUEL, HYD CONT, GEAR DN, ANTI COL, NAV, LAND LT. Two start buttons: START 1 and START 2.

## 14. Sea King start-up

1. BATT ON, INVERTER ON. 2. Throttle (engine speed lever) at the IDLE detent, about 15 %.

3. Hold START 1. At N1 15 % switch ENG1 FUEL ON: light-off, EGT rises to about 550 C. Opening the fuel too early (N1 below about 10 %) is a hot start.

4. Keep holding START 1 to N1 40 %, release. N1 settles at about 64 %.

5. Repeat with START 2 and ENG2 FUEL for the second engine.

6. GEN 1 ON, GEN 2 ON (28 V). HYD CONT ON.

7. Throttle FULL OPEN: the five-blade rotor spools up slowly to 100 %. Keep the collective down.

8. Check both engines: torque about equal, oil pressures green, no cautions.

## 15. Sea King flight, gear and winch

- Take off at about 55-57 % collective. Raise the gear when safely airborne (the wheels need 8 s; drag falls 14 %).

- Cruise 80-100 kt; Vne is 112 kt. Fuel flow is about 1,000-1,200 lb per hour.

- Landing on a ship: gear DOWN, small deck (26 m), the deck is 9 m above the sea. The radar altimeter shows the sea, so judge the deck height by eye.

- Hoist (rescue): hover 12-45 m above the survivor. Press WINCH DOWN until the cable reaches the water. Hold the hover within 10 m for 4 seconds; the survivor is hooked. Press WINCH UP to raise.

- Water landing: gear UP, touch down gently (sink below 300 ft/min). The hull floats.

- Wheel brakes work automatically when the collective is below 15 %.

## 16. Single-engine emergency

- If one engine fails the other takes the full load: torque of the good engine rises towards 100 %. Do not exceed 100 %.

- Lower the collective a little to keep the rotor at 100 %. A heavy Sea King cannot hover on one engine.

- Fly forward at 40-60 kt: translational lift cuts the power needed. Plan a running landing on a runway at 20-30 kt, with the gear DOWN.

- After touch-down lower the collective fully; the wheel brakes stop the aircraft.

- Autorotation is also possible with both engines out: see page 11.

## 17. Missions

1. Delivery Flight (UH-1H, valley, cold start): Base Alpha to Firebase Bravo, 6.8 km.

2. Medevac (UH-1H, valley, engine running): land at LZ Delta, load a patient, return to Base Alpha. Time counts.

3. Hot & High Resupply (UH-1H, mountains, cold start): 350 kg cargo to Ridge Camp at 1,950 m in thin air.

4. Autorotation Drill (UH-1H): the engine fails at 220 m; land within 160 m of the pad.

5. Sea King Familiarisation (cold start, gear, sea): land on the ship HMS Defender.

6. Search and Rescue (Sea King): hoist a survivor from a raft, deliver him to the hospital pad. Time counts.

7. Single-Engine Emergency (Sea King): engine 2 fails; make a running landing on the airfield.

Scores: procedure / emergency handling 30, flight 30, landing 30, fuel or time 10.

# Missions

## 1. Delivery Flight - Bell UH-1H Iroquois

Fly the Huey from Base Alpha to Firebase Bravo, 6.8 km east, and deliver 150 kg of supplies.

You start cold and dark on the pad: battery off, engine stopped. Start the engine, bring the rotor to 100 %, take off, fly the route and land on the Bravo pad.

Wind 270 at 7 kt with gusts, OAT 22 C, clear. Fuel 780 lb. Hills at 2.6 km (+80 m) and 4.5 km (+55 m).

1. BATTERY switch ON

   Switch is on the left of the switch panel (tap it).

2. MAIN FUEL ON and START FUEL ON

   Both fuel switches are needed: MAIN opens the valve, START feeds the igniter fuel.

3. INVERTER ON

   The inverter powers the attitude indicator and RMI.

4. Throttle CLOSED (twist grip fully down)

   The throttle slider is next to the collective. 0 = closed (cut-off).

5. Hold START until N1 reaches 15 %

   Press and HOLD the STARTER button. Battery voltage will sag - that is normal.

6. Open throttle to IDLE (about 15 %) - watch EGT

   Open the throttle slightly when N1 is 15 %. Too early (below about 10 %) = HOT START (EGT above 780 C).

7. Hold START to N1 40 %, release, wait for N1 about 64 %

   Keep holding START until 40 %. If you let go sooner the engine stalls.

8. START FUEL OFF

   After the engine is self-sustaining the start fuel must be turned off.

9. GEN ON - bus 28 V

   The generator takes over from the battery. DC GEN light goes out.

10. HYD CONT ON

   Hydraulics make the controls light. Without them the controls are heavy.

11. Roll throttle FULL OPEN - rotor to 100 %

   Take your time. The governor holds 100 %. Do NOT raise the collective yet.

12. Check gauges: oil pressures green, no cautions

   Look for: ENG OIL 40-70 psi, XMSN OIL about 50 psi, EGT under 610 C, rotor 100 %.

13. Raise collective slowly - lift off to a 3-5 m hover

   Hover needs about 55-58 % collective. Add a little left pedal as power rises.

14. Hover check for 5 seconds (torque, rotor 100 %)

   Keep the nose steady. Torque for a hover is about 30 psi.

15. Accelerate (forward cyclic) and climb above 50 m

   Push the cyclic forward gently; the nose drops and speed builds. Keep rotor at 100 %.

16. Cruise east to Firebase Bravo (6.8 km)

   Cruise 80-100 kt. Never exceed 124 kt (Vne). Hills at 2.6 km and 4.5 km.

17. Approach: slow below 25 kt, descend to the pad

   Flare by pulling the cyclic back. Lower the collective to keep a steady descent.

18. LAND on the pad: sink < 300 fpm, speed < 4 kt

   Level the nose, arrest the sink rate with collective just before touchdown.

## 2. Medevac - Bell UH-1H Iroquois

A casualty waits at LZ Delta, 3.3 km east of Base Alpha. Fly there, land, load the patient and return to the Base Alpha pad where the ambulance is waiting.

You start with the engine running and the rotor at 100 %. Target time: 7 minutes. Landing gently matters for the patient.

Wind 270 at 7 kt, OAT 22 C. Fuel 700 lb. Engine running. Time counts!

1. Take off from Base Alpha

   Collective up to about 57 %, a little left pedal.

2. Climb above 30 m and head east

   Ridge at 2.6 km (+80 m): climb to clear it.

3. Approach LZ Delta: slow down

   The LZ is a flat patch between the two ridges.

4. LAND at LZ Delta and wait while the patient is loaded

   Stay down about 10 seconds with the rotor turning.

5. Take off with the patient (heavier now)

   The aircraft is heavier: more collective is needed.

6. Climb above 40 m and turn west with the pedals

   Use the pedals to turn to 270, then fly back to Base Alpha.

7. Approach Base Alpha

   Slow down and descend towards the pad.

8. LAND gently on the pad

   Sink under 300 ft/min.

## 3. Hot & High Resupply - Bell UH-1H Iroquois

Deliver 350 kg of supplies to Ridge Camp, 4.2 km east at 1,950 m. In thin air the UH-1H has little power to spare.

Start cold. Watch torque and rotor rpm: never exceed 50 psi, never let the rotor fall below 91 %. Use translational lift for the climb and land gently.

Valley base at 1,400 m, ridge camp at 1,950 m. Thin air: less lift and less power. Wind 270 at 5 kt, OAT 14 C. Cargo 350 kg.

1. BATTERY switch ON

   Switch is on the left of the switch panel (tap it).

2. MAIN FUEL ON and START FUEL ON

   Both fuel switches are needed: MAIN opens the valve, START feeds the igniter fuel.

3. INVERTER ON

   The inverter powers the attitude indicator and RMI.

4. Throttle CLOSED (twist grip fully down)

   The throttle slider is next to the collective. 0 = closed (cut-off).

5. Hold START until N1 reaches 15 %

   Press and HOLD the STARTER button. Battery voltage will sag - that is normal.

6. Open throttle to IDLE (about 15 %) - watch EGT

   Open the throttle slightly when N1 is 15 %. Too early (below about 10 %) = HOT START (EGT above 780 C).

7. Hold START to N1 40 %, release, wait for N1 about 64 %

   Keep holding START until 40 %. If you let go sooner the engine stalls.

8. START FUEL OFF

   After the engine is self-sustaining the start fuel must be turned off.

9. GEN ON - bus 28 V

   The generator takes over from the battery. DC GEN light goes out.

10. HYD CONT ON

   Hydraulics make the controls light. Without them the controls are heavy.

11. Roll throttle FULL OPEN - rotor to 100 %

   Take your time. The governor holds 100 %. Do NOT raise the collective yet.

12. Check gauges: oil pressures green, no cautions

   Look for: ENG OIL 40-70 psi, XMSN OIL about 50 psi, EGT under 610 C, rotor 100 %.

13. Lift off to a hover - the air is thin, collective is higher

   Expect about 65-70 % collective and a torque near 40 psi.

14. Accelerate and climb above 60 m

   Do not stay in a hover: forward speed lowers the power needed.

15. Follow the valley up towards Ridge Camp

   The ground rises 550 m over 3.9 km. Climb with it.

16. Approach Ridge Camp: slow down and descend

   Keep the rotor above 95 % in the flare.

17. LAND on the camp pad

   Sink under 300 ft/min, speed under 4 kt.

## 4. Autorotation Drill - Bell UH-1H Iroquois

Emergency training. The engine will fail on the way to Base Alpha. Lower the collective at once, keep the rotor between 91 and 100 %, glide at 60-70 kt and flare to touch down near the pad.

Success: touch down within 160 m of the pad, soft and slow. Points are lost for low rotor speed.

Wind 270 at 7 kt, OAT 22 C. You start in cruise at 220 m, 70 kt. The engine will fail near the base.

1. Fly east to Base Alpha - the engine will fail

   Hold 70 kt and 220 m. Be ready.

2. ENGINE FAILURE! Lower the collective, autorotate and land near the pad

   Collective down within 1 s, rotor 91-100 %. Flare at 15-35 m, level and cushion with the collective.

## 5. Sea King Familiarisation - Westland Sea King HAR.3

The Sea King is a twin-engine, five-blade, amphibious helicopter with retractable landing gear. Start both engines, take off, retract the gear and fly out to the frigate HMS Defender.

Lower the gear again before landing on the small deck. A gear-up landing on land is a crash; a water landing needs the gear UP.

Coast. Wind 270 at 8 kt, OAT 16 C. Fuel 3,000 lb. Land on the deck of HMS Defender, 5.2 km east at sea.

1. BATTERY ON

   Switch is on the left of the switch panel.

2. INVERTER ON

   The inverter powers the attitude indicator and RMI.

3. Throttle to the IDLE detent (about 15 %)

   On the Sea King the engine speed lever stays at GROUND IDLE while starting.

4. Hold START 1 until engine 1 N1 reaches 15 %

   The two start buttons are at the right of the switch panel. Do NOT open the fuel yet.

5. ENG1 FUEL ON at 15 % - light-off

   Opening the fuel cock too early (N1 below about 10 %) gives a HOT START.

6. Hold START 1 to 40 %, release; engine 1 N1 about 64 %

   Release at 40 %. EGT should peak near 550 C.

7. Hold START 2 until engine 2 N1 reaches 15 %

   Same procedure for the second engine.

8. ENG2 FUEL ON at 15 % - light-off

   Watch EGT of engine 2.

9. Hold START 2 to 40 %, release; engine 2 N1 about 64 %

   Both engines now at ground idle.

10. GEN 1 and GEN 2 ON

   Bus voltage rises to 28 V; GEN FAIL lights go out.

11. HYD CONT ON

   Hydraulics are needed for the controls.

12. Throttle FULL OPEN - rotor to 100 %

   Five blades spool up slowly. Keep the collective down.

13. Check gauges: both engines, oil, no cautions

   Torque of both engines should read about the same.

14. Raise collective - lift off to a hover

   Hover needs about 55 % collective; torque about 55 % each engine.

15. Gear UP (GEAR DN switch off) once airborne

   The wheels take about 8 seconds to retract. Drag drops by about 14 %.

16. Accelerate and climb above 50 m

   Cruise 80-100 kt. Vne is 112 kt.

17. Fly east out over the sea towards HMS Defender

   The cliff is at 2.3 km. The ship is at 5.2 km.

18. Gear DOWN for the deck landing

   Switch GEAR DN on. Wait for the wheels to extend.

19. Approach the ship: slow below 25 kt

   The deck is small: aim carefully.

20. LAND on the deck

   Sink under 300 ft/min; the deck is 26 m wide.

## 6. Search and Rescue - Westland Sea King HAR.3

A survivor floats in a life raft 6.9 km offshore. Fly out, hover 12-45 m above the raft, lower the winch, hook the survivor and raise the winch. Then return to the hospital pad.

Hold the hover steady: the survivor is only attached while you stay within 10 m of the raft. Use the LOWER / STOP / RAISE winch buttons in the outside view.

Coast. Wind 270 at 8 kt, OAT 16 C. Survivor in a raft at 6.9 km. Winch hoist, then the hospital pad (1.0 km).

1. Take off from the base

   Engines are running. Collective to about 55-57 %.

2. Gear UP

   GEAR DN switch off.

3. Accelerate and climb above 40 m

   Head east, out over the sea.

4. Fly 5.8 km east to the raft area

   The raft is at 6.9 km; look for the orange raft.

5. Hover 12-45 m above the raft (hold 4 s)

   Slow to a stop over the raft. Small cyclic inputs.

6. LOWER the winch to the water

   Press LOWER; the hook descends 1.5 m/s. Keep the hover.

7. Hold the hover while the survivor is hooked (4 s)

   Stay within 10 m of the raft.

8. RAISE the winch - survivor aboard

   Press RAISE; keep the hover until the cable is stowed.

9. Turn west with the pedals and fly back to the coast

   Pedals turn the nose: aim for heading 270.

10. Gear DOWN for the pad landing

   GEAR DN switch on.

11. Approach the hospital pad

   Slow below 25 kt.

12. LAND on the hospital pad

   Gentle touchdown for the patient.

## 7. Single-Engine Emergency - Westland Sea King HAR.3

Engine 2 will fail on the way to the airfield. A fully loaded Sea King cannot hover on one engine, so make a running landing: keep the rotor at 100 %, reduce power, fly to the airfield and land on the runway at 20-40 kt.

Watch the torque of the good engine: the limit is 100 %. Success: stop on the airfield (the runway is 340 m long).

Coast. Wind 270 at 8 kt, OAT 16 C. In cruise at 110 m, 78 kt. Fuel 1,800 lb. Engine 2 will fail.

1. Fly east to the airfield - an engine will fail

   Hold 78 kt, 110 m.

2. ENGINE 2 FAILED: reduce power, keep 100 % rotor, fly to the airfield

   Lower the collective a little. Do not hover: keep 40-60 kt for translational lift.

3. Gear DOWN for the landing

   The gear extends in 8 s: do it early.

4. Running landing: touch down on the airfield and stop

   Touch down at 20-30 kt, lower the collective fully; the wheel brakes work with the collective down.

