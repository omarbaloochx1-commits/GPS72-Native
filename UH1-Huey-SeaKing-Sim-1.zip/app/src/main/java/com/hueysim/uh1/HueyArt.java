package com.hueysim.uh1;

/** Anchor points (metres) of the supplied Huey side-view artwork. Origin: mast centre at skid level; nose = +x; up = -y.
 *  huey_body_r.png: starboard view (nose right, lettering re-drawn readable); huey_body_l.png: original port view (nose left). */
final class HueyArt {
    private HueyArt() { }
    static final String FILE_R = "huey_body_r.png", FILE_L = "huey_body_l.png";
    static final float HUB_X = 0.0000f;
    static final float HUB_Y = -3.8251f;
    static final float MAST_TOP_Y = -3.3333f;
    static final float TR_X = -7.8962f;
    static final float TR_Y = -3.5041f;
    static final float EXH_X = -2.5137f;
    static final float EXH_Y = -2.6161f;
    static final float BEACON_X = -1.9536f;
    static final float BEACON_Y = -3.0874f;
    static final float LAND_X = 3.8525f;
    static final float LAND_Y = -1.0246f;
    static final float NOSE_X = 4.6380f;
    static final float LEFT = -8.1489f;
    static final float RIGHT = 4.9249f;
    static final float TOP = -3.6749f;
    static final float BOTTOM = 0.0273f;
}
