# GPS 72 (native Android)
Garmin GPS 72 simulator using real GPS, real satellites (GnssStatus) and the phone's compass sensor.

Build APK: push to GitHub -> Actions tab -> "Build APK" -> download artifact GPS72-apk.

## Code layout
- `MainActivity` – device body, permissions, location / GNSS / compass wiring, file import/export
- `GpsView` – the 160x240 LCD: pages, menus, state
- `Geo` – distance, bearing, UTM, Maidenhead, sun and moon
- `LandData` – streaming GeoJSON parser for the offline land outline
- `Gpx` – GPX 1.1 export
- `KeypadView`, `NameKeyboard`, `TrackService` – keys, text entry, background tracking

## Changes in this version
- Heading uses GPS course above ~5 km/h and the compass below it
- Stale fixes are ignored; trip distance ignores jitter when accuracy is poor
- Altitude is mean sea level on Android 14+
- Satellite page lists only tracked satellites, used/strongest first
- Active GOTO survives app restarts; one corrupt waypoint no longer wipes the list
- LCD pixel grid, edge shading and glass glare; haptic key feedback and rocker arrows
- Export GPX (waypoints + saved tracks + active log): Tracks -> MENU -> Export GPX

## v3
- Map grid (lat/lon squares) with the equator and prime meridian emphasised; toggle: map page -> MENU -> Grid
- Waypoint editor: GOTO list -> MENU, or Main Menu -> Waypoints -> ENTER (Go To, Rename, Edit Position, Use Current Position, Delete with confirm)
- Waypoints are written at start-up, on resume and after every change to `<storage>/<app name>/waypoints/waypoints.gpx` (e.g. `/storage/emulated/0/GPS 72 12/waypoints/`); the app asks once for all-files access. Without that access it falls back to `Download/<app name>/waypoints/`
- Setup -> Gen -> Map: North Up (map fixed, marker turns) or Track Up (map turns)
- Arrival is decided by distance to the waypoint coordinates only (Setup -> Alarm -> Arrive Dist: 3/5/10/15/25 m), independent of map zoom
- Whole device scales to the screen height, no scrolling
- Tides: Main Menu -> Sun & Moon -> MENU. Estimated from the moon (no station database): set the local "HW after moon" interval and the mean range from a local tide table
- The device powers on automatically; BACK works like QUIT (closes menus), press BACK twice within 2 s on a main page to leave the app (tracking keeps running)
- Waypoints carry elevation, category, description and creation time (GPX wpt: ele/type/desc/time)
- Waypoint options: Go To, Rename, Edit, Use Current Position, Share via QR, Delete, Delete All (both with confirmation)
- Share via QR (single, several or all waypoints; multi-part QR when large) and Scan QR Code (Main Menu) with an import preview that skips duplicates
- Edit screen: MENU opens Name / Description / Category
- Build workflow unpacks the newest uploaded zip (uploaded via git) before building
- Map pan: centre key of the rocker toggles a cursor (small dot at screen centre joined to the position marker by a dashed line); arrows move the map (hold to repeat), the top line shows the cursor coordinates and the label beside the dot shows its distance from your position; press the centre key again to lock back on the marker
- The device is full-bleed (edge to edge, immersive mode) and its content scales to fit the screen height
- Device layout rewritten: keypad, LCD and brand share the full screen (LCD fills the width, keypad takes the remaining height); no scaling, no side/bottom gaps
- Land outline (Natural Earth 1:50m) is bundled in assets/land.json and installed automatically on first start (Options -> Clear Land File disables it, Load Land File replaces it)
- Key beeps are off by default (Setup -> Beeper: Message Only); the pan-cursor distance is also shown in miles
- Import waypoints from files: Waypoints -> options -> Import File (GPX or AlpineQuest .wpt, with a preview that skips duplicates); new .gpx/.wpt files dropped into the waypoints folder are imported automatically (once) at start and when the Waypoints list opens
- Keypad redesigned: larger buttons (about 30% bigger touch area), bigger rocker; the LCD keeps nearly the full width
