# GPS 72 (native Android)
Garmin GPS 72 simulator using real GPS, real satellites (GnssStatus) and the phone's compass sensor.

Build APK: push to GitHub -> Actions tab -> "Build APK" -> download artifact GPS72-apk.

## Code layout
- `MainActivity` – device body, permissions, location / GNSS / compass wiring, file import/export
- `GpsView` – the 160x240 LCD: pages, menus, state
- `Geo` – distance, bearing, UTM, Maidenhead, sun and moon
- `LandData` – streaming GeoJSON parser for the offline land outline
- `Gpx` – GPX 1.1 export
- `KeypadView`, `NameKeyboard`, `TrackService` – keys, text entry, background tracking

## Changes in this version
- Heading uses GPS course above ~5 km/h and the compass below it
- Stale fixes are ignored; trip distance ignores jitter when accuracy is poor
- Altitude is mean sea level on Android 14+
- Satellite page lists only tracked satellites, used/strongest first
- Active GOTO survives app restarts; one corrupt waypoint no longer wipes the list
- LCD pixel grid, edge shading and glass glare; haptic key feedback and rocker arrows
- Export GPX (waypoints + saved tracks + active log): Tracks -> MENU -> Export GPX

## v3
- Map grid (lat/lon squares) with the equator and prime meridian emphasised; toggle: map page -> MENU -> Grid
- Waypoint editor: GOTO list -> MENU, or Main Menu -> Waypoints -> ENTER (Go To, Rename, Edit Position, Use Current Position, Delete with confirm)
- Waypoints are written at start-up and after every change to `Download/<app name>/waypoints/waypoints.gpx` (Android 10+, no permission needed) and restored from it if app data is empty
- Setup -> Gen -> Map: North Up (map fixed, marker turns) or Track Up (map turns)
- Arrival is decided by distance to the waypoint coordinates only (Setup -> Alarm -> Arrive Dist: 3/5/10/15/25 m), independent of map zoom
- Whole device scales to the screen height, no scrolling
- Tides: Main Menu -> Sun & Moon -> MENU. Estimated from the moon (no station database): set the local "HW after moon" interval and the mean range from a local tide table
- The device powers on automatically; BACK works like QUIT (closes menus), press BACK twice within 2 s on a main page to leave the app (tracking keeps running)
