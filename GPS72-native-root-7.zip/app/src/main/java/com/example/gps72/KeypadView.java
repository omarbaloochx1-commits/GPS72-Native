package com.example.gps72;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

public class KeypadView extends View {
    public interface KeyCb { void key(String k, boolean lg); }
    public KeyCb cb;
    Handler h = new Handler(Looper.getMainLooper());
    Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    static final String[] K = {"zin", "zout", "goto", "light", "quit", "page", "menu", "enter", "up", "down", "left", "right"};
    static final String[] T = {"IN", "OUT", "GOTO", "", "QUIT", "PAGE", "MENU", "ENTER"};
    static final float[][] B = {{110, 84, 44, 26}, {170, 84, 44, 26}, {45, 116, 60, 30}, {45, 164, 60, 30}, {45, 212, 60, 30}, {235, 116, 60, 30}, {235, 164, 60, 30}, {235, 212, 60, 30}};
    static final float[][] D = {{140, 134}, {140, 194}, {110, 164}, {170, 164}};
    int down = -1;
    boolean fired;
    Runnable lr = new Runnable() {
        public void run() { fired = true; if (cb != null) cb.key(K[down], true); }
    };

    public KeypadView(Context c) { super(c); }

    @Override
    protected void onMeasure(int w, int hh) {
        int W = MeasureSpec.getSize(w);
        setMeasuredDimension(W, (int) (W * 250f / 280f));
    }

    void lab(Canvas c, String s, float x, float y, float z, int col, boolean center) {
        P.setStyle(Paint.Style.FILL); P.setShader(null); P.setColor(col); P.setTextSize(z);
        P.setTextAlign(center ? Paint.Align.CENTER : Paint.Align.LEFT); P.setTypeface(Typeface.DEFAULT);
        c.drawText(s, x, y, P);
    }

    @Override
    protected void onDraw(Canvas c) {
        float sc = getWidth() / 280f;
        c.scale(sc, sc);
        // logo (globe)
        Path gp = new Path(); gp.addCircle(140, 28, 26, Path.Direction.CW);
        c.save(); c.clipPath(gp);
        P.setStyle(Paint.Style.FILL); P.setShader(null); P.setColor(0xFF1B2234); c.drawRect(110, 0, 170, 60, P);
        P.setColor(0xFFAABBCC);
        for (int y = 2; y < 56; y += 5) c.drawRect(110, y, 170, y + 3, P);
        P.setColor(0xFF111111); c.drawCircle(136, 30, 9, P); c.drawCircle(150, 20, 6, P);
        c.restore();
        // labels
        lab(c, "ZOOM", 140, 66, 10, 0xFF99BBBB, true);
        lab(c, "MOB", 45, 92, 9, 0xFF99BBBB, true);
        lab(c, "MARK", 235, 238, 9, 0xFF99BBBB, true);
        // rocker
        P.setShader(new RadialGradient(140, 164, 44, new int[]{0xFF222222, 0xFF050505}, null, Shader.TileMode.CLAMP));
        P.setStyle(Paint.Style.FILL); c.drawCircle(140, 164, 44, P); P.setShader(null);
        P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(3); P.setColor(0xFF181818); c.drawCircle(140, 164, 41, P);
        if (down >= 8) { P.setStyle(Paint.Style.FILL); P.setColor(0x33FFFFFF); c.drawCircle(D[down - 8][0], D[down - 8][1], 20, P); }
        // buttons
        for (int i = 0; i < 8; i++) {
            float cx = B[i][0], cy = B[i][1], w = B[i][2], hh = B[i][3];
            RectF r = new RectF(cx - w / 2, cy - hh / 2 + (down == i ? 2 : 0), cx + w / 2, cy + hh / 2 + (down == i ? 2 : 0));
            P.setStyle(Paint.Style.FILL); P.setShader(null); P.setColor(0xFF000000);
            c.drawRoundRect(new RectF(r.left, r.top + 2, r.right, r.bottom + 2), hh / 2, hh / 2, P);
            P.setShader(new LinearGradient(0, r.top, 0, r.bottom, down == i ? 0xFF777777 : 0xFF4A4A4A, 0xFF121212, Shader.TileMode.CLAMP));
            c.drawRoundRect(r, hh / 2, hh / 2, P); P.setShader(null);
            if (i == 3) {
                P.setColor(0xFFFF3333); P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1.6f);
                c.drawCircle(cx, cy - 2, 5, P);
                c.drawLine(cx - 2, cy + 5, cx + 2, cy + 5, P);
                for (int a = 0; a < 8; a++) {
                    double g = Math.toRadians(a * 45 + 22);
                    c.drawLine(cx + (float) Math.cos(g) * 8, cy - 2 + (float) Math.sin(g) * 8, cx + (float) Math.cos(g) * 11, cy - 2 + (float) Math.sin(g) * 11, P);
                }
            } else {
                P.setStyle(Paint.Style.FILL); P.setColor(0xFFEEEEEE); P.setTextSize(i < 2 ? 11 : 12); P.setFakeBoldText(true);
                P.setTextAlign(Paint.Align.CENTER); P.setTypeface(Typeface.DEFAULT_BOLD);
                c.drawText(T[i], cx, r.centerY() + 4, P); P.setFakeBoldText(false);
            }
        }
        P.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC));
        P.setStyle(Paint.Style.FILL); P.setColor(0xFFCCDDDD); P.setTextSize(19); P.setTextAlign(Paint.Align.CENTER);
        c.drawText("GPS 72", 140, 240, P);
    }

    int hit(float x, float y) {
        float sc = getWidth() / 280f;
        x /= sc; y /= sc;
        for (int i = 0; i < 8; i++) if (Math.abs(x - B[i][0]) < B[i][2] / 2 + 5 && Math.abs(y - B[i][1]) < B[i][3] / 2 + 6) return i;
        for (int i = 0; i < 4; i++) { float dx = x - D[i][0], dy = y - D[i][1]; if (dx * dx + dy * dy < 26 * 26) return 8 + i; }
        return -1;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            down = hit(e.getX(), e.getY()); fired = false;
            if (down >= 0) {
                String k = K[down];
                if (k.equals("goto") || k.equals("enter") || k.equals("light")) h.postDelayed(lr, 900);
                else if (cb != null) cb.key(k, false);
            }
            invalidate();
            return true;
        }
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            if (down >= 0) {
                String k = K[down];
                if (k.equals("goto") || k.equals("enter") || k.equals("light")) {
                    h.removeCallbacks(lr);
                    if (!fired && a == MotionEvent.ACTION_UP && cb != null) cb.key(k, false);
                }
            }
            down = -1; invalidate();
            return true;
        }
        return true;
    }
}
