package com.example.gps72;

import android.util.Xml;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;
import java.util.TimeZone;
import org.xmlpull.v1.XmlPullParser;

public class WptImport {
    static String clean(String s, int max) {
        if (s == null) return "";
        s = s.replaceAll("\\p{Cntrl}", " ").trim();
        return s.length() > max ? s.substring(0, max) : s;
    }

    public static ArrayList<GpsView.Wp> read(File f) throws Exception {
        if (f.length() > 8L * 1024 * 1024) throw new Exception("too big");
        byte[] b = new byte[(int) f.length()];
        DataInputStream in = new DataInputStream(new FileInputStream(f));
        in.readFully(b);
        in.close();
        return read(b);
    }

    public static ArrayList<GpsView.Wp> read(byte[] b) throws Exception {
        if (b.length > 4 && b[0] == 'P' && b[1] == 'P') return parseWpt(b);
        return parseGpx(new ByteArrayInputStream(b));
    }

    static String str(DataInputStream in) throws Exception {
        int n = in.readInt();
        if (n < 0 || n > 10000) throw new Exception("bad string");
        byte[] x = new byte[n];
        in.readFully(x);
        return new String(x, "UTF-8");
    }

    // AlpineQuest .wpt: header, key/value properties, then one record (lon, lat as int32 * 1e7 ... timestamp int64 ms at the end)
    static ArrayList<GpsView.Wp> parseWpt(byte[] b) throws Exception {
        ArrayList<GpsView.Wp> out = new ArrayList<>();
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(b));
        byte[] m = new byte[4];
        in.readFully(m);
        in.readInt();
        int np = in.readInt();
        if (np < 0 || np > 100) throw new Exception("bad header");
        String name = "";
        for (int i = 0; i < np; i++) {
            String k = str(in), v = str(in);
            if (k.equals("name")) name = v;
        }
        in.readInt();
        in.readInt();
        int len = in.readInt();
        if (len < 16 || len > 4096) throw new Exception("bad record");
        byte[] r = new byte[len];
        in.readFully(r);
        ByteBuffer bb = ByteBuffer.wrap(r);
        double lon = bb.getInt(0) / 1e7, lat = bb.getInt(4) / 1e7;
        if (Math.abs(lat) > 90 || Math.abs(lon) > 180) throw new Exception("bad coordinates");
        String nm = clean(name, 40);
        GpsView.Wp w = new GpsView.Wp(nm.isEmpty() ? "WPT" : nm, lat, lon);
        if (len >= 22) {
            long ts = bb.getLong(len - 8);
            if (ts > 946684800000L && ts < 4102444800000L) w.ts = ts;
        }
        out.add(w);
        return out;
    }

    static long parseTime(String s) {
        try {
            String t = s.trim();
            if (t.length() < 19) return 0;
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            return f.parse(t.substring(0, 19)).getTime();
        } catch (Exception e) { return 0; }
    }

    static ArrayList<GpsView.Wp> parseGpx(java.io.InputStream is) throws Exception {
        ArrayList<GpsView.Wp> out = new ArrayList<>();
        XmlPullParser p = Xml.newPullParser();
        p.setInput(is, null);
        GpsView.Wp cur = null;
        String tag = null;
        int ev = p.getEventType();
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                String t = p.getName();
                if (t.equals("wpt")) {
                    try {
                        double la = Double.parseDouble(p.getAttributeValue(null, "lat")), lo = Double.parseDouble(p.getAttributeValue(null, "lon"));
                        cur = (Math.abs(la) <= 90 && Math.abs(lo) <= 180) ? new GpsView.Wp("", la, lo) : null;
                    } catch (Exception e) { cur = null; }
                    tag = null;
                } else if (cur != null) tag = t;
            } else if (ev == XmlPullParser.TEXT && cur != null && tag != null) {
                String x = p.getText().trim();
                try {
                    if (tag.equals("name")) cur.n = clean(x, 40);
                    else if (tag.equals("ele")) cur.ele = Double.parseDouble(x);
                    else if (tag.equals("time")) { long ts = parseTime(x); if (ts > 0) cur.ts = ts; }
                    else if (tag.equals("desc") || tag.equals("cmt")) { if (cur.desc.isEmpty()) cur.desc = clean(x, 120); }
                    else if (tag.equals("type")) cur.cat = clean(x, 30);
                } catch (Exception e) { }
            } else if (ev == XmlPullParser.END_TAG) {
                if (p.getName().equals("wpt") && cur != null) {
                    if (cur.n.isEmpty()) cur.n = "WPT" + (out.size() + 1);
                    out.add(cur);
                    cur = null;
                }
                tag = null;
            }
            ev = p.next();
        }
        return out;
    }
}
