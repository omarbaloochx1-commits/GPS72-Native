package com.example.gps72;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

public class KeypadView extends View {
    public interface KeyCb { void key(String k, boolean lg); boolean analog(); void stick(float nx, float ny); }
    public KeyCb cb;
    Handler h = new Handler(Looper.getMainLooper());
    Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    static final String[] K = {"zin", "zout", "goto", "light", "quit", "page", "menu", "enter", "up", "down", "left", "right", "pan"};
    static final String[] T = {"IN", "OUT", "GOTO", "", "QUIT", "PAGE", "MENU", "ENTER"};
    static final float[][] B = {{108, 80, 56, 30}, {172, 80, 56, 30}, {44, 108, 72, 36}, {44, 152, 72, 36}, {44, 196, 72, 36}, {236, 108, 72, 36}, {236, 152, 72, 36}, {236, 196, 72, 36}};
    static final float[][] D = {{140, 118}, {140, 186}, {106, 152}, {174, 152}};
    int down = -1, curDir = -2;
    float snx, sny;
    boolean stickOn, slRun;
    Runnable sl = new Runnable() {
        public void run() {
            if (stickOn && cb != null && cb.analog()) { cb.stick(snx, sny); h.postDelayed(this, 30); } else slRun = false;
        }
    };
    Runnable rep = new Runnable() {
        public void run() { if (down >= 8 && down < 12 && cb != null) { cb.key(K[down], false); h.postDelayed(this, 90); } }
    };
    boolean fired;
    Runnable lr = new Runnable() {
        public void run() { fired = true; if (cb != null) cb.key(K[down], true); }
    };

    public KeypadView(Context c) { super(c); }

    @Override
    protected void onMeasure(int w, int hh) {
        int W = MeasureSpec.getSize(w);
        setMeasuredDimension(W, (int) (W * 232f / 280f));
    }

    void lab(Canvas c, String s, float x, float y, float z, int col, boolean center) {
        P.setStyle(Paint.Style.FILL); P.setShader(null); P.setColor(col); P.setTextSize(z);
        P.setTextAlign(center ? Paint.Align.CENTER : Paint.Align.LEFT); P.setTypeface(Typeface.DEFAULT);
        c.drawText(s, x, y, P);
    }

    @Override
    protected void onDraw(Canvas c) {
        float sc = getWidth() / 280f;
        c.scale(sc, sc);
        // logo (globe)
        Path gp = new Path(); gp.addCircle(140, 24, 22, Path.Direction.CW);
        c.save(); c.clipPath(gp);
        P.setStyle(Paint.Style.FILL); P.setShader(null); P.setColor(0xFF1B2234); c.drawRect(110, 0, 170, 50, P);
        P.setColor(0xFFAABBCC);
        for (int y = 2; y < 48; y += 5) c.drawRect(110, y, 170, y + 3, P);
        P.setColor(0xFF111111); c.drawCircle(136, 26, 8, P); c.drawCircle(149, 17, 5, P);
        c.restore();
        // labels
        lab(c, "ZOOM", 140, 60, 10, 0xFF99BBBB, true);
        lab(c, "MOB", 44, 85, 9, 0xFF99BBBB, true);
        lab(c, "MARK", 236, 226, 9, 0xFF99BBBB, true);
        // rocker
        P.setShader(new RadialGradient(140, 152, 48, new int[]{0xFF222222, 0xFF050505}, null, Shader.TileMode.CLAMP));
        P.setStyle(Paint.Style.FILL); c.drawCircle(140, 152, 48, P); P.setShader(null);
        P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(3); P.setColor(0xFF181818); c.drawCircle(140, 152, 45, P);
        if (down >= 8 && down < 12) { P.setStyle(Paint.Style.FILL); P.setColor(0x33FFFFFF); c.drawCircle(D[down - 8][0], D[down - 8][1], 20, P); }
        // rocker arrows
        P.setStyle(Paint.Style.FILL); P.setColor(0xFF8A8A8A);
        float[][] ar = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};
        for (int i = 0; i < 4; i++) {
            float ax = D[i][0] + ar[i][0] * 6, ay = D[i][1] + ar[i][1] * 6, px = -ar[i][1], py = ar[i][0];
            Path tp = new Path();
            tp.moveTo(ax + ar[i][0] * 6, ay + ar[i][1] * 6);
            tp.lineTo(ax + px * 6, ay + py * 6);
            tp.lineTo(ax - px * 6, ay - py * 6);
            tp.close();
            c.drawPath(tp, P);
        }
        // centre button (map pan cursor)
        P.setStyle(Paint.Style.FILL);
        P.setShader(new RadialGradient(140, 150, 15, down == 12 ? 0xFF777777 : 0xFF4A4A4A, 0xFF121212, Shader.TileMode.CLAMP));
        c.drawCircle(140, 152, 14, P); P.setShader(null);
        P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1.5f); P.setColor(0xFFBBBBBB);
        c.drawCircle(140, 152, 4.5f, P);
        c.drawLine(140, 142, 140, 146, P); c.drawLine(140, 158, 140, 162, P);
        c.drawLine(130, 152, 134, 152, P); c.drawLine(146, 152, 150, 152, P);
        if (stickOn) {
            P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(2); P.setColor(0x66FFFFFF); c.drawCircle(140, 152, 52, P);
            P.setStyle(Paint.Style.FILL); P.setColor(0x88FFFFFF); c.drawCircle(140 + snx * 40, 152 + sny * 40, 10, P);
        }
        // buttons
        for (int i = 0; i < 8; i++) {
            float cx = B[i][0], cy = B[i][1], w = B[i][2], hh = B[i][3];
            RectF r = new RectF(cx - w / 2, cy - hh / 2 + (down == i ? 2 : 0), cx + w / 2, cy + hh / 2 + (down == i ? 2 : 0));
            P.setStyle(Paint.Style.FILL); P.setShader(null); P.setColor(0xFF000000);
            c.drawRoundRect(new RectF(r.left, r.top + 2, r.right, r.bottom + 2), hh / 2, hh / 2, P);
            P.setShader(new LinearGradient(0, r.top, 0, r.bottom, down == i ? 0xFF777777 : 0xFF4A4A4A, 0xFF121212, Shader.TileMode.CLAMP));
            c.drawRoundRect(r, hh / 2, hh / 2, P); P.setShader(null);
            if (i == 3) {
                P.setColor(0xFFFF3333); P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(1.6f);
                c.drawCircle(cx, cy - 2, 6, P);
                c.drawLine(cx - 3, cy + 6, cx + 3, cy + 6, P);
                for (int a = 0; a < 8; a++) {
                    double g = Math.toRadians(a * 45 + 22);
                    c.drawLine(cx + (float) Math.cos(g) * 10, cy - 2 + (float) Math.sin(g) * 10, cx + (float) Math.cos(g) * 14, cy - 2 + (float) Math.sin(g) * 14, P);
                }
            } else {
                P.setStyle(Paint.Style.FILL); P.setColor(0xFFEEEEEE); P.setTextSize(i < 2 ? 12 : 14); P.setFakeBoldText(true);
                P.setTextAlign(Paint.Align.CENTER); P.setTypeface(Typeface.DEFAULT_BOLD);
                c.drawText(T[i], cx, r.centerY() + 5, P); P.setFakeBoldText(false);
            }
        }
        P.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC));
        P.setStyle(Paint.Style.FILL); P.setColor(0xFFCCDDDD); P.setTextSize(19); P.setTextAlign(Paint.Align.CENTER);
        c.drawText("GPS 72", 140, 227, P);
    }

    int hit(float x, float y) {
        float sc = getWidth() / 280f;
        x /= sc; y /= sc;
        if ((x - 140) * (x - 140) + (y - 152) * (y - 152) < 15 * 15) return 12;
        for (int i = 0; i < 8; i++) if (Math.abs(x - B[i][0]) < B[i][2] / 2 + 5 && Math.abs(y - B[i][1]) < B[i][3] / 2 + 3) return i;
        if ((x - 140) * (x - 140) + (y - 152) * (y - 152) < 62 * 62) return 13;
        return -1;
    }

    void updateStick(float px, float py) {
        float sc = getWidth() / 280f, x = px / sc, y = py / sc;
        float dx = (x - 140) / 52f, dy = (y - 152) / 52f;
        float m = (float) Math.hypot(dx, dy);
        if (m > 1) { dx /= m; dy /= m; m = 1; }
        snx = dx; sny = dy;
        if (cb == null) return;
        if (cb.analog()) {
            if (!slRun) { slRun = true; h.post(sl); }
            return;
        }
        int dir = -1;
        if (m > 0.3f) dir = Math.abs(dx) > Math.abs(dy) ? (dx > 0 ? 3 : 2) : (dy > 0 ? 1 : 0);
        if (dir != curDir) {
            curDir = dir;
            h.removeCallbacks(rep);
            if (dir >= 0) { down = 8 + dir; cb.key(K[down], false); h.postDelayed(rep, 420); } else down = 13;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            down = hit(e.getX(), e.getY()); fired = false;
            if (down == 13) {
                stickOn = true; curDir = -2;
                performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
                updateStick(e.getX(), e.getY());
            } else if (down >= 0) {
                performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY);
                String k = K[down];
                if (k.equals("goto") || k.equals("enter") || k.equals("light")) h.postDelayed(lr, 900);
                else if (cb != null) cb.key(k, false);
            }
            invalidate();
            return true;
        }
        if (a == MotionEvent.ACTION_MOVE) {
            if (stickOn) { updateStick(e.getX(), e.getY()); invalidate(); }
            return true;
        }
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            h.removeCallbacks(rep);
            if (stickOn) {
                stickOn = false; curDir = -2; snx = 0; sny = 0;
                if (cb != null) cb.stick(0, 0);
            } else if (down >= 0 && down < K.length) {
                String k = K[down];
                if (k.equals("goto") || k.equals("enter") || k.equals("light")) {
                    h.removeCallbacks(lr);
                    if (!fired && a == MotionEvent.ACTION_UP && cb != null) cb.key(k, false);
                }
            }
            down = -1; invalidate();
            return true;
        }
        return true;
    }
}
