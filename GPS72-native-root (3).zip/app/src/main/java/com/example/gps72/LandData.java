package com.example.gps72;

import android.util.JsonReader;
import android.util.JsonToken;
import java.io.IOException;
import java.util.ArrayList;

/** Streaming parser for the offline map data: GeoJSON polygons (land) and lines (coastline), plus Overpass JSON. */
final class LandData {
    private LandData() { }

    static void readGeo(JsonReader r, ArrayList<ArrayList<float[]>> np, ArrayList<float[]> nb, ArrayList<float[]> nl, ArrayList<float[]> nlb) throws IOException {
        if (r.peek() != JsonToken.BEGIN_OBJECT) { r.skipValue(); return; }
        r.beginObject();
        String gt = "";
        while (r.hasNext()) {
            String k = r.nextName();
            if (k.equals("type") && r.peek() == JsonToken.STRING) gt = r.nextString();
            else if (k.equals("features") || k.equals("geometries") || k.equals("elements")) { r.beginArray(); while (r.hasNext()) readGeo(r, np, nb, nl, nlb); r.endArray(); }
            else if (k.equals("geometry") && r.peek() == JsonToken.BEGIN_ARRAY) readOverpass(r, nl, nlb);
            else if (k.equals("geometry")) readGeo(r, np, nb, nl, nlb);
            else if (k.equals("coordinates")) addCoords(readCoords(r), np, nb, nl, nlb, gt.contains("Line"));
            else r.skipValue();
        }
        r.endObject();
    }

    /** One Overpass "way" geometry: [{lat,lon},...] (oriented: coast keeps land on its left). */
    static void readOverpass(JsonReader r, ArrayList<float[]> nl, ArrayList<float[]> nlb) throws IOException {
        ArrayList<float[]> pts = new ArrayList<>();
        r.beginArray();
        while (r.hasNext()) {
            double la = Double.NaN, lo = Double.NaN;
            r.beginObject();
            while (r.hasNext()) {
                String k = r.nextName();
                if (k.equals("lat")) la = r.nextDouble(); else if (k.equals("lon")) lo = r.nextDouble(); else r.skipValue();
            }
            r.endObject();
            if (!Double.isNaN(la) && !Double.isNaN(lo)) pts.add(new float[]{(float) la, (float) lo});
        }
        r.endArray();
        addLine(pts, true, nl, nlb);
    }

    static void addLine(ArrayList<float[]> pts, boolean oriented, ArrayList<float[]> nl, ArrayList<float[]> nlb) {
        if (pts.size() < 2) return;
        float[] a = new float[pts.size() * 2];
        float[] box = {90, -90, 180, -180, oriented ? 1 : 0};
        for (int i = 0; i < pts.size(); i++) {
            a[2 * i] = pts.get(i)[0]; a[2 * i + 1] = pts.get(i)[1];
            box[0] = Math.min(box[0], a[2 * i]); box[1] = Math.max(box[1], a[2 * i]);
            box[2] = Math.min(box[2], a[2 * i + 1]); box[3] = Math.max(box[3], a[2 * i + 1]);
        }
        nl.add(a); nlb.add(box);
    }

    static Object readCoords(JsonReader r) throws IOException {
        r.beginArray();
        if (r.peek() == JsonToken.NUMBER) {
            double[] p = new double[2]; int n = 0;
            while (r.hasNext()) { double v = r.nextDouble(); if (n < 2) p[n] = v; n++; }
            r.endArray(); return p;
        }
        ArrayList<Object> l = new ArrayList<>();
        while (r.hasNext()) l.add(readCoords(r));
        r.endArray(); return l;
    }

    @SuppressWarnings("unchecked")
    static void addCoords(Object o, ArrayList<ArrayList<float[]>> np, ArrayList<float[]> nb, ArrayList<float[]> nl, ArrayList<float[]> nlb, boolean line) {
        if (!(o instanceof ArrayList)) return;
        ArrayList<Object> l = (ArrayList<Object>) o;
        if (l.isEmpty()) return;
        if (line) {
            if (l.get(0) instanceof double[]) {
                ArrayList<float[]> pts = new ArrayList<>();
                for (Object q : l) { double[] d = (double[]) q; pts.add(new float[]{(float) d[1], (float) d[0]}); }
                addLine(pts, false, nl, nlb);
            } else for (Object po : l) addCoords(po, np, nb, nl, nlb, true);
            return;
        }
        if (!(l.get(0) instanceof ArrayList)) return;
        ArrayList<Object> f = (ArrayList<Object>) l.get(0);
        if (f.isEmpty()) return;
        if (f.get(0) instanceof double[]) {
            ArrayList<float[]> out = new ArrayList<>();
            float[] box = {90, -90, 180, -180};
            for (int k = 0; k < l.size(); k++) {
                ArrayList<Object> ring = (ArrayList<Object>) l.get(k);
                float[] a = new float[ring.size() * 2];
                for (int i = 0; i < ring.size(); i++) {
                    double[] p = (double[]) ring.get(i);
                    a[2 * i] = (float) p[1]; a[2 * i + 1] = (float) p[0];
                    if (k == 0) { box[0] = Math.min(box[0], a[2 * i]); box[1] = Math.max(box[1], a[2 * i]); box[2] = Math.min(box[2], a[2 * i + 1]); box[3] = Math.max(box[3], a[2 * i + 1]); }
                }
                out.add(a);
            }
            np.add(out); nb.add(box);
        } else for (Object po : l) addCoords(po, np, nb, nl, nlb, false);
    }
}
