package com.example.gps72;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** GPX 1.1 export (waypoints with ele/time/desc/type, tracks) and waypoint import. */
final class Gpx {
    private Gpx() { }

    static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    static String unesc(String s) {
        return s.replace("&quot;", "\"").replace("&gt;", ">").replace("&lt;", "<").replace("&amp;", "&");
    }

    static SimpleDateFormat fmt() {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f;
    }

    static String build(ArrayList<GpsView.Wp> wps, ArrayList<double[]> log, ArrayList<GpsView.Trk> saved) {
        StringBuilder b = new StringBuilder(64 * 1024);
        SimpleDateFormat f = fmt();
        b.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        b.append("<gpx version=\"1.1\" creator=\"GPS 72\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n");
        for (GpsView.Wp w : wps) {
            b.append(String.format(Locale.US, "<wpt lat=\"%.7f\" lon=\"%.7f\">", w.la, w.lo));
            if (!Double.isNaN(w.ele)) b.append(String.format(Locale.US, "<ele>%.1f</ele>", w.ele));
            b.append("<time>").append(f.format(new Date(w.ts))).append("</time><name>").append(esc(w.n)).append("</name>");
            if (!w.desc.isEmpty()) b.append("<desc>").append(esc(w.desc)).append("</desc>");
            if (!w.cat.isEmpty()) b.append("<type>").append(esc(w.cat)).append("</type>");
            b.append("</wpt>\n");
        }
        for (GpsView.Trk t : saved) segment(b, t.n, t.p);
        if (log.size() > 1) segment(b, "ACTIVE LOG", log);
        b.append("</gpx>\n");
        return b.toString();
    }

    static String tag(String s, String t) {
        int a = s.indexOf("<" + t + ">");
        if (a < 0) return "";
        a += t.length() + 2;
        int e = s.indexOf("</" + t + ">", a);
        return e < 0 ? "" : s.substring(a, e);
    }

    /** Reads the <wpt> entries written by build(). */
    static ArrayList<GpsView.Wp> parseWaypoints(String xml) {
        ArrayList<GpsView.Wp> out = new ArrayList<>();
        Matcher m = Pattern.compile("<wpt lat=\"([^\"]+)\" lon=\"([^\"]+)\">(.*?)</wpt>", Pattern.DOTALL).matcher(xml);
        SimpleDateFormat f = fmt();
        while (m.find()) {
            try {
                String in = m.group(3);
                GpsView.Wp w = new GpsView.Wp(unesc(tag(in, "name")), Double.parseDouble(m.group(1)), Double.parseDouble(m.group(2)));
                String es = tag(in, "ele");
                if (!es.isEmpty()) w.ele = Double.parseDouble(es);
                w.desc = unesc(tag(in, "desc"));
                w.cat = unesc(tag(in, "type"));
                String ts = tag(in, "time");
                if (!ts.isEmpty()) { Date d = f.parse(ts); if (d != null) w.ts = d.getTime(); }
                if (!w.n.isEmpty()) out.add(w);
            } catch (Exception e) { }
        }
        return out;
    }

    private static void segment(StringBuilder b, String name, ArrayList<double[]> pts) {
        if (pts.size() < 2) return;
        b.append("  <trk><name>").append(esc(name)).append("</name><trkseg>\n");
        for (double[] q : pts) b.append(String.format(Locale.US, "    <trkpt lat=\"%.6f\" lon=\"%.6f\"/>\n", q[0], q[1]));
        b.append("  </trkseg></trk>\n");
    }
}
