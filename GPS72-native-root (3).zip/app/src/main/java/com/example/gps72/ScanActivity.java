package com.example.gps72;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.SurfaceTexture;
import android.hardware.Camera;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.DecodeHintType;
import com.google.zxing.PlanarYUVLuminanceSource;
import com.google.zxing.Result;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.qrcode.QRCodeReader;
import java.util.EnumMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public class ScanActivity extends Activity implements TextureView.SurfaceTextureListener, Camera.PreviewCallback {
    TextureView tv;
    Camera cam;
    int pw, ph;
    volatile boolean done;
    QRCodeReader reader = new QRCodeReader();
    ExecutorService ex = Executors.newSingleThreadExecutor();
    AtomicBoolean busy = new AtomicBoolean(false);
    EnumMap<DecodeHintType, Object> hints = new EnumMap<>(DecodeHintType.class);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        hints.put(DecodeHintType.TRY_HARDER, Boolean.TRUE);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        tv = new TextureView(this);
        tv.setSurfaceTextureListener(this);
        root.addView(tv, new FrameLayout.LayoutParams(-1, -1));
        TextView hint = new TextView(this);
        hint.setText("Point the camera at a GPS 72 QR code");
        hint.setTextColor(0xFFFFFFFF);
        hint.setTextSize(16);
        hint.setGravity(Gravity.CENTER);
        hint.setBackgroundColor(0x88000000);
        hint.setPadding(20, 20, 20, 20);
        root.addView(hint, new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM));
        setContentView(root);
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA}, 5);
        }
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        super.onRequestPermissionsResult(c, p, r);
        if (r.length > 0 && r[0] == PackageManager.PERMISSION_GRANTED) {
            if (tv.isAvailable()) open(tv.getSurfaceTexture());
        } else {
            Toast.makeText(this, "Camera permission is needed to scan", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    void open(SurfaceTexture st) {
        if (cam != null || checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        try {
            int id = 0;
            Camera.CameraInfo ci = new Camera.CameraInfo();
            for (int i = 0; i < Camera.getNumberOfCameras(); i++) {
                Camera.getCameraInfo(i, ci);
                if (ci.facing == Camera.CameraInfo.CAMERA_FACING_BACK) { id = i; break; }
            }
            Camera.getCameraInfo(id, ci);
            cam = Camera.open(id);
            Camera.Parameters p = cam.getParameters();
            List<Camera.Size> ss = p.getSupportedPreviewSizes();
            Camera.Size best = ss.get(0);
            long bestScore = Long.MAX_VALUE;
            for (Camera.Size s : ss) {
                long area = (long) s.width * s.height;
                long score = Math.abs(area - 1280L * 720L);
                if (score < bestScore) { bestScore = score; best = s; }
            }
            p.setPreviewSize(best.width, best.height);
            pw = best.width;
            ph = best.height;
            List<String> fm = p.getSupportedFocusModes();
            if (fm != null && fm.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE)) p.setFocusMode(Camera.Parameters.FOCUS_MODE_CONTINUOUS_PICTURE);
            cam.setParameters(p);
            int rot = getWindowManager().getDefaultDisplay().getRotation();
            int deg = rot == Surface.ROTATION_90 ? 90 : rot == Surface.ROTATION_180 ? 180 : rot == Surface.ROTATION_270 ? 270 : 0;
            int res = (ci.orientation - deg + 360) % 360;
            cam.setDisplayOrientation(res);
            int dw = res % 180 == 90 ? ph : pw, dh = res % 180 == 90 ? pw : ph;
            DisplayMetrics dm = getResources().getDisplayMetrics();
            float a = (float) dw / dh;
            int w, h;
            if (dm.widthPixels / (float) dm.heightPixels > a) { h = dm.heightPixels; w = (int) (h * a); } else { w = dm.widthPixels; h = (int) (w / a); }
            tv.setLayoutParams(new FrameLayout.LayoutParams(w, h, Gravity.CENTER));
            cam.setPreviewTexture(st);
            cam.setPreviewCallback(this);
            cam.startPreview();
        } catch (Exception e) {
            Toast.makeText(this, "Camera error", Toast.LENGTH_LONG).show();
            finish();
        }
    }

    void close() {
        if (cam != null) {
            try { cam.setPreviewCallback(null); cam.stopPreview(); cam.release(); } catch (Exception e) { }
            cam = null;
        }
    }

    @Override
    public void onPreviewFrame(final byte[] data, Camera c) {
        if (done || !busy.compareAndSet(false, true)) return;
        final int w = pw, h = ph;
        ex.execute(new Runnable() {
            public void run() {
                try {
                    PlanarYUVLuminanceSource src = new PlanarYUVLuminanceSource(data, w, h, 0, 0, w, h, false);
                    Result r = reader.decode(new BinaryBitmap(new HybridBinarizer(src)), hints);
                    done = true;
                    final String t = r.getText();
                    runOnUiThread(new Runnable() {
                        public void run() {
                            Intent i = new Intent();
                            i.putExtra("text", t);
                            setResult(RESULT_OK, i);
                            finish();
                        }
                    });
                } catch (Exception e) {
                } finally {
                    reader.reset();
                    busy.set(false);
                }
            }
        });
    }

    @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) { open(st); }
    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) { }
    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) { close(); return true; }
    @Override public void onSurfaceTextureUpdated(SurfaceTexture st) { }

    @Override
    protected void onPause() {
        super.onPause();
        close();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        ex.shutdown();
    }
}
