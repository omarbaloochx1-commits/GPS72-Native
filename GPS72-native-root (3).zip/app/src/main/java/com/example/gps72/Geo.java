package com.example.gps72;

import android.location.Location;

/** Pure geodesy and astronomy helpers (no UI state). */
final class Geo {
    private Geo() { }

    static final double EARTH_R = 6371000.0;
    static final double M_PER_DEG_LAT = 110540;
    static final double M_PER_DEG_LON = 111320;

    /** Distance in meters between two WGS84 points. */
    static double dist(double la1, double lo1, double la2, double lo2) {
        float[] r = new float[2];
        Location.distanceBetween(la1, lo1, la2, lo2, r);
        return r[0];
    }

    /** Initial bearing in degrees (0..360, true north) from point 1 to point 2. */
    static double brg(double la1, double lo1, double la2, double lo2) {
        float[] r = new float[2];
        Location.distanceBetween(la1, lo1, la2, lo2, r);
        return (r[1] + 360) % 360;
    }

    /** UTM coordinates as {"33T E123456", "N1234567"}. */
    static String[] utm(double lat, double lon) {
        double a = 6378137, fl2 = 1 / 298.257223563, k0 = 0.9996, e2 = fl2 * (2 - fl2), ep2 = e2 / (1 - e2);
        int zone = Math.min(60, (int) ((lon + 180) / 6) + 1);
        double lon0 = Math.toRadians((zone - 1) * 6 - 180 + 3), phi = Math.toRadians(lat), lam = Math.toRadians(lon);
        double N = a / Math.sqrt(1 - e2 * Math.sin(phi) * Math.sin(phi)), T2 = Math.tan(phi) * Math.tan(phi), C2 = ep2 * Math.cos(phi) * Math.cos(phi), A = Math.cos(phi) * (lam - lon0);
        double M = a * ((1 - e2 / 4 - 3 * e2 * e2 / 64 - 5 * e2 * e2 * e2 / 256) * phi - (3 * e2 / 8 + 3 * e2 * e2 / 32 + 45 * e2 * e2 * e2 / 1024) * Math.sin(2 * phi) + (15 * e2 * e2 / 256 + 45 * e2 * e2 * e2 / 1024) * Math.sin(4 * phi) - (35 * e2 * e2 * e2 / 3072) * Math.sin(6 * phi));
        double x = k0 * N * (A + (1 - T2 + C2) * A * A * A / 6 + (5 - 18 * T2 + T2 * T2 + 72 * C2 - 58 * ep2) * Math.pow(A, 5) / 120) + 500000;
        double y = k0 * (M + N * Math.tan(phi) * (A * A / 2 + (5 - T2 + 9 * C2 + 4 * C2 * C2) * Math.pow(A, 4) / 24 + (61 - 58 * T2 + T2 * T2 + 600 * C2 - 330 * ep2) * Math.pow(A, 6) / 720));
        if (lat < 0) y += 10000000;
        char band = "CDEFGHJKLMNPQRSTUVWX".charAt(Math.max(0, Math.min(19, (int) Math.floor((lat + 80) / 8))));
        return new String[]{zone + "" + band + " E" + (long) x, "N" + (long) y};
    }

    /** Maidenhead locator (6 characters). */
    static String maidenhead(double lat, double lon) {
        double lo = lon + 180, la2 = lat + 90;
        char[] s = new char[6];
        s[0] = (char) ('A' + Math.min(17, (int) (lo / 20)));
        s[1] = (char) ('A' + Math.min(17, (int) (la2 / 10)));
        s[2] = (char) ('0' + Math.min(9, (int) ((lo % 20) / 2)));
        s[3] = (char) ('0' + Math.min(9, (int) (la2 % 10)));
        s[4] = (char) ('a' + Math.min(23, (int) ((lo % 2) * 12)));
        s[5] = (char) ('a' + Math.min(23, (int) ((la2 % 1) * 24)));
        return new String(s);
    }

    /** {sunriseMs, sunsetMs} for the given place and instant, or {-1,-1} for polar day/night. */
    static long[] sunTimes(double lat, double lon, long nowMs) {
        double jd = nowMs / 86400000.0 + 2440587.5;
        double n = Math.round(jd - 2451545.0 + 0.0008), js = n - lon / 360.0;
        double M = (357.5291 + 0.98560028 * js) % 360, mr = Math.toRadians(M);
        double cc = 1.9148 * Math.sin(mr) + 0.02 * Math.sin(2 * mr) + 0.0003 * Math.sin(3 * mr);
        double lam = Math.toRadians((M + cc + 180 + 102.9372) % 360);
        double jt = 2451545.0 + js + 0.0053 * Math.sin(mr) - 0.0069 * Math.sin(2 * lam);
        double dec = Math.asin(Math.sin(lam) * Math.sin(Math.toRadians(23.44))), la = Math.toRadians(lat);
        double cw = (Math.sin(Math.toRadians(-0.833)) - Math.sin(la) * Math.sin(dec)) / (Math.cos(la) * Math.cos(dec));
        if (Math.abs(cw) > 1) return new long[]{-1, -1};
        double w = Math.toDegrees(Math.acos(cw)) / 360.0;
        return new long[]{(long) ((jt - w - 2440587.5) * 86400000.0), (long) ((jt + w - 2440587.5) * 86400000.0)};
    }

    /** {moonAgeDays, illuminatedFraction}. */
    static double[] moon(long nowMs) {
        double jd = nowMs / 86400000.0 + 2440587.5, syn = 29.530588853;
        double age = ((jd - 2451550.1) % syn + syn) % syn;
        return new double[]{age, (1 - Math.cos(2 * Math.PI * age / syn)) / 2};
    }

    static String phaseName(double a) {
        return a < 1.85 ? "New Moon" : a < 7.38 ? "Waxing Crescent" : a < 9.23 ? "First Quarter" : a < 14.77 ? "Waxing Gibbous" : a < 16.61 ? "Full Moon" : a < 22.15 ? "Waning Gibbous" : a < 24.0 ? "Last Quarter" : a < 27.7 ? "Waning Crescent" : "New Moon";
    }
}
