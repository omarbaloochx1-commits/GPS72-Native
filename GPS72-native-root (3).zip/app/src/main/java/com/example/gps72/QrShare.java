package com.example.gps72;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;

public class QrShare {
    static final int LIMIT = 650;

    public static class Res {
        public ArrayList<GpsView.Wp> list = new ArrayList<>();
        public String err;
    }

    static double r6(double v) { return Math.round(v * 1e6) / 1e6; }

    static String clean(String s, int max) {
        if (s == null) return "";
        s = s.replaceAll("\\p{Cntrl}", " ").trim();
        return s.length() > max ? s.substring(0, max) : s;
    }

    static String wrap(JSONArray a) throws Exception {
        return new JSONObject().put("t", "gps72wp").put("v", 1).put("w", a).toString();
    }

    public static ArrayList<String> payloads(List<GpsView.Wp> l) throws Exception {
        ArrayList<String> out = new ArrayList<>();
        JSONArray cur = new JSONArray();
        int size = 40;
        for (GpsView.Wp w : l) {
            JSONObject o = new JSONObject();
            o.put("n", w.n);
            o.put("la", r6(w.la));
            o.put("lo", r6(w.lo));
            if (!Double.isNaN(w.ele)) o.put("e", Math.round(w.ele * 10) / 10.0);
            if (!w.desc.isEmpty()) o.put("d", w.desc);
            if (!w.cat.isEmpty()) o.put("c", w.cat);
            o.put("ts", w.ts);
            int sz = o.toString().getBytes("UTF-8").length + 1;
            if (cur.length() > 0 && size + sz > LIMIT) { out.add(wrap(cur)); cur = new JSONArray(); size = 40; }
            cur.put(o);
            size += sz;
        }
        if (cur.length() > 0) out.add(wrap(cur));
        return out;
    }

    public static Res parse(String s) {
        Res r = new Res();
        try {
            JSONObject o = new JSONObject(s);
            if (!"gps72wp".equals(o.optString("t")) || o.optInt("v", 0) != 1) { r.err = "Not a GPS 72 waypoint QR code"; return r; }
            JSONArray a = o.getJSONArray("w");
            for (int i = 0; i < a.length() && i < 200; i++) {
                JSONObject j = a.getJSONObject(i);
                String n = clean(j.getString("n"), 40);
                double la = j.getDouble("la"), lo = j.getDouble("lo");
                if (n.isEmpty() || Double.isNaN(la) || Double.isNaN(lo) || Math.abs(la) > 90 || Math.abs(lo) > 180) { r.err = "Invalid waypoint data"; r.list.clear(); return r; }
                GpsView.Wp w = new GpsView.Wp(n, la, lo);
                if (j.has("e")) { double e = j.getDouble("e"); if (!Double.isNaN(e) && Math.abs(e) < 20000) w.ele = e; }
                w.desc = clean(j.optString("d", ""), 120);
                w.cat = clean(j.optString("c", ""), 30);
                long ts = j.optLong("ts", 0);
                if (ts > 0) w.ts = ts;
                r.list.add(w);
            }
            if (r.list.isEmpty()) r.err = "QR code has no waypoints";
        } catch (Exception e) { r.err = "Invalid QR data"; r.list.clear(); }
        return r;
    }

    static Bitmap qr(String text, int maxPx) throws Exception {
        EnumMap<EncodeHintType, Object> h = new EnumMap<>(EncodeHintType.class);
        h.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        h.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M);
        h.put(EncodeHintType.MARGIN, 4);
        BitMatrix m = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, h);
        int n = m.getWidth(), sc = Math.max(2, maxPx / n), sz = n * sc;
        int[] px = new int[sz * sz];
        for (int y = 0; y < sz; y++) for (int x = 0; x < sz; x++) px[y * sz + x] = m.get(x / sc, y / sc) ? 0xFF000000 : 0xFFFFFFFF;
        return Bitmap.createBitmap(px, sz, sz, Bitmap.Config.ARGB_8888);
    }

    static Button btn(Context c, String t) {
        Button b = new Button(c);
        b.setText(t);
        b.setAllCaps(false);
        return b;
    }

    public static void showQr(final Context c, final ArrayList<String> pl, final int total) {
        final Dialog d = new Dialog(c);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        final float dn = c.getResources().getDisplayMetrics().density;
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        final int px = (int) Math.min(dm.widthPixels * 0.94, dm.heightPixels * 0.60);
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFF101010);
        int p = (int) (10 * dn);
        root.setPadding(p, p, p, p);
        final TextView tt = new TextView(c);
        tt.setTextColor(Color.WHITE);
        tt.setTextSize(16);
        tt.setGravity(Gravity.CENTER);
        root.addView(tt, new LinearLayout.LayoutParams(-1, -2));
        final ImageView iv = new ImageView(c);
        iv.setBackgroundColor(Color.WHITE);
        root.addView(iv, new LinearLayout.LayoutParams(px, px));
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        final int[] idx = {0};
        final Runnable upd = new Runnable() {
            public void run() {
                try {
                    Bitmap b = qr(pl.get(idx[0]), px);
                    iv.setImageBitmap(b);
                    iv.setLayoutParams(new LinearLayout.LayoutParams(b.getWidth(), b.getHeight()));
                    tt.setText(pl.size() > 1 ? "QR " + (idx[0] + 1) + " / " + pl.size() + "   (" + total + " waypoints total)" : total + (total == 1 ? " waypoint" : " waypoints"));
                } catch (Exception e) { tt.setText("QR error"); }
            }
        };
        if (pl.size() > 1) {
            Button pv = btn(c, "< Prev");
            pv.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { idx[0] = (idx[0] + pl.size() - 1) % pl.size(); upd.run(); } });
            bar.addView(pv);
            Button nx = btn(c, "Next >");
            nx.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { idx[0] = (idx[0] + 1) % pl.size(); upd.run(); } });
            bar.addView(nx);
        }
        Button cl = btn(c, "Close");
        cl.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { d.dismiss(); } });
        bar.addView(cl);
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        d.setContentView(root);
        upd.run();
        d.show();
        Window w = d.getWindow();
        if (w != null) {
            w.setLayout(-1, -2);
            w.setBackgroundDrawable(new ColorDrawable(0xFF101010));
            w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.screenBrightness = 1f;
            w.setAttributes(lp);
        }
    }

    public static void showImport(Context c, String text, GpsView gv) {
        Res r = parse(text);
        if (r.err != null) { Toast.makeText(c, r.err, Toast.LENGTH_LONG).show(); return; }
        showList(c, r.list, gv);
    }

    public static void showList(final Context c, ArrayList<GpsView.Wp> list, final GpsView gv) {
        final ArrayList<GpsView.Wp> fresh = new ArrayList<>();
        StringBuilder sb = new StringBuilder();
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
        int dup = 0;
        for (GpsView.Wp w : list) {
            boolean dp = gv.isDup(w);
            for (GpsView.Wp x : fresh) if (x.n.equalsIgnoreCase(w.n) && GpsView.dist(x.la, x.lo, w.la, w.lo) < 2) dp = true;
            if (dp) dup++; else fresh.add(w);
            sb.append(dp ? "\u2716 " : "\u2714 ").append(w.n).append(dp ? "   (already saved)" : "").append('\n');
            sb.append("    ").append(String.format(Locale.US, "%.5f, %.5f", w.la, w.lo));
            if (!Double.isNaN(w.ele)) sb.append(String.format(Locale.US, "   alt %.0f m", w.ele));
            sb.append('\n');
            if (!w.cat.isEmpty()) sb.append("    Category: ").append(w.cat).append('\n');
            if (!w.desc.isEmpty()) sb.append("    ").append(w.desc).append('\n');
            sb.append("    Created: ").append(f.format(new Date(w.ts))).append("\n\n");
        }
        final Dialog d = new Dialog(c);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        float dn = c.getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF1B1B1B);
        int p = (int) (12 * dn);
        root.setPadding(p, p, p, p);
        TextView title = new TextView(c);
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setText("Import Waypoint\n" + fresh.size() + " new, " + dup + " already saved");
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        ScrollView sv = new ScrollView(c);
        TextView body = new TextView(c);
        body.setTextColor(0xFFDDDDDD);
        body.setTextSize(14);
        body.setText(sb.toString());
        body.setTextDirection(View.TEXT_DIRECTION_FIRST_STRONG);
        sv.addView(body);
        root.addView(sv, new LinearLayout.LayoutParams(-1, (int) (320 * dn)));
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.END);
        Button cancel = btn(c, "Cancel");
        cancel.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { d.dismiss(); } });
        bar.addView(cancel);
        Button imp = btn(c, fresh.isEmpty() ? "Nothing new" : fresh.size() == 1 ? "Import Waypoint" : "Import " + fresh.size() + " Waypoints");
        imp.setEnabled(!fresh.isEmpty());
        imp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                int n = gv.importWps(fresh);
                Toast.makeText(c, "Imported " + n + (n == 1 ? " waypoint" : " waypoints"), Toast.LENGTH_LONG).show();
                d.dismiss();
            }
        });
        bar.addView(imp);
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        d.setContentView(root);
        d.show();
        Window w = d.getWindow();
        if (w != null) { w.setLayout(-1, -2); w.setBackgroundDrawable(new ColorDrawable(0xFF1B1B1B)); }
    }
}
