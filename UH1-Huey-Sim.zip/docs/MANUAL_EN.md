# UH-1H Huey Simulator - Operating Manual

## 1. Welcome

UH-1H Huey Simulator is a 2-D side-view simulator of the Bell UH-1H Iroquois. The world is a vertical slice that runs east-west: you watch the helicopter from the side, while a full physical model runs underneath.

- Rotor thrust, induced / profile / parasite power, ground effect, translational lift and autorotation are calculated from momentum theory.

- The engine (Lycoming T53-L-13 type) has a gas producer (N1), power turbine (N2), EGT, torque, a governor and a real start sequence.

- Electrical bus, battery, generator, inverter, hydraulics, fuel, oil temperatures and pressures all exist and every caution light works.

Mission 1 teaches the complete procedure: cold start, take-off, a 6.8 km delivery flight east to Firebase Bravo, and landing.

Keep the COACH ON until you know the checklist. It always shows the next step and a hint.

## 2. Controls

- COLLECTIVE (far-left lever): rotor blade pitch. Up = climb, down = descend. Hover needs about 55-58 %.

- THROTTLE (twist grip, next to the collective): 0 = closed (fuel cut-off), 6-25 % = IDLE detent, 100 % = FULL OPEN. With GOV AUTO the governor holds rotor speed once the throttle is open.

- CYCLIC (far-right lever): forward tilts the rotor disc and the helicopter accelerates; aft slows it down. Double-tap the lever to centre it. With FORCE TRIM off the lever springs back to centre.

- PEDALS (LEFT / RIGHT buttons under the outside view): turn the helicopter. Heading changes the direction of travel; at 000/180 you face the camera and cannot move east-west.

- Torque reaction: more power pushes the nose to the right. Add LEFT pedal when you raise the collective.

- STARTER: press and hold. Switches: tap to toggle. The top bar has MENU, MANUAL and COACH.

## 3. Flight instruments

- AIRSPEED: knots. Green 40-100, yellow 100-124, red line 124 kt (Vne, never exceed).

- ATTITUDE: pitch attitude (2-D flight has no roll). Needs the INVERTER; otherwise it shows OFF.

- ALTITUDE: three-hand style: long hand = hundreds of feet, short hand = thousands. Base Alpha is 1017 ft, Firebase Bravo 860 ft MSL.

- VERTICAL SPEED: +-3000 ft/min with the usual lag of about 1.5 s.

- HEADING (RMI): rotating compass card; the cyan pointer shows the bearing to Firebase Bravo and the box shows the distance in nautical miles. Needs the INVERTER.

- TURN: needle shows yaw rate (marks = standard 3 deg/s). The ball shows slip caused by torque / pedals.

- RAD ALT: height above ground in feet (needs power). Yellow bug at 50 ft.

- CLOCK: mission time starting at 08:00.

## 4. Engine and system instruments

- TORQUE (psi): green up to 48, limit 50. Above 50 for more than 4 s damages the transmission (XMSN CHIP).

- TACH: white needle = rotor Nr, orange needle = engine N2. Operating range 91-100.5 % (294-324 rpm). Above 104.6 % is red.

- N1 (gas producer %): ground idle 63-66 %. Above 100 % is red.

- EGT (deg C): continuous limit 610, start limit 780. Above 780 for a moment = hot start, engine damaged (power reduced).

- FUEL: quantity in lb x100 plus fuel pressure (small needle). The 20 MIN FUEL light comes on at 150 lb.

- ENG OIL and XMSN OIL: pressure (left scale, white needle) and temperature (right scale, orange needle). Oil temperatures rise slowly; do not fly at full power with cold oil.

- DC: volts (left) and amps (right). Battery about 24 V; generator 28 V. During start the battery sags.

## 5. Caution panel

- ENG OIL PRESS / XMSN OIL PRESS: pressure low. XMSN OIL HOT: transmission oil above 110 C.

- ENG CHIP / XMSN CHIP: metal in the oil. Engine damaged / transmission over-torqued.

- 20 MIN FUEL: about 20 minutes of fuel left. Plan to land.

- DC GEN: generator not supplying power. INVERTER: inverter off. HYD PRESS: hydraulics off or low - controls are heavy.

- GOV EMER: governor in manual mode - you must set the rotor speed with the throttle.

- LOW RPM (with horn): rotor below 97 %. Lower the collective at once.

- ENGINE OUT: engine stopped in flight - autorotate. EGT HIGH: above 640 C. ROTOR HIGH: above 104 %.

## 6. Cold start checklist

1. BATT ON. 2. MAIN FUEL ON, START FUEL ON. 3. INVERTER ON. 4. Throttle fully CLOSED.

5. Press and HOLD STARTER. N1 rises (battery voltage drops - normal).

6. At N1 15 % roll the throttle to the IDLE detent (about 15 %). Light-off: EGT rises to about 550 C. If you open the throttle too early (N1 below about 10 %) EGT overshoots 780 C = hot start.

7. Keep holding STARTER until N1 reaches 40 %, then release. N1 settles at about 64 %.

8. START FUEL OFF. 9. GEN ON (volts 28, DC GEN light off). 10. HYD CONT ON.

11. Roll the throttle FULL OPEN. Rotor Nr rises to 100 %. Keep the collective DOWN.

12. Check: oil pressures green, EGT below 610, no caution lights. Then you are ready.

## 7. Take-off and hover

- Raise the collective slowly. At about 55 % the skids get light; at 57-58 % the helicopter lifts off.

- Add left pedal as power rises to hold the heading. Use small cyclic corrections: the hover is slightly unstable.

- Hover at 3-5 m for a moment. Torque for a hover is about 30 psi. Rotor must stay at 100 %.

- Ground effect: near the ground the rotor needs less power; just above it you may need more collective as you climb out.

- To depart: push the cyclic forward gently. The nose drops, the speed builds and translational lift improves the climb. Keep the rotor at 100 % and climb through 50 m.

## 8. Cruise and navigation

- Cruise at 80-100 kt. Never exceed 124 kt (Vne). Hold the altitude with the collective, the speed with the cyclic.

- Firebase Bravo is 6.8 km east of Base Alpha. Kilometre signs stand along the route. The heading card pointer and distance box show the way.

- Terrain: ridges at 2.6 km (+80 m) and 4.5 km (+55 m). Stay at least 50 m above the ground.

- Wind: about 7 kt from the west (the wind sock at the pads shows it). Gusts shake the aircraft.

- Fuel: about 560 lb per hour at cruise. You start with 780 lb.

## 9. Approach and landing

- Start slowing about 1 km before Bravo. Pull the cyclic back to reduce speed; lower the collective to keep a steady descent.

- Aim for the pad (+-18 m). Final approach at 30-40 kt, sink 300-500 ft/min.

- Flare at 10-15 m: nose up to kill the forward speed, then level the nose and cushion the touchdown with the collective.

- Successful landing: on the pad, sink rate below 300 ft/min (1.5 m/s), ground speed below 4 kt, stay down 3 seconds.

- Hard landing above 2.6 m/s sink (or 23 kt ground speed). Crash above 4.8 m/s sink, 43 kt ground speed, nose-up above 18 deg (tail strike), or hitting a hillside.

- Score: start-up 30, flight 30, landing 30, fuel 10 = 100.

## 10. Shutdown (practice)

1. Collective DOWN, throttle to IDLE.

2. Let the engine cool for two minutes (EGT and oil temperatures fall).

3. GEN OFF, INVERTER OFF, HYD OFF.

4. Throttle CLOSED (fuel cut-off). The rotor and N1 spin down slowly.

5. MAIN FUEL OFF, BATT OFF.

## 11. Emergencies

- ENGINE FAILURE: lower the collective immediately (within 1 s). Keep the rotor at 91-100 %. Glide at 60 kt (descent about 1500-1700 ft/min). Flare at 15-25 m and cushion with the collective.

- LOW RPM: lower the collective, check the throttle is full open and GOV is AUTO.

- GOVERNOR FAILURE (GOV EMER): hold rotor speed with the twist grip; move it slowly.

- HOT START: if EGT goes above 780, close the throttle at once. The engine may be damaged.

- HYDRAULIC FAILURE: the controls get heavy and less precise; land as soon as practical.

- OVER-TORQUE: reduce collective; do not stay above 50 psi.

- FUEL EXHAUSTED: the engine quits. Autorotate.

## 12. Aircraft data (UH-1H)

- Engine: Lycoming T53-L-13, 1,400 shp (derated to about 1,100 shp). Rotor: 2 blades, diameter 48 ft (14.6 m), 324 rpm.

- Weights: empty about 5,200 lb (2,365 kg); maximum gross 9,500 lb (4,310 kg). Fuel 1,300 lb (about 220 US gal).

- Speeds: Vne 124 kt; cruise about 100-110 kt. Service ceiling 12,600 ft. Length (fuselage) 12.8 m, height 4.4 m.

- Crew 2 + up to 11 troops. In this mission: crew 2 + 150 kg cargo.

- This simulator is an educational model. It is not a certified training device.

## Mission 1 checklist

1. BATTERY switch ON

   Switch is on the left of the switch panel (tap it).

2. MAIN FUEL ON and START FUEL ON

   Both fuel switches are needed: MAIN opens the valve, START feeds the igniter fuel.

3. INVERTER ON

   The inverter powers the attitude indicator and RMI.

4. Throttle CLOSED (twist grip fully down)

   The throttle slider is next to the collective. 0 = closed (cut-off).

5. Hold START until N1 reaches 15 %

   Press and HOLD the STARTER button. Battery voltage will sag - that is normal.

6. Open throttle to IDLE (about 15 %) - watch EGT

   Open the throttle slightly when N1 is 15 %. Too early (below about 10 %) = HOT START (EGT above 780 C).

7. Hold START to N1 40 %, release, wait for N1 about 64 %

   Keep holding START until 40 %. If you let go sooner the engine stalls.

8. START FUEL OFF

   After the engine is self-sustaining the start fuel must be turned off.

9. GEN ON - bus 28 V

   The generator takes over from the battery. DC GEN light goes out.

10. HYD CONT ON

   Hydraulics make the controls light. Without them the controls are heavy.

11. Roll throttle FULL OPEN - rotor to 100 %

   Take your time. The governor holds 100 %. Do NOT raise the collective yet.

12. Check gauges: oil pressures green, no cautions

   Look for: ENG OIL 40-70 psi, XMSN OIL about 50 psi, EGT under 610 C, rotor 100 %.

13. Raise collective slowly - lift off to a 3-5 m hover

   Hover needs about 55-58 % collective. Add a little left pedal as power rises.

14. Hover check for 5 seconds (torque, rotor 100 %)

   Keep the nose steady. Torque for a hover is about 30 psi.

15. Accelerate (forward cyclic) and climb above 50 m

   Push the cyclic forward gently; the nose drops and speed builds. Keep rotor at 100 %.

16. Cruise east to Firebase Bravo (6.8 km)

   Cruise 80-100 kt. Never exceed 124 kt (Vne). Hills at 2.6 km and 4.5 km.

17. Approach: slow below 25 kt, descend to the pad

   Flare by pulling the cyclic back. Lower the collective to keep a steady descent.

18. LAND on the pad: sink < 300 fpm, speed < 4 kt

   Level the nose, arrest the sink rate with collective just before touchdown.

