package com.hueysim.uh1;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

/** Real-time synthesis: turbine whine, two-bladed rotor slap ("whop-whop"), starter, wind, horn and touchdown thump. */
final class SoundEngine implements Runnable {
    static final int SR = 22050;
    volatile float n1, nr, load, speed;
    volatile boolean starter, horn, muted, ready;
    volatile float thumpReq;

    private AudioTrack track;
    private Thread thread;
    private volatile boolean alive;

    void start() {
        if (thread != null) return;
        try {
            int min = AudioTrack.getMinBufferSize(SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            track = new AudioTrack(AudioManager.STREAM_MUSIC, SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT, Math.max(min, 8192), AudioTrack.MODE_STREAM);
            track.play();
            alive = true;
            thread = new Thread(this, "huey-audio");
            thread.setDaemon(true);
            thread.start();
        } catch (Throwable t) { thread = null; }
    }

    void stop() {
        alive = false;
        try { if (thread != null) thread.join(300); } catch (Throwable t) { }
        thread = null;
        try { if (track != null) { track.stop(); track.release(); } } catch (Throwable t) { }
        track = null;
    }

    private int seed = 12345;

    private float noise() {
        seed = seed * 1103515245 + 12345;
        return ((seed >>> 8) & 0xFFFF) / 32768f - 1f;
    }

    public void run() {
        short[] buf = new short[1024];
        double turbPh = 0, turbPh2 = 0, slapT = 0, starterPh = 0, hornPh = 0, hornT = 0, thumpPh = 0, windLp = 0, lp = 0;
        float n1s = 0, nrs = 0, loadS = 0, spdS = 0, thumpEnv = 0, slapEnv = 0;
        double slapPhase = 0;
        while (alive) {
            n1s += (n1 - n1s) * 0.06f;
            nrs += (nr - nrs) * 0.06f;
            loadS += (load - loadS) * 0.05f;
            spdS += (speed - spdS) * 0.05f;
            if (thumpReq > 0) { thumpEnv = Math.max(thumpEnv, thumpReq); thumpReq = 0; }
            float vol = muted ? 0f : 1f;
            float n1n = Math.max(0, n1s / 100f), nrn = Math.max(0, nrs / 100f);
            double fTurb = 320 + n1n * 1500;
            double ampT = Math.pow(n1n, 1.4) * 0.16;
            double slapRate = 2 * 5.4 * nrn;                              // two blades
            double slapAmp = nrn * nrn * (0.20 + 0.55 * Math.min(1, loadS) + 0.25 * Math.min(1, spdS / 60.0));
            for (int i = 0; i < buf.length; i++) {
                double s = 0;
                // turbine whine + harmonics
                turbPh += 2 * Math.PI * fTurb / SR;
                turbPh2 += 2 * Math.PI * fTurb * 2.01 / SR;
                if (turbPh > 1e6) { turbPh -= 1e6 * 1; }
                s += ampT * (Math.sin(turbPh) + 0.35 * Math.sin(turbPh2));
                // broadband engine roar
                float nz = noise();
                lp += (nz - lp) * 0.18;
                s += lp * (0.05 + 0.20 * n1n * n1n);
                // rotor slap: pulse train with fast decay
                slapPhase += slapRate / SR;
                if (slapPhase >= 1) { slapPhase -= 1; slapEnv = 1f; }
                slapEnv *= 0.9965f - (float) (0.01 * nrn);
                s += slapAmp * slapEnv * (Math.sin(2 * Math.PI * 62 * slapT) * 0.8 + noise() * 0.5);
                slapT += 1.0 / SR;
                if (slapT > 100) slapT = 0;
                // starter
                if (starter) {
                    starterPh += 2 * Math.PI * (90 + n1n * 700) / SR;
                    s += 0.07 * Math.sin(starterPh) + 0.03 * noise();
                }
                // wind
                windLp += (noise() - windLp) * 0.04;
                s += windLp * Math.min(1, spdS / 70.0) * 0.25;
                // low rotor rpm horn
                if (horn) {
                    hornT += 1.0 / SR;
                    if (hornT > 0.5) hornT -= 0.5;
                    if (hornT < 0.28) { hornPh += 2 * Math.PI * 860 / SR; s += 0.16 * Math.signum(Math.sin(hornPh)); }
                }
                // touchdown thump
                if (thumpEnv > 0.001f) {
                    thumpPh += 2 * Math.PI * 48 / SR;
                    s += thumpEnv * 0.7 * Math.sin(thumpPh) + thumpEnv * 0.25 * noise();
                    thumpEnv *= 0.9992f;
                } else thumpPh = 0;
                double o = s * vol * 0.8;
                if (o > 1) o = 1; else if (o < -1) o = -1;
                buf[i] = (short) (o * 30000);
            }
            try { if (track != null) track.write(buf, 0, buf.length); else break; } catch (Throwable t) { break; }
        }
    }
}
