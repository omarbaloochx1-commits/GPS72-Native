package com.hueysim.uh1;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

/** The 4 x 4 instrument grid of the UH-1H panel. */
final class Panel {
    final Gauge[] g = new Gauge[16];
    final String[] names = {"ASI", "ADI", "ALT", "VSI", "HDG", "TURN", "CLOCK", "RADALT", "TORQ", "TACH", "N1", "EGT", "FUEL", "ENG OIL", "XMSN OIL", "VOLT/AMP"};
    private final RectF rf = new RectF();

    Panel() {
        g[0] = new ArcGauge("AIRSPEED", "KNOTS", 0, 160, 135, 270, 20, 10, 20, 1)
                .band(40, 100, GU.GREEN).band(100, 124, GU.YELLOW).red(124)
                .needle((s, e) -> s.ias, 0.80f, 0.045f, GU.WHITE);
        g[1] = new AdiGauge();
        g[2] = new ArcGauge("ALTITUDE", "FEET", 0, 10, -90, 360, 1, 0.5, 1, 1)
                .needle((s, e) -> (s.altFt() % 10000 + 10000) % 10000 / 1000.0, 0.50f, 0.075f, GU.ORANGE)
                .needle((s, e) -> (s.altFt() % 1000 + 1000) % 1000 / 100.0, 0.80f, 0.04f, GU.WHITE)
                .digital((s, e) -> s.altFt(), "%.0f", false);
        ((ArcGauge) g[2]).skipLast = true;
        g[3] = new VsiGauge();
        g[4] = new HsiGauge();
        g[5] = new TurnGauge();
        g[6] = new ArcGauge("CLOCK", null, 0, 12, -90, 360, 1, 0.2, 1, 1)
                .needle((s, e) -> (8 + e.clock / 3600.0) % 12, 0.50f, 0.07f, GU.WHITE)
                .needle((s, e) -> (e.clock / 300.0) % 12, 0.76f, 0.045f, GU.WHITE)
                .needle((s, e) -> (e.clock / 5.0) % 12, 0.82f, 0.02f, GU.ORANGE);
        ((ArcGauge) g[6]).skipLast = true;
        ((ArcGauge) g[6]).lab12 = true;
        g[7] = new RadAltGauge();
        g[8] = new ArcGauge("TORQUE", "PSI", 0, 60, 135, 270, 10, 5, 10, 1)
                .band(0, 48, GU.GREEN).band(48, 50, GU.YELLOW).band(50, 60, GU.RED).red(50)
                .needle((s, e) -> s.torque, 0.80f, 0.045f, GU.WHITE)
                .digital((s, e) -> s.torque, "%.0f", false);
        g[9] = new ArcGauge("ENG / ROTOR", "RPM %", 0, 130, 135, 270, 10, 5, 20, 1)
                .band(70, 91, GU.YELLOW).band(91, 100.5, GU.GREEN).band(100.5, 104.6, GU.YELLOW).band(104.6, 130, GU.RED).red(104.6)
                .needle((s, e) -> s.n2, 0.84f, 0.03f, GU.ORANGE)
                .needle((s, e) -> s.nr, 0.78f, 0.05f, GU.WHITE)
                .digital((s, e) -> s.nr, "%.0f", false);
        g[10] = new ArcGauge("N1", "GAS PROD %", 0, 110, 135, 270, 10, 5, 20, 1)
                .band(60, 100, GU.GREEN).band(100, 102, GU.YELLOW).band(102, 110, GU.RED).red(102)
                .needle((s, e) -> s.n1, 0.80f, 0.045f, GU.WHITE)
                .digital((s, e) -> s.n1, "%.1f", false);
        g[11] = new ArcGauge("EGT", "DEG C x100", 0, 1000, 135, 270, 100, 50, 200, 100)
                .band(250, 610, GU.GREEN).band(610, 780, GU.YELLOW).band(780, 1000, GU.RED).red(780)
                .needle((s, e) -> s.egt, 0.80f, 0.045f, GU.WHITE)
                .digital((s, e) -> s.egt, "%.0f", false);
        g[12] = new ArcGauge("FUEL QTY", "LB x100", 0, 1400, 135, 270, 200, 100, 200, 100).powered()
                .band(0, 150, GU.RED).band(300, 1400, GU.GREEN)
                .needle2((s, e) -> s.fuelP, 0, 30, 0.40f, 0.05f, GU.ORANGE)
                .needle((s, e) -> s.fuelLb, 0.80f, 0.045f, GU.WHITE)
                .digital((s, e) -> s.fuelLb, "%.0f", true);
        g[13] = new DualGauge("ENG OIL", "PSI", "DEG C", 0, 100, 20, 1, 0, 150, 50, 1, (s, e) -> s.engOilP, (s, e) -> s.engOilT, true)
                .band(true, 0, 25, GU.RED).band(true, 40, 80, GU.GREEN).band(true, 80, 100, GU.YELLOW)
                .band(false, 30, 100, GU.GREEN).band(false, 100, 110, GU.YELLOW).band(false, 110, 150, GU.RED);
        g[14] = new DualGauge("XMSN OIL", "PSI", "DEG C", 0, 100, 20, 1, 0, 150, 50, 1, (s, e) -> s.xmsnOilP, (s, e) -> s.xmsnOilT, true)
                .band(true, 0, 20, GU.RED).band(true, 40, 70, GU.GREEN).band(true, 70, 100, GU.YELLOW)
                .band(false, 30, 110, GU.GREEN).band(false, 110, 150, GU.RED);
        g[15] = new DualGauge("DC", "VOLTS", "AMPS", 18, 32, 2, 1, -100, 100, 50, 1, (s, e) -> s.busV, (s, e) -> s.amps, true)
                .band(true, 24, 29.5, GU.GREEN).band(true, 18, 22, GU.RED)
                .band(false, -100, -50, GU.YELLOW).band(false, 0, 100, GU.GREEN);
    }

    /** Cell rectangle of gauge i inside the panel area (4 columns x 4 rows). */
    void cell(RectF area, int i, RectF out) {
        float cw = area.width() / 4f, ch = area.height() / 4f;
        int col = i % 4, row = i / 4;
        out.set(area.left + col * cw, area.top + row * ch, area.left + (col + 1) * cw, area.top + (row + 1) * ch);
    }

    void draw(Canvas c, RectF area, Sim s, GaugeEnv e, Paint p) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF121416);
        c.drawRoundRect(area, 14, 14, p);
        for (int i = 0; i < 16; i++) {
            cell(area, i, rf);
            float r = Math.min(rf.width(), rf.height()) * 0.5f * 0.94f;
            g[i].draw(c, rf.centerX(), rf.centerY(), r, s, e, p);
        }
    }
}
