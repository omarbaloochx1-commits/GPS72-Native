package com.hueysim.uh1;

/** Mission 1: cold start, take-off, delivery flight to Firebase Bravo and landing. */
final class Mission {
    static final int N = 18;

    static final String[] EN = {
        "BATTERY switch ON",
        "MAIN FUEL ON and START FUEL ON",
        "INVERTER ON",
        "Throttle CLOSED (twist grip fully down)",
        "Hold START until N1 reaches 15 %",
        "Open throttle to IDLE (about 15 %) - watch EGT",
        "Hold START to N1 40 %, release, wait for N1 about 64 %",
        "START FUEL OFF",
        "GEN ON - bus 28 V",
        "HYD CONT ON",
        "Roll throttle FULL OPEN - rotor to 100 %",
        "Check gauges: oil pressures green, no cautions",
        "Raise collective slowly - lift off to a 3-5 m hover",
        "Hover check for 5 seconds (torque, rotor 100 %)",
        "Accelerate (forward cyclic) and climb above 50 m",
        "Cruise east to Firebase Bravo (6.8 km)",
        "Approach: slow below 25 kt, descend to the pad",
        "LAND on the pad: sink < 300 fpm, speed < 4 kt"
    };
    static final String[] FA = {
        "کلید BATTERY را روشن کنید",
        "کلیدهای MAIN FUEL و START FUEL را روشن کنید",
        "کلید INVERTER را روشن کنید",
        "دسته گاز (Throttle) را کاملاً ببندید (پایین)",
        "دکمهٔ START را نگه دارید تا N1 به ۱۵٪ برسد",
        "گاز را روی IDLE (حدود ۱۵٪) بیاورید - EGT را ببینید",
        "START را تا N1 برابر ۴۰٪ نگه دارید، رها کنید، تا N1 حدود ۶۴٪",
        "START FUEL را خاموش کنید",
        "GEN را روشن کنید - ولتاژ ۲۸ ولت",
        "HYD CONT را روشن کنید",
        "گاز را کامل باز کنید - دور روتور به ۱۰۰٪",
        "ابزارها را چک کنید: فشار روغن سبز، بدون هشدار",
        "کلکتیو را آرام بالا ببرید - بلند شوید و در ارتفاع ۳ تا ۵ متر هاور کنید",
        "۵ ثانیه هاور: گشتاور و دور روتور ۱۰۰٪ را چک کنید",
        "با سیکلیک جلو شتاب بگیرید و بالای ۵۰ متر صعود کنید",
        "به سمت شرق، تا فایربیس براوو (۶٫۸ کیلومتر) پرواز کنید",
        "نزدیک شدن: سرعت زیر ۲۵ نات، فرود به سمت پد",
        "روی پد بنشینید: نرخ فرود < ۳۰۰ فوت/دقیقه، سرعت < ۴ نات"
    };
    static final String[] HINT_EN = {
        "Switch is on the left of the switch panel (tap it).",
        "Both fuel switches are needed: MAIN opens the valve, START feeds the igniter fuel.",
        "The inverter powers the attitude indicator and RMI.",
        "The throttle slider is next to the collective. 0 = closed (cut-off).",
        "Press and HOLD the STARTER button. Battery voltage will sag - that is normal.",
        "Open the throttle slightly when N1 is 15 %. Too early (below about 10 %) = HOT START (EGT above 780 C).",
        "Keep holding START until 40 %. If you let go sooner the engine stalls.",
        "After the engine is self-sustaining the start fuel must be turned off.",
        "The generator takes over from the battery. DC GEN light goes out.",
        "Hydraulics make the controls light. Without them the controls are heavy.",
        "Take your time. The governor holds 100 %. Do NOT raise the collective yet.",
        "Look for: ENG OIL 40-70 psi, XMSN OIL about 50 psi, EGT under 610 C, rotor 100 %.",
        "Hover needs about 55-58 % collective. Add a little left pedal as power rises.",
        "Keep the nose steady. Torque for a hover is about 30 psi.",
        "Push the cyclic forward gently; the nose drops and speed builds. Keep rotor at 100 %.",
        "Cruise 80-100 kt. Never exceed 124 kt (Vne). Hills at 2.6 km and 4.5 km.",
        "Flare by pulling the cyclic back. Lower the collective to keep a steady descent.",
        "Level the nose, arrest the sink rate with collective just before touchdown."
    };
    static final String[] HINT_FA = {
        "کلید در سمت چپ پنل کلیدها است (لمس کنید).",
        "هر دو لازم‌اند: MAIN شیر سوخت را باز می‌کند و START سوخت جرقه‌زن را می‌دهد.",
        "اینورتر برق شاخص وضعیت (ADI) و RMI را تأمین می‌کند.",
        "اسلایدر گاز کنار کلکتیو است. صفر = بسته (قطع سوخت).",
        "دکمهٔ STARTER را بزنید و نگه دارید. افت ولتاژ باتری طبیعی است.",
        "وقتی N1 به ۱۵٪ رسید گاز را کمی باز کنید. خیلی زود (زیر حدود ۱۰٪) = استارت داغ (EGT بالای ۷۸۰).",
        "تا ۴۰٪ نگه دارید. اگر زودتر رها کنید موتور خفه می‌شود.",
        "وقتی موتور خودکفا شد، سوخت استارت باید خاموش شود.",
        "ژنراتور جای باتری را می‌گیرد. چراغ DC GEN خاموش می‌شود.",
        "هیدرولیک کنترل‌ها را سبک می‌کند. بدون آن کنترل‌ها سنگین‌اند.",
        "عجله نکنید. گاورنر دور را روی ۱۰۰٪ نگه می‌دارد. هنوز کلکتیو را بالا نبرید.",
        "بررسی: فشار روغن موتور ۴۰ تا ۷۰، فشار روغن گیربکس حدود ۵۰، EGT زیر ۶۱۰، دور روتور ۱۰۰٪.",
        "هاور حدود ۵۵ تا ۵۸٪ کلکتیو می‌خواهد. با بالا رفتن قدرت کمی پدال چپ بدهید.",
        "دماغه را ثابت نگه دارید. گشتاور هاور حدود ۳۰ psi است.",
        "سیکلیک را آرام جلو ببرید؛ دماغه پایین می‌آید و سرعت زیاد می‌شود. دور روتور ۱۰۰٪ بماند.",
        "سرعت کروز ۸۰ تا ۱۰۰ نات. هرگز از ۱۲۴ نات (Vne) بیشتر نشوید. تپه‌ها در ۲٫۶ و ۴٫۵ کیلومتری.",
        "با کشیدن سیکلیک به عقب فلر کنید. کلکتیو را پایین بیاورید تا نزول یکنواخت بماند.",
        "دماغه را تراز کنید و درست قبل از تماس با کلکتیو نرخ فرود را بگیرید."
    };

    int step;
    boolean complete, failed;
    String failMsg = "";
    double hoverT, landedT, checkT;
    double score, sStart, sFlight, sLand, sFuel;
    String rating = "";
    boolean scored;

    void reset() {
        step = 0; complete = failed = scored = false; failMsg = ""; hoverT = landedT = checkT = 0;
        score = sStart = sFlight = sLand = sFuel = 0; rating = "";
    }

    double distToBravo(Sim s) { return Terrain.PAD_B_X - s.x; }

    private boolean ok(int i, Sim s, double dt) {
        switch (i) {
            case 0: return s.batt;
            case 1: return s.fuelMain && s.fuelStart;
            case 2: return s.inverter;
            case 3: return s.throttle < 0.04 || s.lit;
            case 4: return s.n1 >= 15 || s.lit;
            case 5: return s.lit;
            case 6: return s.lit && s.n1 >= 62 && !s.starterBtn;
            case 7: return s.lit && !s.fuelStart;
            case 8: return s.genOnline;
            case 9: return s.hyd;
            case 10: return s.throttle > 0.95 && s.nr >= 98;
            case 11: {
                boolean good = s.engOilP >= 38 && s.xmsnOilP >= 38 && s.egt < 610 && s.nr >= 98;
                for (int k = 0; k < Sim.NL; k++) if (s.light[k]) good = false;
                checkT = good ? checkT + dt : 0;
                return checkT > 2.0;
            }
            case 12: return !s.onGround && s.agl >= 2.0;
            case 13: {
                boolean hov = !s.onGround && s.agl >= 1.5 && s.agl <= 9 && Math.abs(s.vx) < 2.5 && s.nr > 96;
                hoverT = hov ? hoverT + dt : Math.max(0, hoverT - dt);
                return hoverT >= 5;
            }
            case 14: return s.agl >= 50 && s.ias >= 20;
            case 15: return s.x >= Terrain.PAD_B_X - 1000;
            case 16: return Math.abs(distToBravo(s)) < 250 && s.ias < 25 && s.agl < 60;
            case 17: {
                boolean down = s.onGround && Math.abs(s.x - Terrain.PAD_B_X) <= Terrain.PAD_HALF + 4 && Math.abs(s.vx) < 1.0;
                landedT = down ? landedT + dt : 0;
                return landedT >= 3;
            }
            default: return false;
        }
    }

    /** Advances the checklist; returns true while the mission is running. */
    void update(Sim s, double dt) {
        if (complete || failed) return;
        if (s.crashed) { failed = true; failMsg = s.crashMsg; return; }
        // a step is satisfied as soon as its condition holds (steps can be done in advance)
        int guard = 0;
        while (step < N && guard++ < N * 2) {
            if (ok(step, s, dt)) { step++; continue; }
            // flight steps may be skipped when the pilot is already further along (for example no hover check)
            boolean jumped = false;
            for (int j = 16; j > step && j >= 14; j--) if (ok(j, s, 0)) { step = j + 1; jumped = true; break; }
            if (!jumped) break;
        }
        if (step >= N) { complete = true; computeScore(s); }
    }

    void computeScore(Sim s) {
        if (scored) return;
        scored = true;
        sStart = 30;
        if (s.hotStart || s.engDamaged) sStart -= 18;
        if (s.battCharge < 0.45) sStart -= 4;
        sStart = Math.max(0, sStart);
        sFlight = 30;
        sFlight -= Math.min(10, s.lowRpmTime * 2);
        sFlight -= Math.min(6, s.highRpmTime * 2);
        sFlight -= Math.min(6, s.vneTime * 3);
        sFlight -= Math.min(8, s.overTorqueTime * 1.0);
        if (s.xmsnDamaged) sFlight -= 6;
        sFlight = Math.max(0, sFlight);
        double dx = Math.abs(s.x - Terrain.PAD_B_X);
        double prec = 10 * (1 - Math.min(1, dx / Terrain.PAD_HALF));
        double soft = s.touchVz <= 0.5 ? 10 : (s.touchVz <= 1.5 ? 10 - (s.touchVz - 0.5) * 5 : Math.max(0, 5 - (s.touchVz - 1.5) * 4.5));
        double spd = s.touchSpeed <= 1 ? 10 : Math.max(0, 10 - (s.touchSpeed - 1) * 2);
        sLand = prec + soft + spd;
        if (s.hardLanding) sLand -= 6;
        if (s.tailStrike) sLand -= 4;
        sLand = Math.max(0, Math.min(30, sLand));
        sFuel = Math.max(0, Math.min(10, (s.fuelLb - 480) / 22.0));
        score = Math.round(sStart + sFlight + sLand + sFuel);
        rating = score >= 90 ? "ACE" : score >= 75 ? "PILOT" : score >= 55 ? "TRAINEE" : "ROOKIE";
    }
}
