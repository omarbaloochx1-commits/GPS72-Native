package com.hueysim.uh1;

/** East-west terrain profile of the training area (metres above sea level) and the two helipads. */
final class Terrain {
    private Terrain() { }

    static final double PAD_A_X = 0, PAD_A_ELEV = 310;       // Base Alpha
    static final double PAD_B_X = 6800, PAD_B_ELEV = 262;    // Firebase Bravo
    static final double PAD_HALF = 18;                       // pad half width (m)

    private static double smooth(double e0, double e1, double v) {
        double t = Math.max(0, Math.min(1, (v - e0) / (e1 - e0)));
        return t * t * (3 - 2 * t);
    }

    private static double raw(double x) {
        double t = Math.max(0, Math.min(1, x / 6800.0));
        double h = 310 - 48 * t;
        double mid = smooth(250, 900, x) * (1 - smooth(5900, 6600, x));
        h += mid * 34 * Math.sin(x / 520.0 + 0.6);
        h += 82 * Math.exp(-sq((x - 2600) / 280.0));
        h += 55 * Math.exp(-sq((x - 4500) / 360.0));
        h += mid * (2.6 * Math.sin(x / 37.0) + 1.4 * Math.sin(x / 11.0));
        if (x < 0) h += Math.min(60, -x * 0.05);
        if (x > 7000) h += Math.min(80, (x - 7000) * 0.04);
        return h;
    }

    private static double sq(double v) { return v * v; }

    static double h(double x) {
        double w1 = smooth(PAD_HALF, PAD_HALF + 70, Math.abs(x - PAD_A_X));
        double w2 = smooth(PAD_HALF, PAD_HALF + 70, Math.abs(x - PAD_B_X));
        double r = raw(x);
        double a = PAD_A_ELEV + (r - PAD_A_ELEV) * w1;
        double b = PAD_B_ELEV + (r - PAD_B_ELEV) * w2;
        return Math.abs(x - PAD_B_X) < Math.abs(x - PAD_A_X) ? b : a;
    }

    static double slope(double x) { return (h(x + 2) - h(x - 2)) / 4.0; }

    /** Deterministic tree density: returns tree height (m) at index i or 0 for none. */
    static double tree(int i) {
        int n = i * 73856093 ^ 19349663;
        n ^= n >>> 13; n *= 0x5bd1e995; n ^= n >>> 15;
        int r = n & 0xff;
        double x = i * 14.0;
        if (Math.abs(x - PAD_A_X) < 90 || Math.abs(x - PAD_B_X) < 90) return 0;
        double dense = smooth(300, 1200, x) * (1 - smooth(6000, 6600, x));
        if (r > 40 + 120 * dense) return 0;
        return 5 + (r % 9);
    }
}
