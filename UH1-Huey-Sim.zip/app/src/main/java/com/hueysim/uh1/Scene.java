package com.hueysim.uh1;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import java.util.Locale;
import java.util.Random;

/** Outside view: a vertical east-west slice of the world with the UH-1H in side view. */
final class Scene {
    float camX, camY, zoom = 10f;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private final Random rnd = new Random(11);
    private boolean camInit;

    // particles: dust (type 0) and exhaust smoke (type 1)
    private static final int MAXP = 90;
    private final float[] px = new float[MAXP], py = new float[MAXP], pvx = new float[MAXP], pvy = new float[MAXP], plife = new float[MAXP], psz = new float[MAXP];
    private final int[] ptype = new int[MAXP];
    private int pc;
    private double clock;

    private float ax, ay, aw, ah;     // current area

    float sx(double wx) { return ax + aw * 0.45f + (float) (wx - camX) * zoom; }

    float sy(double wy) { return ay + ah * 0.58f - (float) (wy - camY) * zoom; }

    void reset(Sim s) { camInit = false; pc = 0; }

    void update(Sim s, double dt) {
        clock += dt;
        if (!camInit) { camX = (float) s.x; camY = (float) s.alt + 2; camInit = true; }
        float k = (float) (1 - Math.exp(-dt * 5));
        camX += ((float) (s.x + s.vx * 0.5) - camX) * k;
        camY += ((float) (s.alt + 3) - camY) * (float) (1 - Math.exp(-dt * 3));
        double agl = Math.max(0, s.agl);
        float zt = (float) (13.0 / (1 + agl / 80.0 + Math.abs(s.vx) / 50.0));
        zoom += (Math.max(3.2f, Math.min(13f, zt)) - zoom) * (float) (1 - Math.exp(-dt * 1.5));

        // particles
        float nrN = (float) (s.nr / 100.0);
        if (s.agl < 14 && nrN > 0.7f && s.thrustN > s.massKg() * Sim.G * 0.5 && !s.crashed) {
            int n = (int) (rnd.nextFloat() * 3 * (1 - s.agl / 14.0) + 0.5);
            for (int i = 0; i < n; i++) addP(0, (float) (s.x + (rnd.nextFloat() - 0.5f) * 8), (float) Terrain.h(s.x), (rnd.nextFloat() - 0.5f) * 16, 1 + rnd.nextFloat() * 2, 1.4f, 1.4f + rnd.nextFloat() * 1.8f);
        }
        if (s.lit && s.egt > 430 && rnd.nextFloat() < dt * 22) {
            float face = (float) Math.signum(Math.sin(Math.toRadians(s.hdg)));
            addP(1, (float) (s.x - face * 0.9), (float) (s.alt + 2.9), -face * (2 + rnd.nextFloat() * 3), 1.5f + rnd.nextFloat(), 1.8f, 0.5f + (float) (s.egt - 400) / 600f);
        }
        for (int i = 0; i < pc; i++) {
            plife[i] -= (float) dt;
            px[i] += pvx[i] * (float) dt;
            py[i] += pvy[i] * (float) dt;
            if (ptype[i] == 0) { pvx[i] *= 0.985f; if (py[i] < Terrain.h(px[i])) { py[i] = (float) Terrain.h(px[i]); } pvy[i] *= 0.98f; }
            else { pvy[i] += 0.8f * (float) dt; pvx[i] *= 0.99f; }
        }
        for (int i = pc - 1; i >= 0; i--) if (plife[i] <= 0) removeP(i);
    }

    private void addP(int type, float x, float y, float vx, float vy, float life, float size) {
        if (pc >= MAXP) return;
        px[pc] = x; py[pc] = y; pvx[pc] = vx; pvy[pc] = vy; plife[pc] = life; psz[pc] = size; ptype[pc] = type; pc++;
    }

    private void removeP(int i) {
        pc--;
        px[i] = px[pc]; py[i] = py[pc]; pvx[i] = pvx[pc]; pvy[i] = pvy[pc]; plife[i] = plife[pc]; psz[i] = psz[pc]; ptype[i] = ptype[pc];
    }

    // ------------------------------------------------------------------ drawing
    void draw(Canvas c, RectF a, Sim s, GaugeEnv e) {
        ax = a.left; ay = a.top; aw = a.width(); ah = a.height();
        c.save();
        c.clipRect(a);
        drawSky(c, a);
        drawMountains(c, a);
        drawTerrain(c, a);
        drawStructures(c, a, s);
        drawShadow(c, s);
        drawParticles(c, s, 0);
        drawHuey(c, s, e);
        drawParticles(c, s, 1);
        c.restore();
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3);
        p.setColor(0xFF2A2C30);
        c.drawRect(a, p);
    }

    private void drawSky(Canvas c, RectF a) {
        p.setShader(new LinearGradient(0, a.top, 0, a.bottom, new int[]{0xFF2F6DB4, 0xFF7FB1DE, 0xFFD6E6EE, 0xFFF0DDB8}, new float[]{0f, 0.45f, 0.78f, 1f}, Shader.TileMode.CLAMP));
        p.setStyle(Paint.Style.FILL);
        c.drawRect(a, p);
        p.setShader(null);
        // sun with glow (morning, low in the east)
        float sxs = a.left + a.width() * 0.82f - camX * 0.002f * zoom, sys = a.top + a.height() * 0.30f;
        p.setShader(new RadialGradient(sxs, sys, a.height() * 0.28f, new int[]{0xCCFFF3C4, 0x44FFE9A8, 0x00FFE9A8}, new float[]{0f, 0.35f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(sxs, sys, a.height() * 0.28f, p);
        p.setShader(null);
        p.setColor(0xFFFFFBE6);
        c.drawCircle(sxs, sys, a.height() * 0.035f, p);
        // clouds
        float span = a.width() * 3.0f;
        for (int i = 0; i < 9; i++) {
            float baseX = i * span / 9f;
            float x = a.left + mod(baseX - camX * zoom * 0.04f, span) - span * 0.12f;
            float y = a.top + a.height() * (0.07f + 0.30f * frac(i * 0.381f));
            float w = a.width() * (0.10f + 0.07f * frac(i * 0.77f));
            p.setColor(0xCCFFFFFF);
            rf.set(x, y, x + w, y + w * 0.22f);
            c.drawOval(rf, p);
            rf.set(x + w * 0.2f, y - w * 0.10f, x + w * 0.65f, y + w * 0.18f);
            c.drawOval(rf, p);
            rf.set(x + w * 0.45f, y - w * 0.04f, x + w * 0.95f, y + w * 0.22f);
            c.drawOval(rf, p);
        }
    }

    private void drawMountains(Canvas c, RectF a) {
        float horizon = sy(Terrain.h(camX)) - 6 * zoom;
        horizon = Math.min(a.bottom - a.height() * 0.15f, Math.max(a.top + a.height() * 0.35f, horizon));
        for (int layer = 0; layer < 2; layer++) {
            float par = layer == 0 ? 0.015f : 0.035f;
            float amp = a.height() * (layer == 0 ? 0.20f : 0.12f);
            p.setColor(layer == 0 ? 0xFF8EA7BE : 0xFF6F8B7A);
            path.reset();
            path.moveTo(a.left, a.bottom);
            for (float x = a.left; x <= a.right + 16; x += 16) {
                float u = x + camX * zoom * par;
                float h = (float) (0.5 + 0.28 * Math.sin(u * 0.0042 + layer * 2.0) + 0.17 * Math.sin(u * 0.011 + 1.3 * layer) + 0.08 * Math.sin(u * 0.027));
                path.lineTo(x, horizon + 4 - amp * h + (layer == 1 ? 14 : 0));
            }
            path.lineTo(a.right, a.bottom);
            path.close();
            c.drawPath(path, p);
        }
    }

    private void drawTerrain(Canvas c, RectF a) {
        path.reset();
        path.moveTo(a.left, a.bottom + 2);
        for (float x = a.left; x <= a.right + 6; x += 6) path.lineTo(x, sy(Terrain.h(camX + (x - ax - aw * 0.45f) / zoom)));
        path.lineTo(a.right + 6, a.bottom + 2);
        path.close();
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, a.top + a.height() * 0.45f, 0, a.bottom, new int[]{0xFF6C9A4A, 0xFF4F7A39, 0xFF38552A}, new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        c.drawPath(path, p);
        p.setShader(null);
        // surface edge
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2, zoom * 0.18f));
        p.setColor(0xFF8DBE62);
        path.reset();
        boolean first = true;
        for (float x = a.left; x <= a.right + 6; x += 6) {
            float y = sy(Terrain.h(camX + (x - ax - aw * 0.45f) / zoom));
            if (first) { path.moveTo(x, y); first = false; } else path.lineTo(x, y);
        }
        c.drawPath(path, p);
        p.setStyle(Paint.Style.FILL);
        // trees
        double half = aw / zoom * 0.7;
        int i0 = (int) Math.floor((camX - half) / 14.0), i1 = (int) Math.ceil((camX + half) / 14.0);
        for (int i = i0; i <= i1; i++) {
            double th = Terrain.tree(i);
            if (th <= 0) continue;
            double wx = i * 14.0 + (i * 7 % 5);
            float bx = sx(wx), by = sy(Terrain.h(wx));
            float hh = (float) th * zoom, ww = hh * 0.38f;
            p.setColor(0xFF4B3A28);
            c.drawRect(bx - hh * 0.04f, by - hh * 0.25f, bx + hh * 0.04f, by + 1, p);
            p.setColor(((int) th) % 2 == 0 ? 0xFF2E6A3A : 0xFF3A7A40);
            path.reset();
            path.moveTo(bx, by - hh);
            path.lineTo(bx + ww, by - hh * 0.22f);
            path.lineTo(bx - ww, by - hh * 0.22f);
            path.close();
            c.drawPath(path, p);
        }
    }

    private void drawStructures(Canvas c, RectF a, Sim s) {
        drawPad(c, Terrain.PAD_A_X, Terrain.PAD_A_ELEV, "BASE ALPHA");
        drawPad(c, Terrain.PAD_B_X, Terrain.PAD_B_ELEV, "FIREBASE BRAVO");
        // Alpha: hangar and fuel tanks
        float hx = sx(-95), hy = sy(Terrain.h(-95));
        p.setColor(0xFF7C8084);
        c.drawRect(hx - 18 * zoom, hy - 8 * zoom, hx + 18 * zoom, hy, p);
        p.setColor(0xFF5A5E62);
        path.reset();
        path.moveTo(hx - 19 * zoom, hy - 8 * zoom);
        path.lineTo(hx, hy - 12 * zoom);
        path.lineTo(hx + 19 * zoom, hy - 8 * zoom);
        path.close();
        c.drawPath(path, p);
        p.setColor(0xFF2A2C30);
        c.drawRect(hx - 8 * zoom, hy - 6 * zoom, hx + 8 * zoom, hy, p);
        // Bravo: tents, mast
        float tx = sx(Terrain.PAD_B_X + 70), ty = sy(Terrain.h(Terrain.PAD_B_X + 70));
        for (int i = 0; i < 3; i++) {
            float x = tx + i * 11 * zoom;
            p.setColor(i == 1 ? 0xFF6B7A4A : 0xFF59663D);
            path.reset();
            path.moveTo(x - 4.5f * zoom, ty);
            path.lineTo(x, ty - 4.2f * zoom);
            path.lineTo(x + 4.5f * zoom, ty);
            path.close();
            c.drawPath(path, p);
        }
        float mx = sx(Terrain.PAD_B_X - 85), my = sy(Terrain.h(Terrain.PAD_B_X - 85));
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2, zoom * 0.3f));
        p.setColor(0xFFB8BCC0);
        c.drawLine(mx, my, mx, my - 22 * zoom, p);
        p.setStyle(Paint.Style.FILL);
        if (((int) (clock * 1.4)) % 2 == 0) { p.setColor(0xFFFF3030); c.drawCircle(mx, my - 22 * zoom, Math.max(3, zoom * 0.5f), p); }
        // kilometre posts
        p.setTextAlign(Paint.Align.CENTER);
        for (int k = 1; k <= 6; k++) {
            double wx = k * 1000.0;
            float x = sx(wx);
            if (x < ax - 50 || x > ax + aw + 50) continue;
            float y = sy(Terrain.h(wx));
            p.setColor(0xFFE8E8E8);
            c.drawRect(x - 2, y - 5 * zoom, x + 2, y, p);
            p.setColor(0xFFFFD21F);
            c.drawRect(x - 4 * zoom, y - 8 * zoom, x + 4 * zoom, y - 5 * zoom, p);
            GU.text(c, p, k + " km", x, y - 6.5f * zoom, Math.max(10, zoom * 1.9f), 0xFF202020, Paint.Align.CENTER, true);
        }
    }

    private void drawPad(Canvas c, double wx, double elev, String name) {
        float x0 = sx(wx - Terrain.PAD_HALF), x1 = sx(wx + Terrain.PAD_HALF), y = sy(elev);
        if (x1 < ax - 100 || x0 > ax + aw + 100) return;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF9A9C9E);
        c.drawRect(x0, y - 0.4f * zoom, x1, y + 0.5f * zoom, p);
        p.setColor(0xFFF2C21B);
        c.drawRect(x0, y - 0.4f * zoom, x0 + 0.5f * zoom, y, p);
        c.drawRect(x1 - 0.5f * zoom, y - 0.4f * zoom, x1, y, p);
        float cx = (x0 + x1) / 2;
        GU.text(c, p, "H", cx, y - 0.2f * zoom, Math.max(8, zoom * 2.6f), 0xFFFFFFFF, Paint.Align.CENTER, true);
        // wind sock
        float wxp = x1 + 6 * zoom;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2, zoom * 0.25f));
        p.setColor(0xFFDDDDDD);
        c.drawLine(wxp, y, wxp, y - 7 * zoom, p);
        p.setStyle(Paint.Style.FILL);
        double w = windNow;
        float dir = w >= 0 ? 1 : -1;
        float droop = (float) Math.max(0, 1 - Math.abs(w) / 7.0) * 55;
        for (int i = 0; i < 4; i++) {
            float segX = wxp + dir * (i + 0.5f) * 1.1f * zoom * (float) Math.cos(Math.toRadians(droop));
            float segY = y - 7 * zoom + (i + 0.5f) * 1.1f * zoom * (float) Math.sin(Math.toRadians(droop));
            p.setColor(i % 2 == 0 ? 0xFFFF7A1F : 0xFFFFFFFF);
            rf.set(segX - 0.6f * zoom, segY - (0.55f - i * 0.08f) * zoom, segX + 0.6f * zoom, segY + (0.55f - i * 0.08f) * zoom);
            c.drawRect(rf, p);
        }
        // pad name sign
        p.setColor(0xFF1C1E20);
        c.drawRect(cx - 12 * zoom, y - 9 * zoom, cx + 12 * zoom, y - 5.4f * zoom, p);
        GU.text(c, p, name, cx, y - 7.2f * zoom, Math.max(9, zoom * 1.5f), 0xFFFFFFFF, Paint.Align.CENTER, true);
    }

    double windNow;

    private void drawShadow(Canvas c, Sim s) {
        double gh = Terrain.h(s.x);
        float a = (float) Math.max(0, 0.45 - s.agl / 60.0);
        if (a <= 0) return;
        p.setStyle(Paint.Style.FILL);
        p.setColor((int) (a * 255) << 24);
        float cx = sx(s.x), cy = sy(gh);
        rf.set(cx - 7 * zoom, cy - 0.25f * zoom, cx + 7 * zoom, cy + 0.35f * zoom);
        c.drawOval(rf, p);
    }

    private void drawParticles(Canvas c, Sim s, int type) {
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < pc; i++) {
            if (ptype[i] != type) continue;
            float t = Math.max(0, Math.min(1, plife[i] / 1.6f));
            float rr = psz[i] * zoom * (type == 0 ? (1.2f - 0.5f * t) : (0.7f + (1 - t)));
            if (type == 0) p.setColor((int) (t * 130) << 24 | 0xC9B58A);
            else p.setColor((int) (t * 150) << 24 | 0x303030);
            c.drawCircle(sx(px[i]), sy(py[i]), Math.max(1.5f, rr * 0.5f), p);
        }
    }

    // ------------------------------------------------------------------ helicopter
    private void poly(Canvas c, float[] pts, int color) {
        path.reset();
        path.moveTo(pts[0], pts[1]);
        for (int i = 2; i < pts.length; i += 2) path.lineTo(pts[i], pts[i + 1]);
        path.close();
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.drawPath(path, p);
    }

    private void drawHuey(Canvas c, Sim s, GaugeEnv e) {
        float face = (float) Math.sin(Math.toRadians(s.hdg));
        float sgn = face >= 0 ? 1 : -1;
        float sxs = sgn * Math.max(0.16f, Math.abs(face));
        float u = zoom;                                   // pixels per metre
        c.save();
        c.translate(sx(s.x), sy(s.alt));
        c.scale(sxs, 1f);
        c.rotate((float) -Math.toDegrees(s.pitch));
        // everything below in metres relative to the skid bottom, x forward, y up = negative
        c.save();
        c.scale(u, u);
        float nrN = (float) (s.nr / 100.0);
        // --- skids
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(0.16f);
        p.setColor(0xFF1E1F21);
        c.drawLine(-2.3f, -0.12f, 2.1f, -0.12f, p);
        c.drawLine(2.1f, -0.12f, 2.7f, -0.55f, p);
        c.drawLine(-1.2f, -0.12f, -1.0f, -0.95f, p);
        c.drawLine(1.1f, -0.12f, 0.95f, -0.95f, p);
        p.setStrokeCap(Paint.Cap.BUTT);
        // --- tail boom + fin
        poly(c, new float[]{-2.0f, -1.45f, -2.0f, -2.20f, -8.5f, -2.05f, -8.7f, -1.75f}, 0xFF485736);
        poly(c, new float[]{-7.3f, -1.95f, -8.55f, -3.85f, -9.05f, -3.85f, -8.95f, -1.7f}, 0xFF485736);
        poly(c, new float[]{-6.6f, -1.95f, -7.9f, -2.0f, -7.7f, -1.55f, -6.5f, -1.65f}, 0xFF3C4A2D);
        p.setColor(0xFFE8C21B);
        c.drawRect(-8.0f, -2.2f, -7.7f, -1.7f, p);
        // --- fuselage
        poly(c, new float[]{-2.4f, -0.85f, -2.5f, -2.0f, -1.6f, -2.45f, 1.2f, -2.5f, 2.6f, -2.25f, 3.3f, -1.5f, 3.4f, -1.0f, 3.0f, -0.80f}, 0xFF51623D);
        poly(c, new float[]{-2.4f, -0.85f, 3.0f, -0.80f, 3.3f, -1.05f, -2.45f, -1.1f}, 0xFF3A4729);
        // engine deck and transmission fairing
        poly(c, new float[]{-1.9f, -2.45f, -1.5f, -3.0f, 0.9f, -3.05f, 1.2f, -2.5f}, 0xFF4A5A38);
        poly(c, new float[]{-1.4f, -2.7f, -1.1f, -3.0f, 0.5f, -3.0f, 0.6f, -2.7f}, 0xFF2D3322);
        // windows
        poly(c, new float[]{1.35f, -2.35f, 2.55f, -2.15f, 3.1f, -1.5f, 1.35f, -1.5f}, 0xCC8FC4E0);
        poly(c, new float[]{-0.9f, -2.30f, 1.15f, -2.30f, 1.15f, -1.5f, -0.9f, -1.5f}, 0xAA7FB3D0);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.07f);
        p.setColor(0xFF2A3220);
        c.drawLine(-1.2f, -2.35f, -1.2f, -0.9f, p);
        c.drawLine(1.25f, -2.4f, 1.25f, -0.9f, p);
        // pilot helmet
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFF222426);
        c.drawCircle(1.9f, -1.85f, 0.26f, p);
        c.drawCircle(0.55f, -1.85f, 0.24f, p);
        // lights
        if (s.nav && Gauge.powered(s)) {
            p.setColor(0xFF2BFF5C);
            c.drawCircle(3.15f, -1.15f, 0.12f, p);
            p.setColor(0xFFFFFFFF);
            c.drawCircle(-9.0f, -3.5f, 0.1f, p);
        }
        if (s.acol && Gauge.powered(s) && e.blink) { p.setColor(0xFFFF2A2A); c.drawCircle(-1.0f, -3.1f, 0.2f, p); c.drawCircle(-8.9f, -3.9f, 0.16f, p); }
        if (s.landLt && Gauge.powered(s)) {
            p.setShader(new LinearGradient(3.2f, -1.0f, 14f, 3f, 0x66FFF2B0, 0x00FFF2B0, Shader.TileMode.CLAMP));
            path.reset();
            path.moveTo(3.2f, -1.0f);
            path.lineTo(15f, 0.5f);
            path.lineTo(15f, 5.5f);
            path.close();
            c.drawPath(path, p);
            p.setShader(null);
            p.setColor(0xFFFFF4C0);
            c.drawCircle(3.3f, -1.0f, 0.14f, p);
        }
        // --- tail rotor (seen face-on): spinning two-bladed disc
        float tr = 1.25f, tx = -8.75f, ty = -2.7f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(((int) (Math.min(1, nrN) * 70)) << 24 | 0x202020);
        c.drawCircle(tx, ty, tr, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.14f);
        p.setColor(0xCC15161A);
        double ta = s.rotorAz * 3.1;
        c.drawLine(tx + (float) Math.cos(ta) * tr, ty + (float) Math.sin(ta) * tr, tx - (float) Math.cos(ta) * tr, ty - (float) Math.sin(ta) * tr, p);
        // --- main rotor
        float hubY = -3.7f, hubX = 0.2f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.28f);
        p.setColor(0xFF1A1B1D);
        c.drawLine(hubX, -3.0f, hubX, hubY, p);
        c.save();
        c.rotate((float) Math.toDegrees(s.disc + s.pitch), hubX, hubY);
        float R = (float) Sim.ROTOR_R;
        float cone = 0.04f + (nrN < 0.9f ? (0.9f - nrN) * 0.25f : 0f);               // blades droop at low rpm
        float az = (float) s.rotorAz;
        float len = R * (float) Math.abs(Math.cos(az));
        float dir = (float) Math.signum(Math.cos(az));
        if (nrN > 0.35f) {                                      // translucent disc
            rf.set(hubX - R, hubY - 0.35f - cone * R * 0.6f, hubX + R, hubY + 0.18f);
            p.setStyle(Paint.Style.FILL);
            p.setColor(((int) (Math.min(1, nrN) * 52)) << 24 | 0xB0B4B8);
            c.drawOval(rf, p);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(0.34f);
        p.setColor(0xFF121315);
        float tipY = hubY - cone * len * 0.9f + (nrN < 0.5f ? (0.5f - nrN) * 0.9f * len * 0.1f : 0f);
        c.drawLine(hubX - dir * len, tipY, hubX + dir * len, tipY, p);
        // stabilizer bar and paddles
        float bl = 2.2f * (float) Math.abs(Math.sin(az));
        p.setStrokeWidth(0.09f);
        c.drawLine(hubX - bl, hubY + 0.35f, hubX + bl, hubY + 0.35f, p);
        p.setStyle(Paint.Style.FILL);
        rf.set(hubX + bl - 0.35f, hubY + 0.27f, hubX + bl + 0.35f, hubY + 0.43f);
        c.drawOval(rf, p);
        rf.set(hubX - bl - 0.35f, hubY + 0.27f, hubX - bl + 0.35f, hubY + 0.43f);
        c.drawOval(rf, p);
        c.restore();
        c.restore();   // u scale
        c.restore();   // sprite transform
    }

    /** Small arrow at the screen edge that points to the destination pad when it is off-screen. */
    void drawBearing(Canvas c, RectF a, Sim s) {
        double d = Terrain.PAD_B_X - s.x;
        float x = sx(Terrain.PAD_B_X);
        if (x > a.left + 30 && x < a.right - 30) return;
        boolean right = d > 0;
        float cx = right ? a.right - 36 : a.left + 36, cy = a.top + a.height() * 0.46f;
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xCCFFD21F);
        path.reset();
        float k = right ? 1 : -1;
        path.moveTo(cx + 16 * k, cy);
        path.lineTo(cx - 8 * k, cy - 14);
        path.lineTo(cx - 8 * k, cy + 14);
        path.close();
        c.drawPath(path, p);
        GU.text(c, p, String.format(Locale.US, "BRAVO %.1f km", Math.abs(d) / 1000.0), cx - 14 * k, cy + 26, 16, 0xFFFFFFFF, right ? Paint.Align.RIGHT : Paint.Align.LEFT, true);
    }

    private static float frac(double v) { return (float) (v - Math.floor(v)); }

    private static float mod(float a, float b) { float r = a % b; return r < 0 ? r + b : r; }
}
