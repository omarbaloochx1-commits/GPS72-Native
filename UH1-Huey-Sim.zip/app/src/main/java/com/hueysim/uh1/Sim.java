package com.hueysim.uh1;

/**
 * Bell UH-1H "Huey" simulation core (pure Java, no Android classes).
 *
 * 2-D (vertical east-west slice) flight model built on momentum theory:
 * rotor thrust from collective and rotor speed, induced + profile + parasite power,
 * engine (Lycoming T53-L-13 style: N1 gas producer, N2 power turbine, EGT, torque),
 * rotor speed governed by the engine through a governor (AUTO) or by hand (EMER),
 * 24 V DC electrical system, hydraulics, oils, fuel and the caution panel.
 */
final class Sim {
    static final double G = 9.80665;
    static final double ROTOR_R = 7.315;                        // 48 ft rotor
    static final double DISC_A = Math.PI * ROTOR_R * ROTOR_R;
    static final double OMEGA100 = 33.93;                       // 324 rpm in rad/s
    static final double I_ROT = 3800;                           // rotor + drive inertia (kg m^2)
    static final double RATED_KW = 850;                         // max continuous shaft power at sea level
    static final double EMPTY_KG = 2365 + 190 + 150;            // empty + crew + cargo
    static final double OAT_FIELD = 22;                         // deg C at Base Alpha

    static final String[] LIGHT_NAMES = {"ENG OIL PRESS", "XMSN OIL PRESS", "XMSN OIL HOT", "ENG CHIP DET", "XMSN CHIP DET",
            "20 MIN FUEL", "DC GEN", "INVERTER", "HYD PRESS", "GOV EMER", "LOW RPM", "ENGINE OUT", "EGT HIGH", "ROTOR HIGH"};
    static final int NL = LIGHT_NAMES.length;
    final boolean[] light = new boolean[NL];

    // ---- pilot controls
    double collective, cyclic, pedal, throttle;                 // 0..1, -1..1 (+fwd), -1..1 (+right), 0..1
    boolean batt, gen, fuelMain, fuelStart, inverter, hyd, forceTrim = true, acol, nav, landLt;
    boolean govAuto = true, starterBtn;
    boolean assist = true;                                      // stability augmentation (easier handling)

    // ---- environment
    double windBase = 3.5;                                      // m/s, wind blowing towards +x (wind from the west)
    double windX = 3.5, rho = 1.2, sigma = 1.0, oatNow = OAT_FIELD;

    // ---- aircraft state
    double x, alt, vx, vz, hdg = 90, pitch, pitchRate, disc, yawRate;
    boolean onGround = true, crashed;
    String crashMsg = "";
    double rotorAz;

    // ---- engine / rotor
    double n1, n2, nr, egt = OAT_FIELD, torque, pDel, pReq, pCmd, thrustN, vi;
    boolean lit;
    double lightTimer, overTempT, overTorqueT;
    boolean hotStart, engDamaged, xmsnDamaged;
    double health = 1.0;

    // ---- systems
    double fuelLb = 780, fuelFlow;
    double battCharge = 0.92, battV, busV, amps, hydP;
    double engOilT = OAT_FIELD, engOilP, xmsnOilT = OAT_FIELD, xmsnOilP, fuelP;
    boolean genOnline, starterActive;

    // ---- derived instrument values
    double vsiFpm, turnRate, ball, uf, ias, agl, radAltFt;

    // ---- stats / events used by the mission and the score
    double time, flightTime, lowRpmTime, highRpmTime, overTorqueTime, vneTime, maxAgl;
    double touchVz, touchSpeed, touchPitch, thump;
    boolean hardLanding, tailStrike;
    boolean everAirborne;

    Sim() { reset(); }

    void reset() {
        collective = 0; cyclic = 0; pedal = 0; throttle = 0;
        batt = gen = fuelMain = fuelStart = inverter = hyd = acol = nav = landLt = starterBtn = false;
        forceTrim = true; govAuto = true;
        x = Terrain.PAD_A_X; alt = Terrain.h(x); vx = vz = 0; hdg = 90; pitch = pitchRate = disc = yawRate = 0;
        onGround = true; crashed = false; crashMsg = "";
        n1 = n2 = nr = 0; egt = OAT_FIELD; torque = pDel = pReq = pCmd = thrustN = vi = 0;
        lit = false; lightTimer = overTempT = overTorqueT = 0; hotStart = engDamaged = xmsnDamaged = false; health = 1;
        fuelLb = 780; fuelFlow = 0; battCharge = 0.92; busV = battV = 0; amps = 0; hydP = 0;
        engOilT = xmsnOilT = OAT_FIELD; engOilP = xmsnOilP = fuelP = 0; genOnline = starterActive = false;
        vsiFpm = turnRate = ball = uf = ias = agl = radAltFt = 0;
        time = flightTime = lowRpmTime = highRpmTime = overTorqueTime = vneTime = maxAgl = 0;
        touchVz = touchSpeed = touchPitch = thump = 0; hardLanding = tailStrike = everAirborne = false;
        for (int i = 0; i < NL; i++) light[i] = false;
    }

    double massKg() { return EMPTY_KG + fuelLb * 0.45359; }

    private static double clamp(double v, double a, double b) { return v < a ? a : (v > b ? b : v); }
    private static double sq(double v) { return v * v; }

    /** Advances the simulation by dt seconds (sub-stepped for stability). */
    void step(double dt) {
        while (dt > 1e-9) {
            double h = Math.min(dt, 1.0 / 120.0);
            sub(h);
            dt -= h;
        }
    }

    // thermodynamics / atmosphere --------------------------------------------------
    private void atmosphere() {
        double hm = Math.max(0, alt);
        double p = 101325 * Math.pow(1 - 2.25577e-5 * hm, 5.25588);
        double tK = 273.15 + OAT_FIELD - 0.0065 * (hm - Terrain.PAD_A_ELEV);
        oatNow = tK - 273.15;
        rho = p / (287.05 * tK);
        sigma = rho / 1.225;
        double t = time;
        double gust = 0.9 * Math.sin(t * 0.61) + 0.6 * Math.sin(t * 1.73 + 1.0) + 0.4 * Math.sin(t * 3.1 + 2.0);
        windX = windBase + gust * (assist ? 0.5 : 1.0) * (onGround ? 0.4 : 1.0);
    }

    private double n2Target() {
        if (!lit) return 0;
        if (throttle < 0.25) return 46 + clamp((throttle - 0.06) / 0.19, 0, 1) * 4;
        return 50 + (throttle - 0.25) / 0.75 * 50;
    }

    private double n1IdleTarget() { return 63 + clamp((throttle - 0.06) / 0.19, 0, 1) * 3; }

    private void sub(double dt) {
        time += dt;
        atmosphere();
        double mass = massKg();
        double nrN = nr / 100.0;
        double g = Terrain.h(x);
        agl = alt - g;
        double face = Math.sin(Math.toRadians(hdg));
        double vrelx = vx - windX;
        uf = vrelx * face;
        ias = Math.max(0, uf) * Math.sqrt(sigma) * 1.94384;

        // ================= electrical =================
        genOnline = gen && lit && n1 >= 50;
        starterActive = starterBtn && batt && battCharge > 0.08 && n1 < 40 && fuelLb > 0;
        if (starterActive) battCharge = Math.max(0, battCharge - 0.011 * dt);
        else if (genOnline) battCharge = Math.min(1, battCharge + 0.0015 * dt);
        else if (batt) battCharge = Math.max(0, battCharge - 0.00005 * dt);
        battV = batt ? 20.6 + 4.2 * battCharge - (starterActive ? 3.2 : 0) : 0;
        busV = genOnline ? 28.4 : battV;
        double loads = (batt ? 9 : 0) + (inverter && busV > 18 ? 14 : 0) + (acol && busV > 18 ? 4 : 0) + (nav && busV > 18 ? 3 : 0)
                + (landLt && busV > 18 ? 14 : 0) + (hyd && busV > 18 ? 6 : 0);
        if (starterActive) amps = -(380 + 90 * Math.sin(time * 9));
        else if (genOnline) amps = loads + 18 * (1 - battCharge);
        else amps = batt ? -loads : 0;

        // ================= engine start / N1 / EGT =================
        boolean fuelOk = fuelMain && fuelLb > 0.5;
        if (!lit) {
            if (starterActive && fuelOk && fuelStart && throttle >= 0.06 && n1 >= 3) {
                lightTimer += dt;
                if (lightTimer > 0.6) { lit = true; lightTimer = 0; }
            } else lightTimer = 0;
        } else {
            if (!fuelOk || throttle < 0.05) lit = false;
            else if (n1 < 45 && !fuelStart) lit = false;       // start fuel needed until the engine is self-sustaining
            else if (n1 < 28 && !starterActive) lit = false;   // stalled
        }
        double bf = clamp((battV - 16) / 8.0, 0.25, 1.0);
        if (!lit) {
            if (starterActive) n1 += clamp(25 - n1, 0, 3.4 * bf * dt);
            else n1 = Math.max(0, n1 - (0.9 + 0.035 * n1) * dt);
        } else {
            double tgt, tau;
            if (n1 < 40) { tgt = starterActive ? 48 : 0; tau = 99; }
            else { tgt = throttle < 0.25 ? n1IdleTarget() : 64 + 34 * Math.pow(clamp(pCmd / RATED_KW, 0, 1.15), 0.7); tau = (n1 < 62) ? 2.5 : (tgt > n1 ? 2.0 : 3.5); }
            if (n1 < 40) {
                if (tgt > n1) n1 += 2.9 * bf * dt; else n1 -= 2.5 * dt;
            } else n1 += (tgt - n1) * Math.min(1, dt / tau);
            n1 = clamp(n1, 0, 101.5);
        }
        double pf = clamp(pDel / RATED_KW, 0, 1.3);
        double egtT;
        if (lit) {
            egtT = 355 + 260 * pf;
            if (n1 < 45) egtT += (45 - n1) * 9 + (n1 < 12 ? (12 - n1) * 40 : 0);
        } else egtT = oatNow + 4;
        double egtTau = egtT > egt ? (lit && n1 < 45 ? 0.9 : 1.6) : 4.0;
        egt += (egtT - egt) * Math.min(1, dt / egtTau);
        if (egt > 780) overTempT += dt; else overTempT = Math.max(0, overTempT - dt * 0.5);
        if (overTempT > 0.6 && !engDamaged) { engDamaged = true; hotStart = true; health = 0.55; }

        // ================= rotor thrust / power =================
        double hr = Math.max(0.2, agl + 3.8);
        double ge = 1 + 0.10 * Math.exp(-hr / (ROTOR_R * 1.1));
        double cl = 0.10 + 1.70 * Math.pow(clamp(collective, 0, 1), 1.15);
        // inflow through the disc changes the blade angle of attack: descending raises thrust, climbing lowers it
        cl = clamp(cl - vz * 0.11 / Math.max(0.3, nrN), 0, 2.4);
        thrustN = 3200 * G * cl * nrN * nrN * sigma * ge;
        double hSpeed = Math.abs(vrelx);
        double vh = Math.sqrt(Math.max(1, thrustN) / (2 * rho * DISC_A));
        vi = vh;
        for (int k = 0; k < 6; k++) {
            double den = Math.sqrt(sq(hSpeed) + sq(vz + vi));
            vi = vh * vh / Math.max(den, 0.5 * vh);
        }
        vi /= (1 + 0.28 * Math.exp(-hr / (ROTOR_R * 0.9)) * (1 - clamp(hSpeed / 15, 0, 1)));   // ground effect
        double pIndW = thrustN * (vi + vz);
        pIndW *= pIndW >= 0 ? 1.15 : 0.95;
        double mu = hSpeed / (OMEGA100 * ROTOR_R * Math.max(0.3, nrN));
        double pProf = 150e3 * nrN * nrN * nrN * (1 + 4.6 * mu * mu) * sigma;
        double vneK = ias > 118 ? 1 + sq((ias - 118) / 14.0) : 1;           // retreating-blade stall / compressibility above Vne
        double fPar = (2.4 + 3.0 * (1 - Math.abs(face))) * vneK;
        double pPar = 0.5 * rho * fPar * hSpeed * hSpeed * hSpeed;
        pReq = (1.08 * (pIndW + pProf) + pPar) / 1000.0 + 6;
        if (nr < 1) pReq = 0;

        // ---- engine power available, governor and delivery
        double ratedNow = RATED_KW * health * Math.pow(sigma, 0.8);
        double s1 = clamp((n1 - 40) / 24.0, 0, 1), s2 = clamp((n1 - 62) / 35.0, 0, 1);
        double pAvail = lit ? ratedNow * (0.05 * s1 + 0.95 * s2) : 0;
        double nTgt = n2Target();
        if (!lit) pCmd = 0;
        else if (govAuto) {
            pCmd = pReq + 28 * (nTgt - nr);
            if (nr > nTgt + 0.5) pCmd = Math.min(pCmd, pReq * 0.4);
            pCmd = clamp(pCmd, 0, RATED_KW * 1.1);
        } else {
            double pFrac = throttle < 0.25 ? 0.04 : clamp((throttle - 0.25) / 0.75, 0, 1);
            pCmd = pFrac * RATED_KW;
        }
        pDel = lit ? Math.min(pCmd, pAvail) : 0;
        double omega = Math.max(2.0, nrN * OMEGA100);
        double dOm = (pDel - pReq) * 1000.0 / (I_ROT * omega);
        if (nr < 0.5 && dOm < 0) dOm = 0;
        nr = clamp(nr + dOm / OMEGA100 * 100.0 * dt, 0, 135);
        if (!lit && nr > 0 && pReq < 5) nr = Math.max(0, nr - 0.4 * dt);      // rotor brake / friction when everything is off
        nrN = nr / 100.0;
        n2 = lit ? (nr <= nTgt + 0.3 ? nr : nTgt) : 0;
        torque = pDel * 1.341 / 22.0 / Math.max(0.4, nrN);
        if (torque > 50) overTorqueT += dt; else overTorqueT = Math.max(0, overTorqueT - dt * 0.3);
        if (torque > 52 && overTorqueT > 4 && !xmsnDamaged) xmsnDamaged = true;

        // ================= flight dynamics =================
        double hydG = (hyd && nr > 40 && busV > 18) ? 1.0 : 0.55;
        double inst = assist ? 0.30 : 1.0;
        double aCmd = clamp(cyclic, -1, 1) * hydG * (cyclic < 0 ? 0.40 : 0.28)
                + inst * 0.0045 * uf * Math.max(0, 1 - Math.abs(uf) / 15.0)
                - 0.0010 * Math.max(0, Math.abs(uf) - 10) * Math.signum(uf);
        if (!assist && !onGround) aCmd += 0.004 * Math.sin(time * 2.3) * (1 - Math.abs(face));
        disc += (aCmd - disc) * (1 - Math.exp(-dt / 0.45));
        double pitchGround = 0;
        double sgn = Math.abs(face) > 0.2 ? Math.signum(face) : 0;
        if (onGround) pitchGround = Math.atan(Terrain.slope(x) * sgn);
        if (onGround && thrustN < mass * G * 0.97) {
            pitch += (pitchGround - pitch) * (1 - Math.exp(-dt / 0.15));
            pitchRate = 0;
            disc *= Math.exp(-dt / 0.6);
        } else {
            double thetaT = -0.95 * disc + 0.03;
            double acc = 4.0 * (thetaT - pitch) - 2 * 0.55 * 2.0 * pitchRate;
            pitchRate += acc * dt;
            pitch += pitchRate * dt;
            pitch = clamp(pitch, -0.7, 0.7);
        }

        double dragX = -0.5 * rho * fPar * vrelx * Math.abs(vrelx);
        double dragZ = -0.5 * rho * 1.8 * vz * Math.abs(vz);
        double ax = (thrustN * Math.sin(disc) * face + dragX) / mass;
        double az = (thrustN * Math.cos(disc) + dragZ) / mass - G;

        // yaw (pedals + torque reaction, rotor turns counter-clockwise so torque yaws the nose right)
        boolean heavyOnSkids = onGround && thrustN < mass * G * 0.97;
        double yawT = pedal * hydG * 38 * (0.35 + 0.65 * clamp(nrN, 0, 1.1)) + (heavyOnSkids ? 0 : (torque - 25) * 0.22 * (assist ? 0.15 : 1.0) * (nr > 30 ? 1 : 0));
        if (heavyOnSkids) yawT *= 0.5;
        if (nr < 30) yawT = pedal * 4;
        yawRate += (yawT - yawRate) * (1 - Math.exp(-dt / 0.35));
        hdg = (hdg + yawRate * dt + 360) % 360;

        // ================= ground / integration =================
        boolean wasGround = onGround;
        if (crashed) {
            vx = 0; vz = 0; ax = 0; az = 0;
        } else {
            if (onGround && az <= 0) {                           // supported by the ground
                double normal = Math.max(0, mass * G - thrustN * Math.cos(disc)) / mass;
                double fric = 0.45 * normal;
                if (Math.abs(vx) < 0.06 && Math.abs(ax) <= fric) { vx = 0; ax = 0; }
                else {
                    double dir = Math.abs(vx) > 0.06 ? Math.signum(vx) : Math.signum(ax);
                    ax -= dir * fric;
                    if (Math.abs(vx) < fric * dt && Math.abs(ax) < fric * 1.2) { vx = 0; ax = 0; }
                }
                vz = 0; az = 0;
            }
            vx += ax * dt;
            vz += az * dt;
            x += vx * dt;
            alt += vz * dt;
            double gNew = Terrain.h(x);
            if (alt <= gNew) {
                if (!onGround && vz < -0.05) touchdown(vz, gNew, face, pitchGround);
                alt = gNew;
                if (vz < 0) vz = 0;
                onGround = true;
            } else if (alt > gNew + 0.03 && az > 0.05 && onGround) {
                onGround = false; everAirborne = true;
            } else if (alt > gNew + 0.25) onGround = false;
            if (!onGround) everAirborne = everAirborne || alt - gNew > 1.0;
            // flying into a hillside
            double ahead = x + sgn * 9;
            if (!onGround && sgn != 0 && Terrain.h(ahead) > alt + 2.6 && Math.abs(uf) > 3) crash("Terrain collision / Impact with terrain");
        }
        agl = alt - Terrain.h(x);
        if (!onGround) { flightTime += dt; maxAgl = Math.max(maxAgl, agl); }
        if (wasGround && !onGround) { /* lift-off */ }
        thump = Math.max(0, thump - dt * 2);

        // ================= instruments & systems =================
        vsiFpm += (vz * 196.85 - vsiFpm) * (1 - Math.exp(-dt / 1.4));
        turnRate = yawRate;
        ball += (clamp((torque - 25) * 0.03 - pedal * 0.5 - (yawRate - yawT) * 0.02, -1, 1) - ball) * (1 - Math.exp(-dt / 0.5));
        radAltFt = Math.max(0, agl) * 3.2808;
        rotorAz += nrN * 5.4 * 2 * Math.PI * dt * 0.33;

        fuelFlow = lit ? 95 + 0.62 * pDel * 1.341 : 0;
        fuelLb = Math.max(0, fuelLb - fuelFlow / 3600.0 * dt);
        if (fuelLb <= 0 && lit) lit = false;
        fuelP += (((fuelMain && fuelLb > 0 && (batt || genOnline)) ? 9.5 : 0) - fuelP) * Math.min(1, dt / 1.0);

        double engOilTt = lit ? oatNow + 38 + 50 * pf + 18 * (n1 / 100) : oatNow;
        engOilT += (engOilTt - engOilT) * Math.min(1, dt / (lit ? 70.0 : 240.0));
        double engOilPt = n1 > 3 ? clamp(8 + 0.62 * n1, 0, 75) * (1.12 - 0.003 * (engOilT - 20)) : 0;
        engOilP += (engOilPt - engOilP) * Math.min(1, dt / 1.2);
        double xOilTt = oatNow + (nr / 100) * (28 + 42 * pf);
        xmsnOilT += (xOilTt - xmsnOilT) * Math.min(1, dt / (nr > 20 ? 80.0 : 260.0));
        double xOilPt = nr > 5 ? clamp(8 + 0.42 * nr, 0, 62) : 0;
        xmsnOilP += (xOilPt - xmsnOilP) * Math.min(1, dt / 1.2);
        hydP += (((hyd && nr > 40 && busV > 18) ? 1000 : 0) - hydP) * Math.min(1, dt / 1.5);

        if (!onGround) {
            if (nr < 95) lowRpmTime += dt;
            if (ias > 124) vneTime += dt;
        }
        if (nr > 104.5) highRpmTime += dt;
        if (torque > 50) overTorqueTime += dt;

        boolean powered = busV > 18;
        light[0] = powered && n1 > 30 && engOilP < 25;
        light[1] = powered && nr > 30 && xmsnOilP < 20;
        light[2] = powered && xmsnOilT > 110;
        light[3] = powered && engDamaged;
        light[4] = powered && xmsnDamaged;
        light[5] = powered && fuelLb < 150;
        light[6] = powered && n1 > 50 && !genOnline;
        light[7] = batt && powered && !inverter;
        light[8] = powered && (!hyd || (hydP < 500 && nr > 40));
        light[9] = powered && !govAuto;
        light[10] = powered && nr > 20 && nr < 97 && (lit || !onGround);
        light[11] = powered && everAirborne && !lit && nr > 20 && !onGround;
        light[12] = powered && egt > 640;
        light[13] = powered && nr > 104;
    }

    private void touchdown(double impactVz, double gNew, double face, double pitchGround) {
        touchVz = -impactVz;
        touchSpeed = Math.abs(vx);
        touchPitch = Math.toDegrees(pitch - pitchGround);
        thump = Math.min(1, touchVz / 3.0);
        if (touchVz > 4.8 || Math.abs(vx) > 22) { crash("Hard impact: sink rate " + (int) (touchVz * 196.85) + " fpm"); return; }
        if (touchPitch > 18) { crash("Tail strike on landing"); return; }
        if (touchPitch < -20) { crash("Nose dug in on landing"); return; }
        if (touchVz > 2.6 || Math.abs(vx) > 12) hardLanding = true;
        if (touchPitch > 11) tailStrike = true;
    }

    void crash(String why) {
        if (crashed) return;
        crashed = true; crashMsg = why;
        vx = 0; vz = 0;
    }

    // ---- helpers for the UI ----
    double altFt() { return alt * 3.2808; }
    double fuelMinutes() { return fuelFlow > 1 ? fuelLb / fuelFlow * 60 : 999; }
    double groundSpeedKt() { return Math.abs(vx) * 1.94384; }
}
