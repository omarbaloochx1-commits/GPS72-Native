Headless (no Android) tests of the flight model. They only need a JDK:

  javac -d out app/src/main/java/com/hueysim/uh1/{Terrain,Sim,Mission,Manual}.java tools/headless-tests/*.java
  java -cp out com.hueysim.uh1.T6      # scripted mission: start-up, flight, landing, score

T1 engine start + hover collective, T2 scripted flight/landing, T3 mission checklist + hot start + open-loop hover,
T4/T5 hot-start variants, top speed, engine-out autorotation, T6 full mission, Md writes docs/MANUAL_*.md.
