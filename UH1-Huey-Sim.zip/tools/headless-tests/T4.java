package com.hueysim.uh1;

public class T4 {
    static void run(Sim s, double sec) { for (int i = 0; i < (int) (sec * 60); i++) s.step(1.0 / 60); }
    public static Sim airborne() {
        Sim s = T3.ready();
        s.onGround = false; s.everAirborne = true;
        s.alt = Terrain.h(s.x) + 150; s.vx = 45; s.vz = 0; s.pitch = -0.10; s.disc = 0.11; s.collective = 0.52; s.cyclic = 0.42;
        run(s, 3);
        return s;
    }
    public static void main(String[] a) {
        // hot start variants
        for (double openAt : new double[]{0, 6, 9, 12, 15}) {
            Sim h = new Sim(); h.batt = true; h.fuelMain = true; h.fuelStart = true; h.inverter = true; run(h, 1);
            h.starterBtn = true; double peak = 0;
            for (int i = 0; i < 60 * 60; i++) { if (h.n1 >= openAt && h.throttle == 0) h.throttle = 0.15; h.step(1.0 / 60); peak = Math.max(peak, h.egt); if (h.n1 > 45) break; }
            System.out.printf("throttle opened at N1>=%.0f: peak EGT %.0f hotStart=%b%n", openAt, peak, h.hotStart);
        }
        // engine out in cruise
        Sim r = airborne();
        System.out.printf("cruise: agl=%.0f ias=%.0f vz=%.1f nr=%.1f tq=%.1f pitch=%.1f%n", r.agl, r.ias, r.vz, r.nr, r.torque, Math.toDegrees(r.pitch));
        double t0 = r.time;
        r.throttle = 0; run(r, 1.0);
        System.out.printf("1.0 s after failure, collective still %.2f: nr=%.1f%n", r.collective, r.nr);
        r.collective = 0.12; r.cyclic = 0.35;
        for (int k = 0; k < 10 && !r.onGround; k++) { run(r, 2); System.out.printf("  t+%.0f nr=%.1f vz=%.1f ias=%.0f agl=%.0f pitch=%.1f%n", r.time - t0, r.nr, r.vz, r.ias, r.agl, Math.toDegrees(r.pitch)); }
        // delayed reaction: 3 s
        Sim d = airborne(); d.throttle = 0; run(d, 3.0);
        System.out.printf("collective not lowered for 3 s: nr=%.1f lowRpmLight=%b%n", d.nr, d.light[10]);
    }
}
