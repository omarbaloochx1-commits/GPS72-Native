package com.hueysim.uh1;

public class T3 {
    static void run(Sim s, double sec) { for (int i = 0; i < (int) (sec * 60); i++) s.step(1.0 / 60); }
    public static Sim ready() {
        Sim s = new Sim();
        s.batt = true; s.fuelMain = true; s.fuelStart = true; s.inverter = true; run(s, 1);
        s.starterBtn = true; while (s.n1 < 15) run(s, 0.1);
        s.throttle = 0.15; while (s.n1 < 40) run(s, 0.1);
        s.starterBtn = false; run(s, 14);
        s.gen = true; s.hyd = true; s.fuelStart = false; run(s, 2); s.throttle = 1.0; run(s, 40);
        return s;
    }
    public static void main(String[] a) {
        // 1. mission checklist progression through the start-up
        Sim s = new Sim(); Mission m = new Mission();
        double dt = 1.0 / 60;
        int lastStep = -1;
        s.batt = true; s.fuelMain = true; s.fuelStart = true; s.inverter = true;
        java.util.function.Consumer<Double> adv = secs -> { for (int i = 0; i < (int) (secs * 60); i++) { s.step(dt); m.update(s, dt); if (m.step != lastStepHolder[0]) { System.out.printf("  step %d done at t=%.1f%n", m.step, s.time); lastStepHolder[0] = m.step; } } };
        adv.accept(1.0);
        s.starterBtn = true; while (s.n1 < 15) adv.accept(0.1);
        s.throttle = 0.15; while (s.n1 < 40) adv.accept(0.1);
        s.starterBtn = false; adv.accept(14.0);
        s.gen = true; s.hyd = true; s.fuelStart = false; adv.accept(2.0); s.throttle = 1.0; adv.accept(30.0);
        System.out.println("mission step after start-up: " + m.step + " (expect 12 = take-off)");
        // 2. hot start: throttle opened too early
        Sim h = new Sim(); h.batt = true; h.fuelMain = true; h.fuelStart = true; run(h, 1);
        h.starterBtn = true; h.throttle = 0.15; run(h, 40);
        System.out.printf("hot start test: egt=%.0f hotStart=%b damaged=%b n1=%.1f lit=%b%n", h.egt, h.hotStart, h.engDamaged, h.n1, h.lit);
        // 3. engine failure in cruise -> autorotation
        Sim r = ready();
        r.collective = 0.58; r.step(0);
        run(r, 2);
        // climb to 150 m quickly using collective 0.9, fwd cyclic
        r.cyclic = 0.45; r.collective = 0.8;
        while (r.agl < 150 && r.time < 400) run(r, 0.1);
        r.collective = 0.5;
        run(r, 15);
        System.out.printf("cruise before failure: agl=%.0f ias=%.0f vz=%.1f nr=%.1f%n", r.agl, r.ias, r.vz, r.nr);
        r.throttle = 0.0; // fuel cut = engine out
        double tFail = r.time;
        run(r, 1.0);
        System.out.printf("1 s after failure (collective unchanged %.2f): nr=%.1f%n", r.collective, r.nr);
        r.collective = 0.0; // pilot lowers collective
        for (int k = 0; k < 8; k++) { run(r, 2); System.out.printf("  t+%.0f nr=%.1f vz=%.1f ias=%.0f agl=%.0f pitch=%.1f%n", r.time - tFail, r.nr, r.vz, r.ias, r.agl, Math.toDegrees(r.pitch)); }
        // 4. open-loop hover with assist on/off
        for (int mode = 0; mode < 2; mode++) {
            Sim q = ready(); q.assist = mode == 0;
            q.collective = 0.60; run(q, 4);
            // trim collective to hold ~3 m
            double c = 0.60; 
            for (int i = 0; i < 600; i++) { double err = 4 - q.agl; c += (0.0005 * err - 0.0009 * q.vz); c = Math.max(0.4, Math.min(0.8, c)); q.collective = c; q.pedal = Math.max(-1, Math.min(1, 0.05 * (90 - q.hdg))); q.step(1.0 / 60); }
            double x0 = q.x; double maxP = 0;
            for (int i = 0; i < 60 * 25; i++) { double err = 4 - q.agl; c += (0.0005 * err - 0.0009 * q.vz); c = Math.max(0.4, Math.min(0.8, c)); q.collective = c; q.pedal = Math.max(-1, Math.min(1, 0.05 * (90 - q.hdg))); q.step(1.0 / 60); maxP = Math.max(maxP, Math.abs(Math.toDegrees(q.pitch))); if (q.crashed) break; }
            System.out.printf("open-loop hover assist=%b: drift over 25 s = %.1f m, vx=%.2f, max pitch %.1f deg, agl=%.1f crashed=%b%n", q.assist, q.x - x0, q.vx, maxP, q.agl, q.crashed);
        }
    }
    static int[] lastStepHolder = {-1};
}
