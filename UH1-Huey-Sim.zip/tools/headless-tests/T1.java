package com.hueysim.uh1;

public class T1 {
    static Sim s = new Sim();
    static void run(double sec) { for (int i = 0; i < (int) (sec * 60); i++) s.step(1.0 / 60); }
    static void p(String t) {
        System.out.printf("%-22s t=%6.1f n1=%5.1f n2=%5.1f nr=%5.1f egt=%5.0f tq=%5.1f pDel=%5.0f pReq=%5.0f lit=%b fuel=%5.0f busV=%4.1f%n", t, s.time, s.n1, s.n2, s.nr, s.egt, s.torque, s.pDel, s.pReq, s.lit, s.fuelLb, s.busV);
    }
    public static void main(String[] a) {
        s.batt = true; s.fuelMain = true; s.fuelStart = true; s.inverter = true; run(1); p("batt on");
        s.starterBtn = true; double t0 = s.time;
        while (s.n1 < 15 && s.time - t0 < 30) run(0.1);
        p("n1>=15, open throttle"); s.throttle = 0.15;
        double lightT = s.time;
        while (s.n1 < 40 && s.time - t0 < 60) { run(0.1); if (((int) (s.time * 10)) % 20 == 0) p("starting"); }
        s.starterBtn = false; p("starter off");
        run(12); p("idle"); 
        s.gen = true; s.hyd = true; s.fuelStart = false; run(2);
        s.throttle = 1.0; for (int i = 0; i < 12; i++) { run(3); p("spool up"); }
        System.out.println("max egt seen? now " + s.egt + " damaged=" + s.engDamaged);
        // hover collective search
        for (double c = 0.2; c < 0.9; c += 0.05) {
            s.collective = c; run(1.5);
            System.out.printf("coll %.2f -> thrust/weight=%.3f vz=%.2f alt-agl=%.1f tq=%.1f nr=%.1f onGround=%b%n", c, s.thrustN / (s.massKg() * Sim.G), s.vz, s.agl, s.torque, s.nr, s.onGround);
            if (!s.onGround) break;
        }
    }
}
