package com.hueysim.uh1;

public class T6 {
    public static void main(String[] a) {
        Sim s = new Sim(); Mission m = new Mission(); double dt = 1.0 / 60;
        // full scripted mission: start-up with the checklist steps, then fly and land
        java.util.function.DoubleConsumer adv = secs -> { for (int i = 0; i < (int) (secs * 60); i++) { s.step(dt); m.update(s, dt); } };
        s.batt = true; s.fuelMain = true; s.fuelStart = true; s.inverter = true; adv.accept(1.0);
        s.starterBtn = true; while (s.n1 < 15) adv.accept(0.1);
        s.throttle = 0.15; while (s.n1 < 40) adv.accept(0.1);
        s.starterBtn = false; adv.accept(14.0);
        s.gen = true; s.hyd = true; s.fuelStart = false; adv.accept(2.0); s.throttle = 1.0; adv.accept(40.0);
        double cc = 0.55, prevVx = 0; String phase = "hover"; double targetV = 0, targetAgl = 4;
        for (int i = 0; i < 60 * 500 && !m.complete && !m.failed; i++) {
            double agl = s.agl, dist = Terrain.PAD_B_X - s.x;
            if (phase.equals("hover") && agl > 3 && Math.abs(s.vz) < 0.5 && m.step >= 13) phase = "cruise";
            if (phase.equals("hover")) { targetV = 0; targetAgl = 4; }
            if (phase.equals("cruise")) { targetV = 38; targetAgl = 130; if (dist < 1100) phase = "approach"; }
            if (phase.equals("approach")) { targetV = Math.max(2, Math.min(38, dist / 30)); targetAgl = Math.max(3, Math.min(120, dist * 0.12)); if (dist < 25) phase = "land"; }
            if (phase.equals("land")) { targetV = Math.max(0, Math.min(3, dist / 20)); targetAgl = -1.5; }
            double vzCmd = Math.max(-2.5, Math.min(4, (targetAgl - agl) * 0.5));
            if (phase.equals("land") && agl < 6) vzCmd = -0.6;
            cc += 0.7 * (vzCmd - s.vz) * 0.25 * dt * 3; cc = Math.max(0, Math.min(1, cc));
            if (phase.equals("land") && s.onGround) cc = Math.max(0, cc - 0.3 * dt);
            if (m.step < 12) cc = 0; // stay on the ground until the checklist reached take-off
            s.collective = cc;
            double gs = s.vx; double cy = 0.06 * (targetV - gs) + (targetV > 15 ? 0.35 : 0) - 0.05 * s.pitchRate;
            s.cyclic = Math.max(-1, Math.min(1, cy));
            s.pedal = Math.max(-1, Math.min(1, 0.08 * (90 - s.hdg) - 0.02 * s.yawRate));
            s.step(dt); m.update(s, dt);
            if (i % 1800 == 0) System.out.printf("t=%.0f ph=%s step=%d x=%.0f agl=%.1f vx=%.1f ias=%.1f vz=%.1f coll=%.2f nr=%.1f%n", s.time, phase, m.step, s.x, s.agl, s.vx, s.ias, s.vz, s.collective, s.nr);
        }
        System.out.printf("mission complete=%b failed=%b (%s) step=%d%n", m.complete, m.failed, m.failMsg, m.step);
        System.out.printf("score: start %.0f flight %.0f land %.0f fuel %.0f = %.0f (%s); touchVz=%.2f touchSpeed=%.2f fuel=%.0f lb time=%.0f s%n", m.sStart, m.sFlight, m.sLand, m.sFuel, m.score, m.rating, s.touchVz, s.touchSpeed, s.fuelLb, s.time);
    }
}
