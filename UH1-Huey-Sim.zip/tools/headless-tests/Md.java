package com.hueysim.uh1;

public class Md {
    public static void main(String[] a) throws Exception {
        for (int lang = 0; lang < 2; lang++) {
            boolean fa = lang == 1;
            StringBuilder b = new StringBuilder();
            b.append(fa ? "# دفترچه راهنمای UH-1H Huey Simulator\n\n" : "# UH-1H Huey Simulator - Operating Manual\n\n");
            for (int i = 0; i < Manual.pages(); i++) {
                String[] pg = Manual.page(fa, i);
                b.append("## ").append(pg[0]).append("\n\n");
                for (int k = 1; k < pg.length; k++) { b.append(pg[k]).append("\n\n"); }
            }
            b.append(fa ? "## چک‌لیست ماموریت ۱\n\n" : "## Mission 1 checklist\n\n");
            for (int i = 0; i < Mission.N; i++) {
                b.append(i + 1).append(". ").append((fa ? Mission.FA : Mission.EN)[i]).append("\n\n   ").append((fa ? Mission.HINT_FA : Mission.HINT_EN)[i]).append("\n\n");
            }
            java.nio.file.Files.write(java.nio.file.Paths.get("docs/" + (fa ? "MANUAL_FA.md" : "MANUAL_EN.md")), b.toString().getBytes("UTF-8"));
        }
    }
}
