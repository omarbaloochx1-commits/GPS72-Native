# UH-1H Huey Simulator (Android, 2D)

A 2-D side-view simulator of the **Bell UH-1H Iroquois ("Huey")** with a real physical model and a complete cockpit.

* Rotor thrust, induced / profile / parasite power, ground effect, translational lift, autorotation (momentum theory)
* Lycoming T53-L-13 style engine: N1 gas producer, N2 power turbine, EGT, torque, governor (AUTO / EMER), real start sequence (hot start possible)
* 24 V electrical system (battery, starter-generator, inverter), hydraulics, fuel, engine and transmission oil, 14 caution lights
* 16 working instruments: airspeed, attitude, altimeter, VSI, heading/RMI with distance, turn & slip, clock, radar altimeter,
  torque, rotor/engine tach, N1, EGT, fuel quantity + pressure, engine oil, transmission oil, volts/amps
* Mission 1: cold start -> take-off -> 6.8 km delivery flight east to Firebase Bravo -> landing, scored out of 100
* In-game manual (English / Persian) and a coach that shows the next checklist step
* Synthesised sound: turbine whine, blade slap, starter, wind, low-rpm horn, touchdown

Manuals: `docs/MANUAL_EN.md`, `docs/MANUAL_FA.md` (same text as the in-game MANUAL button).

## Build the APK on GitHub
1. Create a new repository (or empty an old one) and upload the contents of this project, **including the `.github` folder**
   (or upload the project zip next to `.github/workflows/build.yml`; the workflow unpacks the newest zip).
2. Open the *Actions* tab -> **Build APK** -> run -> download the artifact `UH1-Huey-Sim-apk-<n>`.
3. Install `app-debug.apk`. The package name `com.hueysim.uh1` and the signing key are fixed, so every new build updates the old one
   and keeps the saved settings.

Requirements: Android 7.0+ (API 24), landscape. No permissions are needed.

## Controls (touch)
Left: **COLLECTIVE** lever and **THROTTLE** twist grip. Right: **CYCLIC** lever (double-tap to centre). Under the outside view:
**LEFT / RIGHT PEDAL**. Switches under the outside view are tapped; **STARTER** is press-and-hold.
