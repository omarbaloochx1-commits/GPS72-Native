# GPS 72 Native Android

Native Java Android implementation of the GPS 72-style handheld GPS interface.

## Build

Run `gradle assembleDebug` from the project root, or use the included GitHub Actions workflow (`.github/workflows/build.yml`).

## Added in this development build

- Track points and trip distance are saved locally and restored when the app is reopened.
- Track storage is capped at 2,000 recent points to keep app storage bounded.
- Long-press the existing MENU button for about one second to export waypoints and the recorded track as a GPX file.
- A normal short press of MENU continues to open/close the original menu.

The existing screen layout, visual drawing, page order, buttons, and their normal short-press actions are retained.
