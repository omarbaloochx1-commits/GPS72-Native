package com.example.gps72;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.hardware.*;
import android.location.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity implements LocationListener, SensorEventListener {
    private LocationManager locationManager;
    private SensorManager sensorManager;
    private Sensor rotationSensor;
    private GpsScreen screen;
    private final ArrayList<double[]> track = new ArrayList<>();
    private final ArrayList<Waypoint> waypoints = new ArrayList<>();
    private final android.os.Handler handler = new android.os.Handler();
    private SharedPreferences prefs;
    private Location current;
    private float heading = Float.NaN, accuracy = 0;
    private int satellites = 0;
    private boolean recording = true, light = false, menu = false;
    private int page = 0, selectedWaypoint = -1, zoom = 3;
    private long startTime = System.currentTimeMillis();
    private double tripDistance = 0, tripMaxSpeed = 0;
    private String status = "SEARCHING FOR GPS";
    private static final int REQ_GPS = 10, CREATE_GPX = 11;

    static class Waypoint { String name; double lat, lon; Waypoint(String n,double a,double o){name=n;lat=a;lon=o;} }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystem();
        prefs=getSharedPreferences("gps72_data",MODE_PRIVATE);
        loadData();
        locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE);
        rotationSensor=sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        screen=new GpsScreen(this); setContentView(screen);
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_GPS);
        else startGps();
        handler.post(tick);
    }
    private void hideSystem(){ getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE); }
    @Override public void onWindowFocusChanged(boolean f){super.onWindowFocusChanged(f);if(f)hideSystem();}
    @Override protected void onResume(){super.onResume();if(rotationSensor!=null)sensorManager.registerListener(this,rotationSensor,SensorManager.SENSOR_DELAY_UI);if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED)startGps();}
    @Override protected void onPause(){super.onPause();sensorManager.unregisterListener(this);if(locationManager!=null)locationManager.removeUpdates(this);saveData();}
    @Override protected void onDestroy(){super.onDestroy();handler.removeCallbacks(tick);saveData();}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_GPS&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startGps();else status="LOCATION PERMISSION REQUIRED";}
    @SuppressWarnings("MissingPermission") private void startGps(){try{locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,0.5f,this);Location last=locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);if(last!=null&&current==null)onLocationChanged(last);status="GPS ACTIVE - WAITING FIX";}catch(Exception e){status="GPS PROVIDER UNAVAILABLE";}}
    @Override public void onLocationChanged(Location l){if(l==null)return; if(current!=null){float d=current.distanceTo(l);if(d>0.8f&&d<100)tripDistance+=d;}current=l;accuracy=l.hasAccuracy()?l.getAccuracy():0;if(l.hasSpeed()){double s=l.getSpeed()*3.6;tripMaxSpeed=Math.max(tripMaxSpeed,s);}status="3D GPS FIX";if(recording&&(track.isEmpty()||distance(track.get(track.size()-1),l.getLatitude(),l.getLongitude())>2)){track.add(new double[]{l.getLatitude(),l.getLongitude(),System.currentTimeMillis()});if(track.size()>5000)track.remove(0);}saveData();invalidate();}
    @Override public void onProviderEnabled(String p){} @Override public void onProviderDisabled(String p){status="GPS DISABLED";} @Override public void onStatusChanged(String p,int s,Bundle b){}
    @Override public void onSensorChanged(SensorEvent e){if(e.sensor.getType()==Sensor.TYPE_ROTATION_VECTOR){float[] m=new float[9],o=new float[3];SensorManager.getRotationMatrixFromVector(m,e.values);SensorManager.getOrientation(m,o);heading=(float)Math.toDegrees(o[0]);heading=(heading+360)%360;invalidate();}}
    @Override public void onAccuracyChanged(Sensor s,int a){}
    private double distance(double[] p,double lat,double lon){float[] r=new float[1];Location.distanceBetween(p[0],p[1],lat,lon,r);return r[0];}
    private void saveData(){if(prefs==null)return;StringBuilder b=new StringBuilder();for(double[] p:track)b.append(p[0]).append(',').append(p[1]).append(',').append((long)p[2]).append(';');StringBuilder w=new StringBuilder();for(Waypoint p:waypoints)w.append(encode(p.name)).append(',').append(p.lat).append(',').append(p.lon).append(';');prefs.edit().putString("track",b.toString()).putString("wps",w.toString()).putFloat("trip",(float)tripDistance).putFloat("max",(float)tripMaxSpeed).putBoolean("record",recording).apply();}
    private String encode(String s){return android.util.Base64.encodeToString(s.getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);}
    private void loadData(){tripDistance=prefs.getFloat("trip",0);tripMaxSpeed=prefs.getFloat("max",0);recording=prefs.getBoolean("record",true);String t=prefs.getString("track","");for(String x:t.split(";")){try{String[] a=x.split(",");if(a.length==3)track.add(new double[]{Double.parseDouble(a[0]),Double.parseDouble(a[1]),Double.parseDouble(a[2])});}catch(Exception ignored){}}String w=prefs.getString("wps","");for(String x:w.split(";")){try{String[] a=x.split(",");if(a.length==3)waypoints.add(new Waypoint(new String(android.util.Base64.decode(a[0],0),java.nio.charset.StandardCharsets.UTF_8),Double.parseDouble(a[1]),Double.parseDouble(a[2])));}catch(Exception ignored){}}}
    private void mark(){if(current==null){status="NO GPS POSITION TO MARK";return;}String n="WPT "+(waypoints.size()+1);waypoints.add(new Waypoint(n,current.getLatitude(),current.getLongitude()));status="WAYPOINT SAVED: "+n;saveData();}
    private void mob(){if(current==null){status="NO GPS POSITION FOR MOB";return;}waypoints.add(new Waypoint("MOB",current.getLatitude(),current.getLongitude()));selectedWaypoint=waypoints.size()-1;status="MAN OVERBOARD POSITION SAVED";saveData();page=4;}
    private void exportGpx(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/gpx+xml");i.putExtra(Intent.EXTRA_TITLE,"GPS72-track.gpx");startActivityForResult(i,CREATE_GPX);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==CREATE_GPX&&c==RESULT_OK&&d!=null){try(OutputStream o=getContentResolver().openOutputStream(d.getData())){o.write(makeGpx().getBytes(java.nio.charset.StandardCharsets.UTF_8));status="GPX FILE EXPORTED";}catch(Exception e){status="GPX EXPORT FAILED";}invalidate();}}
    private String makeGpx(){StringBuilder b=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"GPS 72\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n");for(Waypoint w:waypoints)b.append("<wpt lat=\"").append(w.lat).append("\" lon=\"").append(w.lon).append("\"><name>").append(xml(w.name)).append("</name></wpt>\n");b.append("<trk><name>GPS 72 Track</name><trkseg>\n");for(double[] p:track)b.append("<trkpt lat=\"").append(p[0]).append("\" lon=\"").append(p[1]).append("\"><time>").append(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.US).format(new Date((long)p[2]))).append("</time></trkpt>\n");return b.append("</trkseg></trk></gpx>").toString();}
    private String xml(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}
    private Runnable tick=()->{if(screen!=null)screen.invalidate();handler.postDelayed(tick,1000);};
    private void action(String a){switch(a){case "PAGE":page=(page+1)%5;menu=false;break;case "QUIT":if(menu)menu=false;else page=(page+4)%5;break;case "MENU":menu=!menu;break;case "ENTER":if(menu){menu=false;exportGpx();}else mark();break;case "GOTO":if(!waypoints.isEmpty()){selectedWaypoint=(selectedWaypoint+1)%waypoints.size();page=4;status="GOTO: "+waypoints.get(selectedWaypoint).name;}else status="NO WAYPOINTS - PRESS MARK";break;case "MOB":mob();break;case "LIGHT":light=!light;break;case "IN":zoom=Math.min(8,zoom+1);break;case "OUT":zoom=Math.max(1,zoom-1);break;case "UP":case "DOWN":case "LEFT":case "RIGHT":if(menu){if(a.equals("UP"))menuChoice=(menuChoice+3)%4;else if(a.equals("DOWN"))menuChoice=(menuChoice+1)%4;}break;}saveData();screen.invalidate();}
    private int menuChoice=0;

    class GpsScreen extends View {
        Canvas c; Paint p=new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG); float sx,sy;
        final int lcd=Color.rgb(75,77,52), ink=Color.rgb(37,39,29), pale=Color.rgb(190,204,202);
        GpsScreen(Context x){super(x);setLayerType(View.LAYER_TYPE_SOFTWARE,null);setFocusable(true);}
        void rect(float l,float t,float r,float b,int color){p.setShader(null);p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRect(l,t,r,b,p);}
        void round(float l,float t,float r,float b,float rad,int color){p.setShader(null);p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,rad,rad,p);}
        void strokeRound(float l,float t,float r,float b,float rad,int color,float sw){p.setShader(null);p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(sw);c.drawRoundRect(l,t,r,b,rad,rad,p);p.setStyle(Paint.Style.FILL);}
        void txt(String s,float x,float y,float size,int color,boolean bold){p.setShader(null);p.setColor(color);p.setTextSize(size);p.setTypeface(bold?Typeface.create("sans-serif",Typeface.BOLD):Typeface.create("sans-serif",Typeface.NORMAL));p.setTextAlign(Paint.Align.CENTER);p.setStyle(Paint.Style.FILL);c.drawText(s,x,y,p);}
        void line(float x,float y,float x2,float y2,int color,float sw){p.setShader(null);p.setColor(color);p.setStrokeWidth(sw);p.setStyle(Paint.Style.STROKE);c.drawLine(x,y,x2,y2,p);p.setStyle(Paint.Style.FILL);}
        void circle(float x,float y,float r,int color){p.setShader(null);p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawCircle(x,y,r,p);}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);c=canvas;sx=getWidth()/430f;sy=getHeight()/864f;c.save();c.scale(sx,sy);drawDevice();c.restore();}
        void drawDevice(){
            // Rubberized black GPS 72 body, matching the supplied reference proportions.
            rect(0,0,430,864,Color.rgb(34,35,36));
            p.setShader(new LinearGradient(0,0,0,864,Color.rgb(37,38,39),Color.rgb(7,8,8),Shader.TileMode.CLAMP));
            c.drawRoundRect(11,-12,419,878,52,52,p);p.setShader(null);
            strokeRound(11,-12,419,878,52,Color.rgb(54,55,56),2);
            // Garmin striped globe emblem
            circle(215,43,35,Color.rgb(192,207,211));
            c.save();Path clip=new Path();clip.addCircle(215,43,35,Path.Direction.CW);c.clipPath(clip);
            for(int y=13;y<78;y+=7)rect(176,y,254,y+3,Color.rgb(26,29,32));
            circle(207,43,12,Color.BLACK);circle(229,31,8,Color.BLACK);c.restore();
            txt("ZOOM",215,96,14,pale,false);
            button("IN",174,120,60,38);button("OUT",256,120,60,38);
            txt("MOB",87,131,13,pale,false);
            button("GOTO",87,164,82,43);button("PAGE",344,164,82,43);
            // Backlight key
            button("",87,229,82,43);drawSun(87,229);
            button("MENU",344,229,82,43);
            // Central directional rocker
            circle(215,229,59,Color.rgb(5,6,7));circle(215,229,54,Color.rgb(22,23,24));
            p.setShader(new RadialGradient(215,216,58,new int[]{Color.rgb(35,36,37),Color.rgb(10,11,12)},null,Shader.TileMode.CLAMP));c.drawCircle(215,229,51,p);p.setShader(null);
            strokeCircle(215,229,57,Color.rgb(4,5,6),3);strokeCircle(215,229,52,Color.rgb(48,49,50),2);
            button("QUIT",87,294,82,43);button("ENTER",344,294,82,43);
            txt("GPS 72",215,331,27,Color.rgb(202,213,214),true);txt("MARK",344,349,13,pale,false);
            // Recessed monochrome LCD
            round(54,352,376,823,20,Color.rgb(4,5,5));
            strokeRound(54,352,376,823,20,Color.rgb(19,20,20),3);
            rect(62,360,368,815,lcd);
            if(light){rect(62,360,368,815,Color.argb(48,255,255,175));}
            drawScreen();
            txt("GARMIN",215,860,22,Color.rgb(210,213,214),true);
        }
        void strokeCircle(float x,float y,float r,int color,float sw){p.setShader(null);p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(sw);c.drawCircle(x,y,r,p);p.setStyle(Paint.Style.FILL);}
        void button(String label,float x,float y,float w,float h){
            p.setShader(new LinearGradient(x,y-h/2,x,y+h/2,new int[]{Color.rgb(79,80,81),Color.rgb(38,39,40),Color.rgb(5,6,7)},null,Shader.TileMode.CLAMP));
            c.drawRoundRect(x-w/2,y-h/2+3,x+w/2,y+h/2+3,h/2,h/2,p);p.setShader(null);
            strokeRound(x-w/2,y-h/2,x+w/2,y+h/2,h/2,Color.rgb(27,28,29),1.2f);
            if(!label.isEmpty())txt(label,x,y+6,16,Color.rgb(239,240,240),true);
        }
        void drawSun(float x,float y){circle(x,y,7,Color.TRANSPARENT);strokeCircle(x,y,7,Color.rgb(255,48,60),2);for(int i=0;i<8;i++){double a=i*Math.PI/4;line(x+(float)Math.cos(a)*13,y+(float)Math.sin(a)*13,x+(float)Math.cos(a)*18,y+(float)Math.sin(a)*18,Color.rgb(255,48,60),2.5f);}}
        void drawScreen(){
            if(menu){drawMenu();return;}
            switch(page){case 0:drawSatellite();break;case 1:drawMap();break;case 2:drawCompass();break;case 3:drawTrip();break;case 4:drawGoto();break;}
            line(69,786,361,786,ink,1);txt(new String[]{"SATELLITE","MAP","COMPASS","TRIP","GOTO"}[page],215,805,12,ink,true);txt(recording?"REC":"HOLD",335,805,10,ink,true);
        }
        void drawSatellite(){txt("GPS STATUS",215,385,15,ink,true);txt("POSITION",215,414,11,ink,false);txt(current==null?"ACQUIRING SATELLITES":"POSITION FIXED",215,438,12,ink,true);circle(215,565,78,ink);circle(215,565,75,lcd);strokeCircle(215,565,55,ink,1);circle(215,565,3,ink);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x=(float)(215+61*Math.cos(a)),y=(float)(565+61*Math.sin(a));circle(x,y,9,i<satellites?Color.rgb(65,85,43):Color.rgb(135,130,100));txt(""+(i+1),x,y+3,9,Color.WHITE,true);}txt("FIX: "+(current==null?"SEARCHING":"3D"),215,687,13,ink,true);txt("SAT: "+satellites+"   ACC: "+(int)accuracy+"m",215,712,12,ink,false);txt(status,215,750,10,ink,false);}
        void drawMap(){txt("TRACK / POSITION",215,385,14,ink,true);for(int x=75;x<360;x+=24)line(x,405,x,765,Color.rgb(151,148,112),.7f);for(int y=410;y<770;y+=24)line(70,y,360,y,Color.rgb(151,148,112),.7f);if(track.size()>1){p.setColor(Color.rgb(45,75,42));p.setStrokeWidth(2.5f);p.setStyle(Paint.Style.STROKE);Path path=new Path();double[] base=track.get(track.size()-1);int first=Math.max(0,track.size()-300);for(int i=first;i<track.size();i++){double[] q=track.get(i);float x=(float)(215+(q[1]-base[1])*65000*zoom),y=(float)(590-(q[0]-base[0])*65000*zoom);if(i==first)path.moveTo(x,y);else path.lineTo(x,y);}c.drawPath(path,p);p.setStyle(Paint.Style.FILL);}circle(215,590,5,Color.rgb(155,35,30));txt(current==null?"NO POSITION":String.format(Locale.US,"%.5f  %.5f",current.getLatitude(),current.getLongitude()),215,752,11,ink,true);txt("ZOOM "+zoom,215,425,10,ink,false);}
        void drawCompass(){txt("COMPASS",215,385,15,ink,true);circle(215,590,110,ink);circle(215,590,106,lcd);strokeCircle(215,590,91,ink,1.5f);for(int i=0;i<36;i++){double a=i*Math.PI/18;float r=i%3==0?94:100;line((float)(215+r*Math.sin(a)),(float)(590-r*Math.cos(a)),(float)(215+106*Math.sin(a)),(float)(590-106*Math.cos(a)),ink,i%3==0?2:1);}txt("N",215,485,16,ink,true);txt("E",319,596,14,ink,true);txt("S",215,700,14,ink,true);txt("W",111,596,14,ink,true);if(!Float.isNaN(heading)){double a=Math.toRadians(heading);line(215,590,(float)(215+78*Math.sin(a)),(float)(590-78*Math.cos(a)),Color.rgb(150,35,25),4);txt(String.format(Locale.US,"%03.0f°",heading),215,625,15,ink,true);}else txt("NO COMPASS",215,625,11,ink,true);}
        void drawTrip(){txt("TRIP COMPUTER",215,385,15,ink,true);String[] labels={"TRIP ODOMETER","MOVING SPEED","MAX SPEED","ALTITUDE","ELAPSED TIME","TRACK POINTS","GPS ACCURACY"};String[] vals={String.format(Locale.US,"%.2f km",tripDistance/1000),current!=null&&current.hasSpeed()?String.format(Locale.US,"%.1f km/h",current.getSpeed()*3.6):"--",String.format(Locale.US,"%.1f km/h",tripMaxSpeed),current!=null&&current.hasAltitude()?String.format(Locale.US,"%.0f m",current.getAltitude()):"--",String.format(Locale.US,"%d min",(System.currentTimeMillis()-startTime)/60000),""+track.size(),String.format(Locale.US,"%.0f m",accuracy)};for(int i=0;i<labels.length;i++){int y=430+i*45;txt(labels[i],145,y,10,ink,false);txt(vals[i],295,y,12,ink,true);line(75,y+12,355,y+12,Color.rgb(151,148,112),.8f);}}
        void drawGoto(){txt("GOTO / WAYPOINTS",215,385,14,ink,true);if(waypoints.isEmpty()){txt("NO WAYPOINTS",215,560,15,ink,true);txt("PRESS MARK TO SAVE",215,590,11,ink,false);return;}if(selectedWaypoint<0)selectedWaypoint=0;Waypoint w=waypoints.get(selectedWaypoint);txt(w.name,215,450,17,ink,true);txt(String.format(Locale.US,"LAT  %.5f",w.lat),215,490,13,ink,false);txt(String.format(Locale.US,"LON  %.5f",w.lon),215,520,13,ink,false);if(current!=null){float[] r=new float[2];Location.distanceBetween(current.getLatitude(),current.getLongitude(),w.lat,w.lon,r);txt(String.format(Locale.US,"DIST  %.2f km",r[0]/1000),215,580,14,ink,true);txt(String.format(Locale.US,"BRG  %.0f°",r[1]<0?r[1]+360:r[1]),215,610,14,ink,true);}txt("GOTO KEY: NEXT POINT",215,700,11,ink,false);}
        void drawMenu(){txt("MAIN MENU",215,390,17,ink,true);String[] m={"EXPORT TRACK (GPX)",recording?"PAUSE TRACK LOG":"RESUME TRACK LOG","CLEAR TRACK LOG","WAYPOINTS: "+waypoints.size()};for(int i=0;i<m.length;i++){int y=455+i*58;if(i==menuChoice)round(75,y-24,355,y+13,4,Color.rgb(143,147,105));txt(m[i],215,y,13,ink,true);}txt("UP / DOWN  SELECT",215,740,10,ink,false);}
        @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX()/sx,y=e.getY()/sy;
            if(y>350&&y<825){if(menu){if(y<500)menuChoice=0;else if(y<560)menuChoice=1;else if(y<620)menuChoice=2;else menuChoice=3;selectMenu();}else if(x<215)action("PAGE");else action("ENTER");return true;}
            if(y>270&&y<320){if(x<180)action("QUIT");else action("ENTER");}
            else if(y>205&&y<255){if(x<145)action("LIGHT");else if(x>285)action("MENU");else if(x<190)action("LEFT");else if(x>240)action("RIGHT");else if(y<229)action("UP");else action("DOWN");}
            else if(y>140&&y<190){if(x<180)action("GOTO");else if(x>260)action("PAGE");}
            else if(y>100&&y<140){if(x<145)action("MOB");else if(x<215)action("IN");else action("OUT");}
            return true;}
        void selectMenu(){if(menuChoice==0)exportGpx();else if(menuChoice==1){recording=!recording;status=recording?"TRACK RECORDING":"TRACK PAUSED";}else if(menuChoice==2){track.clear();tripDistance=0;status="TRACK CLEARED";}else page=4;menu=false;saveData();invalidate();}
    }
}
