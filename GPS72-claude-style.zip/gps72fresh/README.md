# GPS 72 Native

A native Android recreation inspired by the Garmin GPS 72 handheld unit. The interface is drawn locally in Java and follows the physical button/screen layout.

## Features
- GPS position, fix state and reported accuracy
- Live track recording with persistent local storage
- Trip distance, speed, maximum speed, altitude and elapsed time
- Compass heading when the device provides a rotation-vector sensor
- Waypoint marking, waypoint list and GOTO distance/bearing
- MOB (Man Overboard) point marking
- GPX export through Android's document picker
- Track pause/resume and clear controls in the menu
- GPS 72-style screen, keypad, page navigation and backlight overlay

## Build
Open in Android Studio or run `gradle assembleDebug` with JDK 17 and Gradle 8.7. GitHub Actions workflow is included and can be started manually.

The app requires Android location permission and a device with GPS for live position. Compass availability depends on device sensors. The map page is an offline track plot, not a street-map database.
