package com.example.gps72;

import android.util.JsonReader;
import android.util.JsonToken;
import java.io.IOException;
import java.util.ArrayList;

/** Streaming GeoJSON parser for the offline land outline (polygons + bounding boxes). */
final class LandData {
    private LandData() { }

    static void readGeo(JsonReader r, ArrayList<ArrayList<float[]>> np, ArrayList<float[]> nb) throws IOException {
        if (r.peek() != JsonToken.BEGIN_OBJECT) { r.skipValue(); return; }
        r.beginObject();
        while (r.hasNext()) {
            String k = r.nextName();
            if (k.equals("features") || k.equals("geometries")) { r.beginArray(); while (r.hasNext()) readGeo(r, np, nb); r.endArray(); }
            else if (k.equals("geometry")) readGeo(r, np, nb);
            else if (k.equals("coordinates")) addCoords(readCoords(r), np, nb);
            else r.skipValue();
        }
        r.endObject();
    }
    static Object readCoords(JsonReader r) throws IOException {
        r.beginArray();
        if (r.peek() == JsonToken.NUMBER) {
            double[] p = new double[2]; int n = 0;
            while (r.hasNext()) { double v = r.nextDouble(); if (n < 2) p[n] = v; n++; }
            r.endArray(); return p;
        }
        ArrayList<Object> l = new ArrayList<>();
        while (r.hasNext()) l.add(readCoords(r));
        r.endArray(); return l;
    }
    @SuppressWarnings("unchecked")
    static void addCoords(Object o, ArrayList<ArrayList<float[]>> np, ArrayList<float[]> nb) {
        if (!(o instanceof ArrayList)) return;
        ArrayList<Object> l = (ArrayList<Object>) o;
        if (l.isEmpty() || !(l.get(0) instanceof ArrayList)) return;
        ArrayList<Object> f = (ArrayList<Object>) l.get(0);
        if (f.isEmpty()) return;
        if (f.get(0) instanceof double[]) {
            ArrayList<float[]> out = new ArrayList<>();
            float[] box = {90, -90, 180, -180};
            for (int k = 0; k < l.size(); k++) {
                ArrayList<Object> ring = (ArrayList<Object>) l.get(k);
                float[] a = new float[ring.size() * 2];
                for (int i = 0; i < ring.size(); i++) {
                    double[] p = (double[]) ring.get(i);
                    a[2 * i] = (float) p[1]; a[2 * i + 1] = (float) p[0];
                    if (k == 0) { box[0] = Math.min(box[0], a[2 * i]); box[1] = Math.max(box[1], a[2 * i]); box[2] = Math.min(box[2], a[2 * i + 1]); box[3] = Math.max(box[3], a[2 * i + 1]); }
                }
                out.add(a);
            }
            np.add(out); nb.add(box);
        } else for (Object po : l) addCoords(po, np, nb);
    }
}
