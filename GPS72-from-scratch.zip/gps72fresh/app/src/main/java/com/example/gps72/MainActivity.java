package com.example.gps72;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.hardware.*;
import android.location.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity implements LocationListener, SensorEventListener {
    private LocationManager locationManager;
    private SensorManager sensorManager;
    private Sensor rotationSensor;
    private GpsScreen screen;
    private final ArrayList<double[]> track = new ArrayList<>();
    private final ArrayList<Waypoint> waypoints = new ArrayList<>();
    private final android.os.Handler handler = new android.os.Handler();
    private SharedPreferences prefs;
    private Location current;
    private float heading = Float.NaN, accuracy = 0;
    private int satellites = 0;
    private boolean recording = true, light = false, menu = false;
    private int page = 0, selectedWaypoint = -1, zoom = 3;
    private long startTime = System.currentTimeMillis();
    private double tripDistance = 0, tripMaxSpeed = 0;
    private String status = "SEARCHING FOR GPS";
    private static final int REQ_GPS = 10, CREATE_GPX = 11;

    static class Waypoint { String name; double lat, lon; Waypoint(String n,double a,double o){name=n;lat=a;lon=o;} }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystem();
        prefs=getSharedPreferences("gps72_data",MODE_PRIVATE);
        loadData();
        locationManager=(LocationManager)getSystemService(LOCATION_SERVICE);
        sensorManager=(SensorManager)getSystemService(SENSOR_SERVICE);
        rotationSensor=sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        screen=new GpsScreen(this); setContentView(screen);
        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION},REQ_GPS);
        else startGps();
        handler.post(tick);
    }
    private void hideSystem(){getWindow().getDecorView().setSystemUiVisibility(5894|1024|512|4096);}
    @Override public void onWindowFocusChanged(boolean f){super.onWindowFocusChanged(f);if(f)hideSystem();}
    @Override protected void onResume(){super.onResume();if(rotationSensor!=null)sensorManager.registerListener(this,rotationSensor,SensorManager.SENSOR_DELAY_UI);if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED)startGps();}
    @Override protected void onPause(){super.onPause();sensorManager.unregisterListener(this);if(locationManager!=null)locationManager.removeUpdates(this);saveData();}
    @Override protected void onDestroy(){super.onDestroy();handler.removeCallbacks(tick);saveData();}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==REQ_GPS&&g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)startGps();else status="LOCATION PERMISSION REQUIRED";}
    @SuppressWarnings("MissingPermission") private void startGps(){try{locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,0.5f,this);Location last=locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);if(last!=null&&current==null)onLocationChanged(last);status="GPS ACTIVE - WAITING FIX";}catch(Exception e){status="GPS PROVIDER UNAVAILABLE";}}
    @Override public void onLocationChanged(Location l){if(l==null)return; if(current!=null){float d=current.distanceTo(l);if(d>0.8f&&d<100)tripDistance+=d;}current=l;accuracy=l.hasAccuracy()?l.getAccuracy():0;if(l.hasSpeed()){double s=l.getSpeed()*3.6;tripMaxSpeed=Math.max(tripMaxSpeed,s);}status="3D GPS FIX";if(recording&&(track.isEmpty()||distance(track.get(track.size()-1),l.getLatitude(),l.getLongitude())>2)){track.add(new double[]{l.getLatitude(),l.getLongitude(),System.currentTimeMillis()});if(track.size()>5000)track.remove(0);}saveData();invalidate();}
    @Override public void onProviderEnabled(String p){} @Override public void onProviderDisabled(String p){status="GPS DISABLED";} @Override public void onStatusChanged(String p,int s,Bundle b){}
    @Override public void onSensorChanged(SensorEvent e){if(e.sensor.getType()==Sensor.TYPE_ROTATION_VECTOR){float[] m=new float[9],o=new float[3];SensorManager.getRotationMatrixFromVector(m,e.values);SensorManager.getOrientation(m,o);heading=(float)Math.toDegrees(o[0]);heading=(heading+360)%360;invalidate();}}
    @Override public void onAccuracyChanged(Sensor s,int a){}
    private double distance(double[] p,double lat,double lon){float[] r=new float[1];Location.distanceBetween(p[0],p[1],lat,lon,r);return r[0];}
    private void saveData(){if(prefs==null)return;StringBuilder b=new StringBuilder();for(double[] p:track)b.append(p[0]).append(',').append(p[1]).append(',').append((long)p[2]).append(';');StringBuilder w=new StringBuilder();for(Waypoint p:waypoints)w.append(encode(p.name)).append(',').append(p.lat).append(',').append(p.lon).append(';');prefs.edit().putString("track",b.toString()).putString("wps",w.toString()).putFloat("trip",(float)tripDistance).putFloat("max",(float)tripMaxSpeed).putBoolean("record",recording).apply();}
    private String encode(String s){return android.util.Base64.encodeToString(s.getBytes(java.nio.charset.StandardCharsets.UTF_8),android.util.Base64.NO_WRAP);}
    private void loadData(){tripDistance=prefs.getFloat("trip",0);tripMaxSpeed=prefs.getFloat("max",0);recording=prefs.getBoolean("record",true);String t=prefs.getString("track","");for(String x:t.split(";")){try{String[] a=x.split(",");if(a.length==3)track.add(new double[]{Double.parseDouble(a[0]),Double.parseDouble(a[1]),Double.parseDouble(a[2])});}catch(Exception ignored){}}String w=prefs.getString("wps","");for(String x:w.split(";")){try{String[] a=x.split(",");if(a.length==3)waypoints.add(new Waypoint(new String(android.util.Base64.decode(a[0],0),java.nio.charset.StandardCharsets.UTF_8),Double.parseDouble(a[1]),Double.parseDouble(a[2])));}catch(Exception ignored){}}}
    private void mark(){if(current==null){status="NO GPS POSITION TO MARK";return;}String n="WPT "+(waypoints.size()+1);waypoints.add(new Waypoint(n,current.getLatitude(),current.getLongitude()));status="WAYPOINT SAVED: "+n;saveData();}
    private void mob(){if(current==null){status="NO GPS POSITION FOR MOB";return;}waypoints.add(new Waypoint("MOB",current.getLatitude(),current.getLongitude()));selectedWaypoint=waypoints.size()-1;status="MAN OVERBOARD POSITION SAVED";saveData();page=4;}
    private void exportGpx(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/gpx+xml");i.putExtra(Intent.EXTRA_TITLE,"GPS72-track.gpx");startActivityForResult(i,CREATE_GPX);}
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==CREATE_GPX&&c==RESULT_OK&&d!=null){try(OutputStream o=getContentResolver().openOutputStream(d.getData())){o.write(makeGpx().getBytes(java.nio.charset.StandardCharsets.UTF_8));status="GPX FILE EXPORTED";}catch(Exception e){status="GPX EXPORT FAILED";}invalidate();}}
    private String makeGpx(){StringBuilder b=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<gpx version=\"1.1\" creator=\"GPS 72\" xmlns=\"http://www.topografix.com/GPX/1/1\">\n");for(Waypoint w:waypoints)b.append("<wpt lat=\"").append(w.lat).append("\" lon=\"").append(w.lon).append("\"><name>").append(xml(w.name)).append("</name></wpt>\n");b.append("<trk><name>GPS 72 Track</name><trkseg>\n");for(double[] p:track)b.append("<trkpt lat=\"").append(p[0]).append("\" lon=\"").append(p[1]).append("\"><time>").append(new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'",Locale.US).format(new Date((long)p[2]))).append("</time></trkpt>\n");return b.append("</trkseg></trk></gpx>").toString();}
    private String xml(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;");}
    private Runnable tick=()->{if(screen!=null)screen.invalidate();handler.postDelayed(tick,1000);};
    private void action(String a){switch(a){case "PAGE":page=(page+1)%5;menu=false;break;case "QUIT":if(menu)menu=false;else page=(page+4)%5;break;case "MENU":menu=!menu;break;case "ENTER":if(menu){menu=false;exportGpx();}else mark();break;case "GOTO":if(!waypoints.isEmpty()){selectedWaypoint=(selectedWaypoint+1)%waypoints.size();page=4;status="GOTO: "+waypoints.get(selectedWaypoint).name;}else status="NO WAYPOINTS - PRESS MARK";break;case "MOB":mob();break;case "LIGHT":light=!light;break;case "IN":zoom=Math.min(8,zoom+1);break;case "OUT":zoom=Math.max(1,zoom-1);break;case "UP":case "DOWN":case "LEFT":case "RIGHT":if(menu){if(a.equals("UP"))menuChoice=(menuChoice+3)%4;else if(a.equals("DOWN"))menuChoice=(menuChoice+1)%4;}break;}saveData();screen.invalidate();}
    private int menuChoice=0;

    class GpsScreen extends View {
        Canvas c; Paint p=new Paint(3); float sx,sy; int ink=Color.rgb(30,35,25),paper=Color.rgb(190,184,145),dark=Color.rgb(28,30,28),green=Color.rgb(57,76,45);
        GpsScreen(Context x){super(x);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
        void fill(float l,float t,float r,float b,int color){p.setColor(color);p.setStyle(Paint.Style.FILL);c.drawRect(l,t,r,b,p);} void text(String s,float x,float y,int size,int color,boolean bold){p.setColor(color);p.setTextSize(size);p.setTypeface(bold?Typeface.create("monospace",Typeface.BOLD):Typeface.create("monospace",Typeface.NORMAL));p.setStyle(Paint.Style.FILL);c.drawText(s,x,y,p);} void line(float x,float y,float a,float b,int color,float w){p.setColor(color);p.setStrokeWidth(w);p.setStyle(Paint.Style.STROKE);c.drawLine(x,y,a,b,p);p.setStyle(Paint.Style.FILL);} void circle(float x,float y,float r,int color,boolean stroke){p.setColor(color);p.setStyle(stroke?Paint.Style.STROKE:Paint.Style.FILL);p.setStrokeWidth(3);c.drawCircle(x,y,r,p);p.setStyle(Paint.Style.FILL);}
        @Override protected void onDraw(Canvas canvas){super.onDraw(canvas);c=canvas;sx=getWidth()/430f;sy=getHeight()/850f;c.save();c.scale(sx,sy);drawDevice();c.restore();}
        void drawDevice(){fill(0,0,430,850,Color.rgb(42,39,35));p.setShader(new LinearGradient(35,20,400,820,Color.rgb(20,22,23),Color.rgb(7,8,9),Shader.TileMode.CLAMP));c.drawRoundRect(22,12,408,838,42,42,p);p.setShader(null);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(Color.rgb(91,91,84));c.drawRoundRect(22,12,408,838,42,42,p);p.setStyle(Paint.Style.FILL);
            text("◉",180,85,48,Color.LTGRAY,true);text("ZOOM",180,218,14,Color.LTGRAY,true);
            button("MOB",105,268,48,25);button("+",198,252,25,25);button("OUT",281,252,46,25);button("GOTO",105,307,55,25);button("PAGE",325,307,54,25);button("LIGHT",105,368,52,28);button("MENU",326,368,52,28);circle(215,367,61,Color.rgb(8,9,10),false);circle(215,367,61,Color.rgb(82,83,78),true);button("QUIT",111,433,56,27);button("ENTER",326,433,58,27);text("GPS 72",184,482,25,Color.rgb(190,196,205),true);text("MARK",329,477,13,Color.LTGRAY,true);
            fill(63,506,367,810,Color.rgb(70,68,53));p.setColor(Color.rgb(130,127,102));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);c.drawRoundRect(60,500,370,814,18,18,p);p.setStyle(Paint.Style.FILL);fill(70,510,360,805,paper);if(light){fill(70,510,360,805,Color.argb(85,255,255,190));}
            drawScreen();text("GARMIN",176,830,23,Color.LTGRAY,true);
        }
        void button(String s,float x,float y,float w,float h){p.setColor(Color.rgb(5,6,7));c.drawRoundRect(x-w/2,y-h/2,x+w/2,y+h/2,17,17,p);p.setColor(Color.rgb(110,110,103));p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawRoundRect(x-w/2,y-h/2,x+w/2,y+h/2,17,17,p);p.setStyle(Paint.Style.FILL);text(s,x-w/2+7,y+5,14,Color.rgb(225,226,218),true);}
        void drawScreen(){fill(74,514,356,800,paper);text("GPS 72      "+new SimpleDateFormat("HH:mm:ss",Locale.US).format(new Date()),82,532,12,ink,true);line(75,538,355,538,ink,1);if(menu){drawMenu();return;}switch(page){case 0:drawSatellite();break;case 1:drawMap();break;case 2:drawCompass();break;case 3:drawTrip();break;case 4:drawGoto();break;}line(75,777,355,777,ink,1);text(new String[]{"SATELLITE","MAP","COMPASS","TRIP","GOTO"}[page],82,794,12,ink,true);text(recording?"REC":"HOLD",296,794,11,ink,true);}
        void drawSatellite(){text("GPS STATUS",82,557,14,ink,true);circle(215,644,70,ink,true);circle(215,644,4,ink,false);for(int i=0;i<8;i++){double a=i*Math.PI/4;float x=(float)(215+58*Math.cos(a)),y=(float)(644+58*Math.sin(a));circle(x,y,10,i<satellites?green:Color.rgb(135,130,100),false);text(""+(i+1),x-4,y+4,9,Color.WHITE,true);}text("FIX: "+(current==null?"SEARCH":"3D"),83,738,12,ink,true);text("SAT: "+satellites+"   ACC: "+(int)accuracy+"m",83,758,11,ink,true);}
        void drawMap(){text("TRACK / POSITION",82,557,13,ink,true);for(int x=85;x<355;x+=27)line(x,570,x,752,Color.rgb(165,158,126),1);for(int y=575;y<755;y+=27)line(80,y,350,y,Color.rgb(165,158,126),1);if(track.size()>1){p.setColor(Color.rgb(48,74,52));p.setStrokeWidth(3);p.setStyle(Paint.Style.STROKE);Path path=new Path();double[] base=track.get(track.size()-1);for(int i=Math.max(0,track.size()-250);i<track.size();i++){double[] q=track.get(i);float x=(float)(215+(q[1]-base[1])*80000*zoom),y=(float)(665-(q[0]-base[0])*80000*zoom);if(i==Math.max(0,track.size()-250))path.moveTo(x,y);else path.lineTo(x,y);}c.drawPath(path,p);p.setStyle(Paint.Style.FILL);}circle(215,665,6,Color.rgb(160,45,35),false);text(current==null?"NO POSITION":String.format(Locale.US,"%.5f %.5f",current.getLatitude(),current.getLongitude()),82,754,10,ink,true);text("ZOOM "+zoom,280,575,10,ink,true);}
        void drawCompass(){text("COMPASS",82,557,14,ink,true);circle(215,658,88,ink,true);circle(215,658,3,ink,false);for(int i=0;i<36;i++){double a=i*Math.PI/18;float r1=i%3==0?77:82;line((float)(215+r1*Math.sin(a)),(float)(658-r1*Math.cos(a)),(float)(215+88*Math.sin(a)),(float)(658-88*Math.cos(a)),ink,i%3==0?2:1);}text("N",209,580,15,ink,true);text("E",304,663,13,ink,true);text("S",210,750,13,ink,true);text("W",118,663,13,ink,true);if(!Float.isNaN(heading)){double a=Math.toRadians(heading);line(215,658,(float)(215+68*Math.sin(a)),(float)(658-68*Math.cos(a)),Color.rgb(150,35,25),5);text(String.format(Locale.US,"%03.0f°",heading),188,691,15,ink,true);}else text("NO SENSOR",170,691,11,ink,true);}
        void drawTrip(){text("TRIP COMPUTER",82,557,14,ink,true);String[] labels={"TRIP ODOMETER","MOVING SPEED","MAX SPEED","ALTITUDE","ELAPSED TIME","TRACK POINTS"};String[] vals={String.format(Locale.US,"%.2f km",tripDistance/1000),current!=null&&current.hasSpeed()?String.format(Locale.US,"%.1f km/h",current.getSpeed()*3.6):"--",String.format(Locale.US,"%.1f km/h",tripMaxSpeed),current!=null&&current.hasAltitude()?String.format(Locale.US,"%.0f m",current.getAltitude()):"--",String.format(Locale.US,"%d min",(System.currentTimeMillis()-startTime)/60000),""+track.size()};for(int i=0;i<labels.length;i++){int y=590+i*29;text(labels[i],84,y,10,ink,false);text(vals[i],252,y,12,ink,true);line(82,y+7,348,y+7,Color.rgb(160,154,125),1);}}
        void drawGoto(){text("GOTO / WAYPOINTS",82,557,13,ink,true);if(waypoints.isEmpty()){text("NO WAYPOINTS",112,646,14,ink,true);text("PRESS ENTER TO MARK",91,670,11,ink,false);return;}if(selectedWaypoint<0)selectedWaypoint=0;Waypoint w=waypoints.get(selectedWaypoint);text(w.name,90,590,16,ink,true);text(String.format(Locale.US,"%.5f",w.lat),90,621,12,ink,false);text(String.format(Locale.US,"%.5f",w.lon),90,644,12,ink,false);if(current!=null){float[] r=new float[2];Location.distanceBetween(current.getLatitude(),current.getLongitude(),w.lat,w.lon,r);text(String.format(Locale.US,"DIST %.2f km",r[0]/1000),90,687,13,ink,true);text(String.format(Locale.US,"BRG %.0f°",r[1]<0?r[1]+360:r[1]),90,711,13,ink,true);}text("GOTO KEY: NEXT POINT",90,752,10,ink,false);}
        void drawMenu(){text("MAIN MENU",90,565,16,ink,true);String[] m={"EXPORT TRACK (GPX)",recording?"PAUSE TRACK LOG":"RESUME TRACK LOG","CLEAR TRACK LOG","WAYPOINTS: "+waypoints.size()};for(int i=0;i<m.length;i++){int y=602+i*35;if(i==menuChoice)fill(82,y-17,348,y+7,Color.rgb(116,126,88));text(m[i],91,y,11,ink,true);}text("ENTER SELECT / QUIT BACK",83,755,9,ink,false);}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_UP)return true;float x=e.getX()/sx,y=e.getY()/sy;if(y>500&&y<815){if(menu){if(menuChoice==0)exportGpx();else if(menuChoice==1){recording=!recording;status=recording?"TRACK RECORDING":"TRACK PAUSED";}else if(menuChoice==2){track.clear();tripDistance=0;status="TRACK CLEARED";}else page=4;menu=false;}else if(x<215)action("PAGE");else action("ENTER");return true;}if(y<500){if(y>340&&y<400){if(x<160)action("LIGHT");else if(x>280)action("MENU");}else if(y>410){if(x<210)action("QUIT");else action("ENTER");}else if(y>285&&y<330){if(x<155)action("GOTO");else if(x>285)action("PAGE");}else if(y>235&&y<280){if(x<145)action("MOB");else if(x<250)action("IN");else action("OUT");}else if(y>=330&&y<410&&x>280)action("MENU");else if(y>340&&y<400&&x<160)action("LIGHT");else if(y>400&&y<470&&x<175)action("QUIT");else if(y>400&&y<470)action("ENTER");else if(x>150&&x<280){if(y<350)action("UP");else if(y<390)action("DOWN");} }return true;}
    }
}
