package com.example.gps72;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;

/** Bottom icon bar: page shortcuts normally, and ESC / arrows / OK / options while a dialog or list is open. */
public class NavBar extends View {
    GpsView gv;
    Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    float dn;
    Handler h = new Handler(Looper.getMainLooper());
    int down = -1;
    Runnable rp;
    static final String[] DK = {"quit", "up", "down", "left", "right", "enter", "menu"};

    public NavBar(Context c, GpsView g) {
        super(c);
        gv = g;
        dn = c.getResources().getDisplayMetrics().density;
    }

    boolean dlg() { return gv.ui != null || gv.sub != 0; }

    @Override
    protected void onMeasure(int w, int hh) {
        setMeasuredDimension(MeasureSpec.getSize(w), (int) (62 * dn));
    }

    int cell(float x) {
        float m = 6 * dn, cw = (getWidth() - 2 * m) / 7f;
        int i = (int) Math.floor((x - m) / cw);
        return i < 0 || i > 6 ? -1 : i;
    }

    @Override
    protected void onDraw(Canvas c) {
        int W = getWidth(), H = getHeight();
        c.drawColor(0xFF161616);
        float m = 6 * dn, cw = (W - 2 * m) / 7f;
        P.setStyle(Paint.Style.FILL);
        P.setColor(0xFF3A3A3A);
        c.drawRoundRect(new RectF(m, 4 * dn, W - m, H - 4 * dn), 14 * dn, 14 * dn, P);
        boolean d = dlg();
        for (int i = 0; i < 7; i++) {
            float cx = m + cw * (i + 0.5f), cy = H / 2f, s = 11 * dn;
            if (down == i) {
                P.setStyle(Paint.Style.FILL);
                P.setColor(0x44FFFFFF);
                c.drawRoundRect(new RectF(m + cw * i + 3 * dn, 7 * dn, m + cw * (i + 1) - 3 * dn, H - 7 * dn), 10 * dn, 10 * dn, P);
            }
            boolean act = !d && ((i == 0 && gv.page == 4) || (i == 1 && gv.page == 1) || (i == 3 && gv.page == 0) || (i == 4 && gv.page == 2) || (i == 5 && gv.page == 3));
            P.setColor(act ? 0xFFA9CC7E : 0xFFFFFFFF);
            icon(c, d ? 10 + i : i, cx, cy, s);
            if (i > 0) {
                P.setStyle(Paint.Style.STROKE);
                P.setStrokeWidth(1);
                P.setColor(0xFF555555);
                float sx = m + cw * i;
                c.drawLine(sx, 14 * dn, sx, H - 14 * dn, P);
            }
        }
    }

    void icon(Canvas c, int id, float x, float y, float s) {
        P.setStrokeCap(Paint.Cap.ROUND);
        P.setStrokeJoin(Paint.Join.ROUND);
        Path p = new Path();
        switch (id) {
            case 0:
                P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(s * 0.28f);
                for (int k = -1; k <= 1; k++) c.drawLine(x - s * 0.9f, y + k * s * 0.6f, x + s * 0.9f, y + k * s * 0.6f, P);
                break;
            case 1:
                P.setStyle(Paint.Style.FILL);
                p.moveTo(x - s * 1.2f, y - s * 0.8f); p.lineTo(x - s * 0.4f, y - s * 0.55f); p.lineTo(x - s * 0.4f, y + s * 0.95f); p.lineTo(x - s * 1.2f, y + s * 0.7f); p.close();
                p.moveTo(x - s * 0.3f, y - s * 0.55f); p.lineTo(x + s * 0.3f, y - s * 0.95f); p.lineTo(x + s * 0.3f, y + s * 0.55f); p.lineTo(x - s * 0.3f, y + s * 0.95f); p.close();
                p.moveTo(x + s * 0.4f, y - s * 0.95f); p.lineTo(x + s * 1.2f, y - s * 0.65f); p.lineTo(x + s * 1.2f, y + s * 0.85f); p.lineTo(x + s * 0.4f, y + s * 0.55f); p.close();
                c.drawPath(p, P);
                break;
            case 2:
                P.setStyle(Paint.Style.FILL);
                c.drawRect(x - s * 0.95f, y - s * 1.1f, x - s * 0.75f, y + s * 1.1f, P);
                p.moveTo(x - s * 0.75f, y - s * 1.0f); p.lineTo(x + s * 0.2f, y - s * 0.85f); p.lineTo(x + s * 1.1f, y - s * 0.7f); p.lineTo(x + s * 0.4f, y - s * 0.25f); p.lineTo(x + s * 1.1f, y + s * 0.1f); p.lineTo(x - s * 0.75f, y + s * 0.2f); p.close();
                c.drawPath(p, P);
                break;
            case 3:
                P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(s * 0.22f);
                c.drawCircle(x, y, s * 0.85f, P);
                c.drawLine(x, y - s * 1.25f, x, y - s * 0.7f, P); c.drawLine(x, y + s * 0.7f, x, y + s * 1.25f, P);
                c.drawLine(x - s * 1.25f, y, x - s * 0.7f, y, P); c.drawLine(x + s * 0.7f, y, x + s * 1.25f, y, P);
                P.setStyle(Paint.Style.FILL);
                c.drawCircle(x, y, s * 0.38f, P);
                break;
            case 4:
                P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(s * 0.2f);
                c.drawCircle(x, y, s * 1.1f, P);
                P.setStyle(Paint.Style.FILL);
                p.moveTo(x, y - s * 0.8f); p.lineTo(x + s * 0.35f, y); p.lineTo(x, y + s * 0.8f); p.lineTo(x - s * 0.35f, y); p.close();
                c.drawPath(p, P);
                break;
            case 5:
                P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(s * 0.22f);
                c.drawLine(x - s, y + s, x - s * 0.3f, y - s, P); c.drawLine(x + s, y + s, x + s * 0.3f, y - s, P);
                P.setStrokeWidth(s * 0.16f);
                c.drawLine(x, y + s * 0.8f, x, y + s * 0.4f, P); c.drawLine(x, y + s * 0.1f, x, y - s * 0.25f, P); c.drawLine(x, y - s * 0.55f, x, y - s * 0.75f, P);
                break;
            case 6:
            case 16:
                P.setStyle(Paint.Style.FILL);
                for (int k = -1; k <= 1; k++) c.drawCircle(x, y + k * s * 0.65f, s * 0.2f, P);
                break;
            case 10:
                P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(s * 0.28f);
                c.drawLine(x - s * 0.8f, y - s * 0.8f, x + s * 0.8f, y + s * 0.8f, P); c.drawLine(x + s * 0.8f, y - s * 0.8f, x - s * 0.8f, y + s * 0.8f, P);
                break;
            case 11:
                P.setStyle(Paint.Style.FILL);
                p.moveTo(x, y - s * 0.9f); p.lineTo(x + s, y + s * 0.65f); p.lineTo(x - s, y + s * 0.65f); p.close();
                c.drawPath(p, P);
                break;
            case 12:
                P.setStyle(Paint.Style.FILL);
                p.moveTo(x, y + s * 0.9f); p.lineTo(x + s, y - s * 0.65f); p.lineTo(x - s, y - s * 0.65f); p.close();
                c.drawPath(p, P);
                break;
            case 13:
                P.setStyle(Paint.Style.FILL);
                p.moveTo(x - s * 0.9f, y); p.lineTo(x + s * 0.65f, y - s); p.lineTo(x + s * 0.65f, y + s); p.close();
                c.drawPath(p, P);
                break;
            case 14:
                P.setStyle(Paint.Style.FILL);
                p.moveTo(x + s * 0.9f, y); p.lineTo(x - s * 0.65f, y - s); p.lineTo(x - s * 0.65f, y + s); p.close();
                c.drawPath(p, P);
                break;
            default:
                P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(s * 0.3f);
                p.moveTo(x - s * 0.9f, y); p.lineTo(x - s * 0.25f, y + s * 0.65f); p.lineTo(x + s * 0.95f, y - s * 0.7f);
                c.drawPath(p, P);
        }
    }

    void fire(int i, boolean rep) {
        if (dlg()) {
            gv.quiet = rep;
            gv.press(DK[i], false);
            gv.quiet = false;
        } else {
            switch (i) {
                case 0: gv.nav(4); break;
                case 1: gv.nav(1); break;
                case 2: gv.navWaypoints(); break;
                case 3: gv.nav(0); break;
                case 4: gv.nav(2); break;
                case 5: gv.nav(3); break;
                default: gv.press("menu", false);
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            down = cell(e.getX());
            if (down < 0) return true;
            invalidate();
            final int k = down;
            fire(k, false);
            if (dlg() && k >= 1 && k <= 4) {
                rp = new Runnable() { public void run() { fire(k, true); h.postDelayed(this, 120); } };
                h.postDelayed(rp, 420);
            }
            return true;
        }
        if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
            if (rp != null) h.removeCallbacks(rp);
            down = -1;
            invalidate();
        }
        return true;
    }
}
