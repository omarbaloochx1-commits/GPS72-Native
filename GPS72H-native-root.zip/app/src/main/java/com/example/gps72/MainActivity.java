package com.example.gps72;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.location.GnssStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.Priority;
import android.os.Build;
import android.os.Bundle;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import java.util.ArrayList;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.LinearLayout;

public class MainActivity extends Activity {
    GpsView gv;
    LocationManager lm;
    SensorManager sm;
    Handler h = new Handler(Looper.getMainLooper());
    boolean locStarted = false;
    FusedLocationProviderClient fc;
    LocationCallback fcb;
    float decl = 0;

    LocationListener ll = new LocationListener() {
        public void onLocationChanged(Location l) {
            try {
                decl = new GeomagneticField((float) l.getLatitude(), (float) l.getLongitude(), (float) l.getAltitude(), System.currentTimeMillis()).getDeclination();
            } catch (Exception e) { }
            gv.decl = decl;
            gv.onLoc(l);
        }
        public void onStatusChanged(String p, int s, Bundle b) { }
        public void onProviderEnabled(String p) { gv.gerr = 0; gv.postInvalidate(); }
        public void onProviderDisabled(String p) { gv.gerr = 2; gv.postInvalidate(); }
    };

    GnssStatus.Callback gcb = new GnssStatus.Callback() {
        public void onSatelliteStatusChanged(GnssStatus s) {
            int n = s.getSatelliteCount();
            int[] id = new int[n];
            float[] az = new float[n], el = new float[n], cn = new float[n];
            boolean[] us = new boolean[n];
            for (int i = 0; i < n; i++) {
                id[i] = s.getSvid(i);
                az[i] = s.getAzimuthDegrees(i);
                el[i] = s.getElevationDegrees(i);
                cn[i] = s.getCn0DbHz(i);
                us[i] = s.usedInFix(i);
            }
            gv.setSats(n, id, az, el, cn, us);
        }
    };

    SensorEventListener sl = new SensorEventListener() {
        public void onSensorChanged(SensorEvent e) {
            float[] r = new float[9], o = new float[3];
            SensorManager.getRotationMatrixFromVector(r, e.values);
            SensorManager.getOrientation(r, o);
            if (Math.abs(o[1]) > 1.0f) {
                float[] r2 = new float[9];
                SensorManager.remapCoordinateSystem(r, SensorManager.AXIS_X, SensorManager.AXIS_Z, r2);
                SensorManager.getOrientation(r2, o);
            }
            float hd = (float) Math.toDegrees(o[0]) + decl;
            gv.setCompass(((hd % 360) + 360) % 360);
        }
        public void onAccuracyChanged(Sensor s, int a) { }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        sm = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        gv = new GpsView(this);
        gv.loadLandReq = new Runnable() {
            public void run() {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, 77);
            }
        };
        setupStorage();
        gv.shareReq = new GpsView.ShareCb() {
            public void share(ArrayList<GpsView.Wp> l) {
                try { QrShare.showQr(MainActivity.this, QrShare.payloads(l), l.size()); } catch (Exception e) { gv.toast("QR error"); }
            }
        };
        gv.scanReq = new Runnable() {
            public void run() { startActivityForResult(new Intent(MainActivity.this, ScanActivity.class), 88); }
        };
        gv.importReq = new Runnable() {
            public void run() {
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, 89);
            }
        };
        gv.exportReq = new Runnable() {
            public void run() {
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/gpx+xml");
                i.putExtra(Intent.EXTRA_TITLE, "gps72-" + new java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US).format(new java.util.Date()) + ".gpx");
                startActivityForResult(i, 78);
            }
        };
        try { gv.ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Exception e) { }
        final float dn = getResources().getDisplayMetrics().density;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF161616);
        root.addView(gv, new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.VERTICAL);
        bar.setBackgroundColor(0xFF161616);
        int pd = (int) (4 * dn);
        bar.setPadding(pd, pd, pd, pd);
        String[][] rows = {
                {"GOTO:goto", "MARK:mark", "PAN:pan", "ZOOM +:zin", "ZOOM -:zout"},
                {"QUIT:quit", "PAGE:page", "MENU:menu", "ENTER:enter"},
                {"\u25C4:left", "\u25B2:up", "\u25BC:down", "\u25BA:right"}};
        for (String[] row : rows) {
            LinearLayout lr = new LinearLayout(this);
            lr.setOrientation(LinearLayout.HORIZONTAL);
            bar.addView(lr, new LinearLayout.LayoutParams(-1, (int) (50 * dn)));
            for (String d0 : row) {
                String[] q = d0.split(":");
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1f);
                lp.setMargins((int) (2 * dn), (int) (2 * dn), (int) (2 * dn), (int) (2 * dn));
                lr.addView(btn(q[0], q[1], dn), lp);
            }
        }
        root.addView(bar, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
        final android.content.SharedPreferences p0 = getSharedPreferences("g72", 0);
        final int tn = p0.getInt("tipN", 0);
        if (tn < 3) {
            p0.edit().putInt("tipN", tn + 1).apply();
            h.postDelayed(new Runnable() { public void run() { gv.toast("Swipe < > : pages"); } }, 2800);
            h.postDelayed(new Runnable() { public void run() { gv.toast("Long press: MARK"); } }, 5300);
            h.postDelayed(new Runnable() { public void run() { gv.toast("Swipe up: MENU"); } }, 7800);
        }
        hideBars();
        boolean needLoc = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED;
        boolean needNot = Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED;
        if (needLoc || needNot) {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION, "android.permission.POST_NOTIFICATIONS"}, 1);
            else requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION}, 1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] p, int[] r) {
        super.onRequestPermissionsResult(c, p, r);
        startLocation();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Sensor rv = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        if (rv != null) sm.registerListener(sl, rv, SensorManager.SENSOR_DELAY_UI);
        startLocation();
        gv.syncGpx();
        gv.scanFolder();
    }

    @Override
    protected void onPause() {
        super.onPause();
        gv.flush();
        sm.unregisterListener(sl);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        gv.flush();
        try { lm.removeUpdates(ll); lm.unregisterGnssStatusCallback(gcb); } catch (Exception e) { }
        try { if (fc != null) fc.removeLocationUpdates(fcb); } catch (Throwable e) { }
        try { stopService(new Intent(this, TrackService.class)); } catch (Exception e) { }
        locStarted = false;
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 78) { exportResult(res, data); return; }
        if (req == 89) {
            if (res == RESULT_OK && data != null && data.getData() != null) {
                try {
                    java.io.InputStream in = getContentResolver().openInputStream(data.getData());
                    java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
                    byte[] bf = new byte[65536];
                    int n;
                    while ((n = in.read(bf)) > 0 && bo.size() < 8000000) bo.write(bf, 0, n);
                    in.close();
                    ArrayList<GpsView.Wp> l = WptImport.read(bo.toByteArray());
                    if (l.isEmpty()) gv.toast("No waypoints found in file"); else QrShare.showList(this, l, gv);
                } catch (Exception e) { gv.toast("Cannot read file"); }
            }
            return;
        }
        if (req == 88) {
            if (res == RESULT_OK && data != null && data.getStringExtra("text") != null) QrShare.showImport(this, data.getStringExtra("text"), gv);
            return;
        }
        if (req == 77 && res == RESULT_OK && data != null && data.getData() != null) {
            final Uri u = data.getData();
            gv.toast("Copying land file...");
            new Thread(new Runnable() {
                public void run() {
                    try {
                        InputStream in = getContentResolver().openInputStream(u);
                        final File f = new File(getFilesDir(), "land.json");
                        OutputStream out = new FileOutputStream(f);
                        byte[] b = new byte[65536];
                        int n;
                        while ((n = in.read(b)) > 0) out.write(b, 0, n);
                        out.close();
                        in.close();
                        runOnUiThread(new Runnable() { public void run() { gv.loadLand(f); } });
                    } catch (Exception e) {
                        runOnUiThread(new Runnable() { public void run() { gv.toast("Cannot read file"); } });
                    }
                }
            }).start();
        }
    }

    /** Full-bleed device: keypad, LCD and brand share the whole screen; the LCD is as large as the screen allows (no scaling, no gaps). */
    static class Device extends ViewGroup {
        final float d;
        View kv, lcd, br;
        int padT, kw, kh, lw, lh, brH, ky, ly, bry;

        Device(Context c, float d) {
            super(c);
            this.d = d;
            setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                public WindowInsets onApplyWindowInsets(View v, WindowInsets in) {
                    int t = in.getSystemWindowInsetTop();
                    if (Build.VERSION.SDK_INT >= 28 && in.getDisplayCutout() != null) t = Math.max(t, in.getDisplayCutout().getSafeInsetTop());
                    if (t != padT) { padT = t; requestLayout(); }
                    return in;
                }
            });
        }

        void setParts(View k, View l, View b) { kv = k; lcd = l; br = b; addView(k); addView(l); addView(b); }

        @Override
        protected void onMeasure(int w, int h) {
            int W = MeasureSpec.getSize(w), H = MeasureSpec.getSize(h);
            int m = (int) (4 * d), bz = (int) (8 * d), gap = (int) (4 * d);
            brH = (int) (26 * d);
            int top = padT + (int) (6 * d), avail = H - top - (int) (4 * d);
            int gvMax = W - 2 * m - 2 * bz;
            int kwFit = (int) ((avail - ((int) (1.5f * gvMax) + 2 * bz) - brH - 2 * gap) * 280f / 232f);
            kw = Math.min(W, Math.max(kwFit, (int) (0.85f * W)));      // big buttons first, the LCD takes the rest
            int lcdH = Math.min((int) (1.5f * gvMax) + 2 * bz, avail - (int) (kw * 232f / 280f) - brH - 2 * gap);
            int gvW = (int) ((lcdH - 2 * bz) / 1.5f);
            lw = gvW + 2 * bz;
            lh = lcdH;
            kv.measure(MeasureSpec.makeMeasureSpec(kw, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec((int) (kw * 232f / 280f), MeasureSpec.EXACTLY));
            kh = kv.getMeasuredHeight();
            lcd.measure(MeasureSpec.makeMeasureSpec(lw, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(lh, MeasureSpec.EXACTLY));
            br.measure(MeasureSpec.makeMeasureSpec(W, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(brH, MeasureSpec.EXACTLY));
            int extra = Math.max(0, avail - kh - lh - brH - 2 * gap) / 3;
            ky = top + extra;
            ly = ky + kh + gap + extra;
            bry = ly + lh + gap + extra;
            setMeasuredDimension(W, H);
        }

        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int W = r - l;
            kv.layout((W - kv.getMeasuredWidth()) / 2, ky, (W + kv.getMeasuredWidth()) / 2, ky + kh);
            lcd.layout((W - lw) / 2, ly, (W + lw) / 2, ly + lh);
            br.layout(0, bry, W, bry + brH);
        }
    }

    /** On-screen touch button. GOTO: tap = GOTO list, hold = MOB. Arrows and zoom repeat while held. */
    Button btn(String t, final String k, float dn) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setTextSize(14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setPadding(0, 0, 0, 0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF4A4A4A, 0xFF1A1A1A});
        g.setCornerRadius(16 * dn);
        g.setStroke(2, 0xFF000000);
        b.setBackground(g);
        final boolean rep = k.equals("up") || k.equals("down") || k.equals("left") || k.equals("right") || k.equals("zin") || k.equals("zout");
        final boolean[] fired = {false};
        final Runnable lr = new Runnable() {
            public void run() { fired[0] = true; gv.press("goto", true); }
        };
        final Runnable rp = new Runnable() {
            public void run() { gv.press(k, false); h.postDelayed(this, 130); }
        };
        b.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View v, MotionEvent e) {
                int a = e.getAction();
                if (a == MotionEvent.ACTION_DOWN) {
                    v.setAlpha(0.6f);
                    fired[0] = false;
                    if (k.equals("goto")) h.postDelayed(lr, 800);
                    else if (k.equals("mark")) gv.press("enter", true);
                    else {
                        gv.press(k, false);
                        if (rep) h.postDelayed(new Runnable() { public void run() { gv.press(k, false); h.postDelayed(rp, 130); } }, 420);
                    }
                } else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                    v.setAlpha(1f);
                    h.removeCallbacks(lr);
                    h.removeCallbacks(rp);
                    if (k.equals("goto") && !fired[0] && a == MotionEvent.ACTION_UP) gv.press("goto", false);
                }
                return true;
            }
        });
        return b;
    }

    void hideBars() {
        try {
            if (Build.VERSION.SDK_INT >= 28) getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
        } catch (Exception e) { }
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) hideBars();
    }

    /** Asks once for access to the storage root so waypoints can live in <storage>/<app name>/waypoints. */
    void setupStorage() {
        gv.postDelayed(new Runnable() {
            public void run() {
                try {
                    if (Build.VERSION.SDK_INT >= 30) {
                        if (!Environment.isExternalStorageManager() && !getSharedPreferences("g72", 0).getBoolean("askedAll", false)) {
                            getSharedPreferences("g72", 0).edit().putBoolean("askedAll", true).apply();
                            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName())));
                        }
                    } else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 2);
                    }
                } catch (Exception e) { }
            }
        }, 4000);
    }

    void exportResult(int res, Intent data) {
        if (res != RESULT_OK || data == null || data.getData() == null) return;
        final Uri u = data.getData();
        final byte[] bytes;
        try { bytes = gv.gpxText().getBytes("UTF-8"); } catch (Exception e) { gv.toast("Export failed"); return; }
        new Thread(new Runnable() {
            public void run() {
                boolean ok = false;
                try {
                    OutputStream out = getContentResolver().openOutputStream(u);
                    out.write(bytes);
                    out.close();
                    ok = true;
                } catch (Exception e) { }
                final String m = ok ? "GPX exported" : "Export failed";
                runOnUiThread(new Runnable() { public void run() { gv.toast(m); } });
            }
        }).start();
    }

    long lastBack;

    /** BACK acts like the device QUIT key; leaving the app needs a second BACK within 2 seconds on a main page. */
    @Override
    public void onBackPressed() {
        if (!gv.on) { super.onBackPressed(); return; }
        if (gv.ui != null || gv.sub != 0) { gv.press("quit", false); return; }
        long now = System.currentTimeMillis();
        if (now - lastBack < 2000) moveTaskToBack(true);
        else { lastBack = now; gv.toast("Press BACK again to exit"); }
    }

    @SuppressLint("MissingPermission")
    void startLocation() {
        if (locStarted) return;
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            gv.gerr = 1;
            gv.postInvalidate();
            return;
        }
        gv.gerr = lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ? 0 : 2;
        String[] pv = {LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER};
        for (String p : pv) {
            try { lm.requestLocationUpdates(p, 1000, 0, ll); } catch (Exception e) { }
        }
        try { lm.registerGnssStatusCallback(gcb, h); } catch (Exception e) { }
        try {
            fc = LocationServices.getFusedLocationProviderClient(this);
            fcb = new LocationCallback() {
                @Override
                public void onLocationResult(LocationResult r) {
                    for (Location l : r.getLocations()) gv.onLoc(l);
                }
            };
            LocationRequest req = new LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 1000).setMinUpdateIntervalMillis(500).build();
            fc.requestLocationUpdates(req, fcb, Looper.getMainLooper());
        } catch (Throwable e) { }
        long now = System.currentTimeMillis();
        for (String p : pv) {
            try {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && now - l.getTime() < 60000) gv.onLoc(l);
            } catch (Exception e) { }
        }
        locStarted = true;
        try {
            Intent i = new Intent(this, TrackService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception e) { }
        gv.postInvalidate();
    }
}
